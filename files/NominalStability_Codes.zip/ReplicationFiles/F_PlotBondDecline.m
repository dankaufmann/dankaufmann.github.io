%% Calculates descritpive stats
clear; clc; close all;
addpath('./funcs/') 
addpath('./Chan_MASV_matlab/')

PeriodStart = [1804, 1850, 1874, 1907, 1945, 1973, 2000];
PeriodEnd   = [1849, 1873, 1906, 1944, 1972, 1999, 2017];

smplStart = {1800};
smplEnd   = {2017};
addMopoLab = 0;

mySheet = 'Data';
[data, txt]= xlsread('Data.xlsx', mySheet);
BONDS = data(: , 5);
BDate = data(:, 1);

%% Plot figures
for s = 1:size(smplStart, 2)
    for Method = {'MA_SV'}
       for Variable = {'CPI', 'NGDP', 'WPI', 'DEFL'} 
           

            load(['./Results/', char(Method), '_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s})]);
           
            if strcmp(Method, 'SW_SV')
                Tau         = store_tau;
                Date        = tid;
           else
                Tau         = stau;
                Date        = tid;
                Psi         = spsi;
           end
            
            %% Plot the trend and bond yields
            bond = BONDS(BDate >= tid(1) & BDate <= tid(end), :);
            figure;
            hold on 
                plotCI(tid, tauCI(:,1), tauCI(:,2), ':k');
                h1 = plot(tid, tauhat,':k', 'LineWidth',1.5); 
                h2 = plot(tid, bond, '-k','LineWidth',1.5);
                
                if strcmp(mySheet, 'DataQ')
                    xlim([tid(1) tid(end)]);
                    datetick
                    ylim([-4, 10])
                else
                    xlim([1899 2020]);
                    ylim([-3, 8])
                end
                ylabel('In %')
                title(char(Variable))
            hold off 
            addZeroLine;
            addMopoRegimes;
            legend([h1 h2],{'Permanent component','Bond yield'}, 'Location', 'South');
            box on;
 
            % Expsrt the graph
            outFileName = ['./Figures/', char(Method), '/Bonds_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
            exportfig(gcf, outFileName, 'Color','cmyk');
            
            %% Plot ex-post real interest rate
            rer = repmat(bond', [nloop-burnin, 1]) - stau;
            rerhat = mean(rer)';
            rerCI = quantile(rer,[.05 .95])';
                        figure;
            hold on 
                plotCI(tid, rerCI(:,1), rerCI(:,2), 'k');
                h1 = plot(tid, rerhat,'k', 'LineWidth',1.5); 
                
                if strcmp(mySheet, 'DataQ')
                    xlim([tid(1) tid(end)]);
                    datetick
                    ylim([-4, 10])
                else
                    xlim([1899 2020]);
                    ylim([-3, 8])
                end
                
                ylabel('In %')
                title(char(Variable))
            hold off 
            addZeroLine;
            addMopoRegimes;
            legend([h1 h2],{'Ex-post real interest rate'}, 'Location', 'North');
            box on;
 
            % Export the graph
            outFileName = ['./Figures/', char(Method), '/RER_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
            exportfig(gcf, outFileName, 'Color','cmyk');
    
       end
    end
end



