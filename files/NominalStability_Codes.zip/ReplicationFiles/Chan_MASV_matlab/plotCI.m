function plotCI(x,y1,y2, myPatt)
if nargin == 3
    myPatt = '-k';
end    
%f = fill([x',fliplr(x')], [y1',fliplr(y2')],C);
%set(f,'EdgeColor','none'),
plot(x, y1, myPatt, 'LineWidth', 0.2)
plot(x, y2, myPatt, 'LineWidth', 0.2)

end