%% Calculates descritpive stats
clear; clc; close all;
addpath('./funcs/') 
addpath('./Chan_MASV_matlab/')

PeriodStart = [1804, 1850, 1874, 1907, 1945, 1973, 2000];
PeriodEnd   = [1849, 1873, 1906, 1944, 1972, 1999, 2017];

smplStart = {1800};
smplEnd   = {2017};
addMopoLab = 0;

%% Plot figures
for s = 1:size(smplStart, 2)
    for Method = {'MA_SV', 'SW_SV'}
       v = 0;
       for Variable = {'CPI', 'NGDP', 'WPI', 'DEFL'}
           v = v+1;
           MidTargetRage   = {1, 1+1.5, 0.5, 1};  % Note different target ranges for NGDP and NGDP (assuming 2% productivity growth)

           load(['./Results/', char(Method), '_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s})]);

           if strcmp(Method, 'SW_SV')
                Tau         = store_tau;
                Date        = tid;
           else
                Tau         = stau;
                Date        = tid;
                Psi         = spsi;
           end
            
            %% Plot the trend
            figure;
            hold on 
                plotCI(tid, tauCI(:,1), tauCI(:,2));
                plot(tid, tauhat,'-k', 'LineWidth',1.5); 
                plot(tid, y, ':k','LineWidth',1);
                xlim([1800 2020]);
                ylim([-4, 9])
                ylabel('Log-change, in %')
                title(char(Variable))
            hold off 
            addZeroLine;
            addMopoRegimes;
            box on;
            % Export the graph
            outFileName = ['./Figures/', char(Method), '/Tau_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
            exportfig(gcf, outFileName, 'Color','cmyk');

            %% Plot the trend SV
            figure;
            hold on 
                plotCI(tid, gCI(:,1), gCI(:,2));
                plot(tid, ghat,'-k', 'LineWidth',1.5); 
                xlim([1800 2020]);
                ylim([0, 1.5])
                ylabel('Standard deviation, in %')
                title(char(Variable))
            hold off 
            addZeroLine;
            addMopoRegimes;
            box on;
            % Export the graph
            outFileName = ['./Figures/', char(Method), '/gSV_', char(Variable),'_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
            exportfig(gcf, outFileName, 'Color','cmyk');
            
           
            %% Plot the MA SV
            figure;
            hold on 
                plotCI(tid, hCI(:,1), hCI(:,2));
                plot(tid, hhat,'-k', 'LineWidth',1.5); 
                xlim([1800 2020]);
                ylim([0, 18])
                ylabel('Standard deviation, in %')
                title(char(Variable))
            hold off 
            addZeroLine;
            addMopoRegimes;
            box on;
            % Export the graph
            outFileName = ['./Figures/', char(Method), '/hSV_', char(Variable),'_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
            exportfig(gcf, outFileName, 'Color','cmyk');
                        
            %% Plot the MA coefficients
            if ~strcmp(Method, 'SW_SV')
                figure; 
                h = histogram(Psi);
                h.FaceColor = 'w';
                h.EdgeColor = 'k';
                box on;
                title(char(Variable))
                outFileName = ['./Figures/', char(Method), '/psi_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
                exportfig(gcf, outFileName, 'Color','cmyk');
            end
            
            %% Plot Prob stability over time
            Larger  = mean(Tau > MidTargetRage{v}+1, 1);
            Smaller = mean(Tau < MidTargetRage{v}-1, 1);
            Stable = ones(size(Smaller)) - Larger - Smaller;
                    
            figure;
            hold on 
                h =  area(tid, [Smaller', Stable', Larger']);
                h(1).FaceColor = [.6 .6 .6];
                h(2).FaceColor = [1 1 1];
                h(3).FaceColor = [.6 .6 .6];
                xlim([1800 2020]);
                ylim([0, 1])
                ylabel('Probability')
                title(char(Variable))
            hold off 
            addZeroLine;
            addMopoRegimes;
            box on;
            % Export the graph
            outFileName = ['./Figures/', char(Method), '/prob_', char(Variable),  '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
            exportfig(gcf, outFileName, 'Color','cmyk');
            
       end
    end
end



