%% Evaluates the results from the UC-SV models
close all;
clear;
clc;
addpath('./funcs');

PeriodStart = [1804, 1850, 1874, 1907, 1945, 1973, 2000];
PeriodEnd   = [1849, 1873, 1906, 1944, 1972, 1999, 2017];
Regimes         = {'', 'Competing currencies', 'Bimetallism', 'Gold Standard', 'World War period', 'Bretton Woods', 'Monetary targeting', 'Inflation targeting'};;
Variables       = {'CPI', 'NGDP', 'WPI', 'DEFL'};    % 	, 'WPI', 'HWI', 'PC' , NGDP	RGDP	M1	SRATE	GBPCHF
MidTargetRage   = {1, 1+1.5, 0.5, 1};  % Note different target ranges for NGDP and NGDP (assuming 2% productivity growth)

%smplStart = {1800, 1800, 1907};
%smplEnd   = {2017, 1907, 2017};
smplStart = {1800};
smplEnd   = {2017};
for s = 1:size(smplStart, 2)
    for  Method = {'MA_SV'} %  'MA_SV', 'SW_SV'
        
       for v = 1:size(Variables, 2)
           
           Variable = char(Variables{v});
           load(['./Results/', char(Method), '_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s})]);
            
           disp([Method, Variable, int2str(smplStart{s}), int2str(smplEnd{s})])
          

            % Plot the markov chain
            figure;
            subplot(3, 2, 1)
                plot(stau(:, 20), 'k'); 
                title('\tau')
                xlim([1, size(stau, 1)])
            box on;

                  subplot(3, 2, 2)
                plot(spsi(:, 1), 'k'); 
                title('\psi')
                xlim([1, size(stau, 1)])
            box on;
            
            subplot(3, 2, 3)
                plot(stheta(:, 5), 'k'); 
                title('\sigma_h')
                xlim([1, size(stau, 1)])
            box on;

            subplot(3, 2, 4)
                plot(stheta(:, 6), 'k'); 
                title('\sigma_g')
                xlim([1, size(stau, 1)])
            box on;

            subplot(3, 2, 5)
                plot(stheta(:, 3), 'k'); 
                title('\phi_h')
                xlim([1, size(stau, 1)])
            box on;
            
            subplot(3, 2, 6)
                plot(stheta(:, 4), 'k'); 
                title('\phi_g')
                xlim([1, size(stau, 1)])
            box on;
      
        
            % Export the graph
            outFileName = ['./Figures/', char(Method), '/Chain_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
            exportfig(gcf, outFileName, 'Color','cmyk');
           
            
            % Prior and posterior
            % Simulate prior

%nuh0 = 10; Sh0 = .02*(nuh0-1);
%nug0 = 10; Sg0 = .05*(nug0-1);


            for i = 1:(nloop-burnin)
                ph2(i) = 1/gamrnd(nuh0, 1./Sh0); 
                pg2(i) = 1/gamrnd(nug0, 1./Sg0); 
            end
            figure;
            subplot(1, 2, 1)
            h1 = histogram(stheta(:, 5));
            hold on;
            h2 = histogram(ph2);
            h1.FaceColor = [1 1 1];
            h1.Normalization = 'probability';
            h1.BinWidth = 0.01;
            h2.FaceColor = [0 0 0];
            h2.Normalization = 'probability';
            h2.BinWidth = 0.01;
            xlim([0, 0.3])
            legend('Posterior', 'Prior')
            title('\sigma^2_h')
            
            subplot(1, 2, 2)
            h1 = histogram(stheta(:, 6));
            hold on;
            h2 = histogram(pg2);
            h1.FaceColor = [1 1 1];
            h1.Normalization = 'probability';
            h1.BinWidth = 0.01;
            h2.FaceColor = [0 0 0];
            h2.Normalization = 'probability';
            h2.BinWidth = 0.01;
            xlim([0, 0.3])
            legend('Posterior', 'Prior')
            title('\sigma^2_g')
            
            % Export the graph
            outFileName = ['./Figures/', char(Method), '/sigPrior_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
            exportfig(gcf, outFileName, 'Color','cmyk');
          
       end
           
    end
end

