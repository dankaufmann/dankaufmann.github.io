% =======================================================================
% This is the main run file for estimating the moving average stochastic
% volatility models in Chan (2013).
%
% This code is free to use for academic purposes only, provided that the 
% paper is cited as:
%
% Chan, J.C.C. (2013). Moving Average Stochastic Volatility Models
% with Application to Inflation Forecast, Journal of Econometrics,
% 176 (2), 162-172.
%
% This code comes without technical support of any kind.  It is expected to
% reproduce the results reported in the paper. Under no circumstances will
% the authors be held responsible for any use (or misuse) of this code in
% any way.
% =======================================================================

% Adapted by Daniel Kaufmann

clear; clc; close all;
addpath('./Chan_MASV_matlab/')  

% 1:UC-MA; 2:UCSV-MA; 3:AR(1)-MA; 4:AR(2)-MA; 5:UCSV-MA-Altenrative Priors;
model = 2;
nloop   = 2000;  % 150000 (final)
burnin  = 1000;  % 100000 (final)


% Get Data
mySheet = 'Data';
[data, txt]= xlsread('Data.xlsx', mySheet); 
smplStart = {1800};
smplEnd   = {2017};
for var_id = [1, 2, 3, 5]   
    for smpl = 1:size(smplStart, 2)
    
        %% load data
        var_name = char(txt(1, var_id+1));
        isMissing = isnan(data);
        y = data(~isMissing(1:end, var_id+1), var_id+1);
        tid = data(~isMissing(1:end, var_id+1), 1);
        tid = tid(3:end, 1);
        y = log(y(2:end)./y(1:end-1))*100;

        % Impose sample restrictions
        inSmpl = (tid>=smplStart{smpl} & tid <= smplEnd{smpl});
        %[inSmpl, tid]

        y = y(inSmpl);
        tid = tid(inSmpl);
        tid = tid(2:end);
        y0 = y(1);
        y = y(2:end);
        T = length(y);
        options = optimset('Display', 'off') ;
        warning off all;
     
        disp(['Starting MCMC.... ', 'variable: ', var_name, ' sample: ', int2str(smplStart{smpl}), '-', int2str(smplEnd{smpl})]);
        disp(' ' );
        switch model
            case 1 
                UC_MA;        
            case 2        
                UCSV_MA; 
            case 3
                AR1MA;
            case 4
                AR2MA; 
            case 5        
                UCSV_MA_ROB;
        end  
        if model == 5
           save(['./Results/MA_SV_ROB_', var_name, '_', int2str(smplStart{smpl}), '_', int2str(smplEnd{smpl})])
        end
        if model == 2
           save(['./Results/MA_SV_', var_name, '_', int2str(smplStart{smpl}), '_', int2str(smplEnd{smpl})])
        end        
    end
end