% Definition of price stability lines
xL = get(gca,'XLim');
line(xL, [0, 0],'Color',[0, 0, 0]);
%line(xL, [2, 2],'Color',[0, 0, 0]);
