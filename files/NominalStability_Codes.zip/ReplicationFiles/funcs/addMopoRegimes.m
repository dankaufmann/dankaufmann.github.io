yL      = get(gca,'YLim');
%for l = 1:size(PeriodStart, 2)
%   line([PeriodStart(l) PeriodStart(l)],yL,'Color','r', 'LineStyle', '-');
%end;
dataRange = get(gca,'YLim'); % Data range of current axes
dateRange = get(gca,'XLim'); % Data range of current axes

for n = 1:(2):size(PeriodStart, 2)
     hBands(n) = patch(gca,[PeriodStart(n),PeriodStart(n),PeriodEnd(n),PeriodEnd(n)],...
                      [dataRange,fliplr(dataRange)],'k',...
                      'FaceAlpha',0.2,'EdgeColor','none');
end

if(addMopoLab)
    for n = 1:1:size(PeriodStart, 2)

        txt = MopoLab{n};
        t = text(PeriodStart(n), dataRange(2), txt, 'VerticalAlignment', 'top');
        t.FontSize = 9;

    end
end
