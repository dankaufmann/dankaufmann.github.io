% Definition of price stability lines
xL = get(gca,'XLim');
line(xL, [VariablesRange(v, 1), VariablesRange(v, 1)],'Color','r', 'LineStyle', ':');
line(xL, [VariablesRange(v, 2), VariablesRange(v, 2)],'Color','r', 'LineStyle', ':');
