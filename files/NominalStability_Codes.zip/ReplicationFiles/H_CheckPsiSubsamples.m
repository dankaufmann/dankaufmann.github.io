%% Evaluates the results from the UC-SV models
close all;
clear;
clc;
addpath('./funcs');

load(['./Results/MA_SV_CPI_1800_1907']);
Psi_first         = spsi;
load(['./Results/MA_SV_CPI_1907_2017']);
Psi_second         = spsi;
load(['./Results/MA_SV_CPI_1800_2017']);
Psi_all         = spsi;
        
means = [mean(Psi_all), mean(Psi_first), mean(Psi_second)];
stds  = [std(Psi_all), std(Psi_first), std(Psi_second)];
probs = [mean(Psi_all>0), mean(Psi_first>0), mean(Psi_second>0)];

probs2 = [mean(Psi_all<0.56 & Psi_all>0.32),mean(Psi_first<0.56 & Psi_first>0.32),mean(Psi_second<0.56 & Psi_second>0.32)];

figure;
scatter(Psi_first, Psi_second,25,'b','*')
hold on;
refline(1, 0)
hold off;

figure; 
h = histogram(Psi_first);
h.FaceColor = 'w';
h.EdgeColor = 'k';
box on;
title('Posterior \psi for CPI (1800-1907)')
%outFileName = ['./Figures/', char(Method), '/psi_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
%exportfig(gcf, outFileName, 'Color','cmyk');
          
figure; 
h = histogram(Psi_second);
h.FaceColor = 'w';
h.EdgeColor = 'k';
box on;
title('Posterior \psi for CPI (1907-2017)')
%outFileName = ['./Figures/', char(Method), '/psi_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
%exportfig(gcf, outFileName, 'Color','cmyk');
   
figure; 
h = histogram(Psi_all);
h.FaceColor = 'w';
h.EdgeColor = 'k';
box on;
title('Posterior \psi for CPI (1800-2017)')
%outFileName = ['./Figures/', char(Method), '/psi_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.eps'];
%exportfig(gcf, outFileName, 'Color','cmyk');

   