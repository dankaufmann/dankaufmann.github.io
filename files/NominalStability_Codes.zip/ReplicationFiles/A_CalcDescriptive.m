%% Calculates descritpive stats
clear; clc; close all;
addpath('./funcs/') 

PeriodStart = [1804, 1850, 1874, 1907, 1945, 1973, 2000];
PeriodEnd   = [1849, 1873, 1906, 1944, 1972, 1999, 2025];

%myFontSize      = 7;
%myWidth         = 10;


%% Load Data
[Data, Labels] = xlsread('Data.xlsx', 'Data');

% Get and transform the data
Y   = Data;
Y   = 100*(log(Y(2:end, :)) - log(Y(1:end-1, :)));
Date = Data(2:end, 1);

CPI = Y(:, strcmp(Labels, 'CPI'));
WPI = Y(:, strcmp(Labels, 'WPI'));
NGDP = Y(:, strcmp(Labels, 'NGDP'));
DEFL = Y(:, strcmp(Labels, 'DEFL'));

%% Plot figures
% 1) Make price level plot
figure;
box on;

Level = [CPI, WPI, DEFL, NGDP];
isMissing        = isnan(Level);
Level(isMissing) = 0;
Level            = cumsum(Level, 1);
Level = Level - Level(Date==1852, :);
Level(isMissing) = NaN;
   
hold on;        
plot(Date, Level(:, 1), '-k', 'LineWidth', 1.5);
plot(Date, Level(:, 2), ':k', 'LineWidth', 1.5);
plot(Date, Level(:, 3), '--k', 'LineWidth', 1.5);
plot(Date, Level(:, 4), '-.k', 'LineWidth', 1.5);
ylim([-100, 700]);

MopoLab = {{'Competing', 'currencies'}, {'Bime-','tallism'}, {'Gold', 'Standard'}, {'World War', 'period'}, {'Bretton', 'Woods'}, {'Monetary', 'targeting'}, {'Flexible', 'inflation', 'targeting'}};
addMopoLab = 1;
addMopoRegimes;
box on;
hold off;

xlim([PeriodStart(1), 2025]);
ylabel(['Log-level \times 100 (1852 = 0)'])
legend('CPI', 'WPI', 'DEFL', 'NGDP', 'Location', 'SouthEast');

% Export the graph
outFileName = ['./Figures/Descriptive/Data_Level.eps'];
exportfig(gcf, outFileName, 'Color','cmyk');

%% Make descriptive statistics
Inflation = [CPI, WPI, DEFL, NGDP];
Variables       = {'CPI', 'WPI', 'DEFL','NGDP'};    % 	, 'WPI', 'HWI', 'PC' , NGDP	RGDP	M1	SRATE	GBPCHF
Titles          = {'Consumer prices', 'Wholesale prices', 'GDP deflator', 'Nominal GDP'};
Regimes         = {'', 'Competing currencies', 'Bimetallism', 'Gold Standard', 'World War period', 'Bretton Woods', 'Monetary targeting', 'Inflation targeting'};;

for v = 1:size(Variables, 2)
    Variable = char(Variables(v));  
    Title    = char(Titles(v));

    %% Create tables
    descTable  = Regimes';
    descTable{1, 2} = 'Mean';
    descTable{1, 3} = 'Std. dev.';
    
    for p = 1:size(PeriodStart, 2)

        Label       = [int2str(PeriodStart(p)), ' - ', int2str(PeriodEnd(p))];
        
        % Ony if there is actually data available during the period
        % examined
        if Date(1) < PeriodEnd(p) || (Date(1) > PeriodEnd(p) && Date(1) > PeriodStart(p))

            % 1) Create descriptive statistics
            inSample = ((Date >= PeriodStart(p)) + (Date <= PeriodEnd(p)))>1;
            Mean     = nanmean(Inflation(inSample, v));
            Std      = nanstd(Inflation(inSample, v));
            
            descTable{p+1, 2} = num2str(Mean, '%2.2f');
            descTable{p+1, 3} = num2str(Std, '%2.2f');
        end
    end

    %% Export the tables
    tableFile = ['./Tables/Descriptive_', Variable, '.xlsx'];
    writetable(table(descTable), tableFile, 'FileType', 'spreadsheet');

end







