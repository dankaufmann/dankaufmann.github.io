%% Evaluates the results from the UC-SV models
close all;
clear;
clc;
addpath('./funcs');

PeriodStart = [1804, 1850, 1874, 1907, 1945, 1973, 2000];
PeriodEnd   = [1849, 1873, 1906, 1944, 1972, 1999, 2017];
Regimes         = {'', 'Competing currencies', 'Bimetallism', 'Gold Standard', 'World War period', 'Bretton Woods', 'Monetary targeting', 'Inflation targeting'};;
Variables       = {'CPI', 'NGDP', 'WPI', 'DEFL'};    % 	, 'WPI', 'HWI', 'PC' , NGDP	RGDP	M1	SRATE	GBPCHF
MidTargetRage   = {1, 1+1.5, 0.5, 1};  % Note different target ranges for NGDP and NGDP (assuming 2% productivity growth)

smplStart = {1800};
smplEnd   = {2017};
for s = 1:size(smplStart, 2)
    for  Method = {'MA_SV', 'SW_SV'} 
        
       for v = 1:size(Variables, 2)
           
           Variable = char(Variables{v});
           load(['./Results/', char(Method), '_', char(Variable), '_', int2str(smplStart{s}), '_', int2str(smplEnd{s})]);
            
           disp([Method, Variable, int2str(smplStart{s}), int2str(smplEnd{s})])
           
            %% Create tables
            if strcmp(Method, 'SW_SV')
                Tau         = store_tau;
                gSV         = exp(store_g/2);
                Date        = tid;
            else
                Tau         = stau;
                gSV         = exp(sg/2);
                Date        = tid;
                Psi         = spsi;
            end
            
              
            % Table for posterior of price stability
            postTable =  Regimes';
            postTable{1, 2} = 'Smaller';
            postTable{1, 3} = 'Stable';
            postTable{1, 4} = 'Larger';
            
            postTable_ROB =  Regimes';
            postTable_ROB{1, 2} = 'Smaller';
            postTable_ROB{1, 3} = 'Stable';
            postTable_ROB{1, 4} = 'Larger';
            for p = 1:size(PeriodStart, 2)

                % Ony if there is actually data available during the period
                % examined
                if Date(1) < PeriodEnd(p) || (Date(1) > PeriodEnd(p) && Date(1) > PeriodStart(p))

                    inSample = ((Date >= PeriodStart(p)) + (Date <= PeriodEnd(p)))>1;
                    
                    % 2) Create posterior probability for todays definition of price
                    % stability
                    Larger  = mean(mean(Tau(:, inSample) > MidTargetRage{v}+1));
                    Smaller = mean(mean(Tau(:, inSample) < MidTargetRage{v}-1));
                    Stable = 1 - Larger - Smaller;

                    % Export the stuff...
                    postTable{p+1, 2} = num2str(Smaller, '%2.2f');
                    postTable{p+1, 3} = num2str(Stable, '%2.2f');
                    postTable{p+1, 4} = num2str(Larger, '%2.2f');
                    
                    % 2) Robustness with lower stability range
                    Larger  = mean(mean(Tau(:, inSample) > MidTargetRage{v}));
                    Smaller = mean(mean(Tau(:, inSample) < MidTargetRage{v}-2));
                    Stable = 1 - Larger - Smaller;

                    % Export the stuff...
                    postTable_ROB{p+1, 2} = num2str(Smaller, '%2.2f');
                    postTable_ROB{p+1, 3} = num2str(Stable, '%2.2f');
                    postTable_ROB{p+1, 4} = num2str(Larger, '%2.2f');
                   
                end
            end

            %% Export the tables
            tableFile = ['./Tables/', char(Method),'/Posterior_', char(Variable),'_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.xlsx'];
            writetable(table(postTable), tableFile, 'FileType', 'spreadsheet');
            
            tableFile = ['./Tables/', char(Method),'/Posterior_ROB_', char(Variable),'_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.xlsx'];
            writetable(table(postTable_ROB), tableFile, 'FileType', 'spreadsheet');
            
            if ~strcmp(Method, 'SW_SV')
                %% Table for Psi
                EPsi = mean(Psi);
                SPsi = sqrt(var(Psi));
                PPsi = mean(Psi>0);
                
                % Evaluate truncated normal
                pd = makedist('Normal');
                pd.mu = 0;      % Note that prior is mean zero
                pd.sigma = 1;   % with inverse variance 1
                t = truncate(pd, 0, inf);
                
                evalPrior = pdf(t, 0); % Evaluate PDF at 0 (see Chan, 2013)
                
                figure;
                pdSix = fitdist(Psi, 'Kernel');
                x = 0:.01:1;
                ySix = pdf(pdSix,x);
                plot(x,ySix,'k-','LineWidth',2)
                
                evalPost = ySix(1);
                BFPsi = evalPrior/evalPost;
  
                psiTable{2, 1} = 'EPsi';
                psiTable{3, 1} = 'SPsi';
                psiTable{4, 1} = 'PPsi';
                psiTable{5, 1} = 'BFPsi';
                
                psiTable{1, v+1} = Variable;
                psiTable{2, v+1} = EPsi;
                psiTable{3, v+1} = SPsi;
                psiTable{4, v+1} = PPsi;
                psiTable{5, v+1} = BFPsi;
                
            end
            
       end
       
       if ~strcmp(Method, 'SW_SV')
           %% Export the tables
           tableFile = ['./Tables/', char(Method), '\Psi_Posterior', '_', int2str(smplStart{s}), '_', int2str(smplEnd{s}), '.xlsx'];
           writetable(table(psiTable), tableFile, 'FileType', 'spreadsheet');
       end
    end
end

