#-------------------------------------------------------------------------------
# Useful functions for heteroskedasticity-based estimator
#-------------------------------------------------------------------------------
# Fabio Canetg and Daniel Kaufmann (2022)
# Overnight rate and signalling effects of central bank bills
# European Economic Review, forthcoming
#-------------------------------------------------------------------------------

# Make output directory forder
makeOutDir <- function(mainDir, outDir){
  
  if (file.exists(outDir)){
    setwd(file.path(mainDir, outDir))
  } else {
    dir.create(file.path(mainDir, outDir))
  }
  return(paste(mainDir, outDir , sep="")) # combines the stringe mainDir and outDir with seperation "" (i.e. w/o any separation)
}

# Get data from FRED
ts_fred <- function(..., class = "data.frame") {
  symb <- c(...)
  dta.env <- new.env()
  suppressMessages(getSymbols(symb, env = dta.env, src = "FRED"))
  z <- data.table::rbindlist(lapply(as.list(dta.env), ts_dt), idcol = "id")
  tsbox:::as_class(class)(z)
}


# compute lags of a variable and return a data frame
compLags <- function(x, lags){
  df <- array(data = NA, dim = c(length(x), lags))
  for (p in 1:lags){
    df[, p] <- lag(x, p)
  }
  return(as.data.frame(df))
}

# Draws a bootstrap sample following Efron and Tibshirani (sec. 8.6).
drawBootData <- function(Data, k){
  
  Ts <- nrow(Data)
  N  <- ncol(Data)
  DataB <- array(data = NA, dim = c(Ts+100, N))
  
  for(i in 1:ceiling(Ts/k)) {            # fill the vector with random blocks
    endpoint <- sample(k:Ts, size=1)     # by randomly sampling endpoints
    DataB[(i-1)*k+1:k, ] <- Data[endpoint-(k:1)+1, ] # and copying blocks
  }
  
  DataB <- DataB[1:Ts, ]           # trim overflow when k doesn't divide N
  return(DataB)
  
}

# Main running code
estimateIRFHetLP <- function(Data, EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo, NoExo) {
  N <- length(EndVar)
  K <- length(ExoVar)
  Ts <- nrow(Data)
  J <- length(SignRest)
  
  # Select appropriate data set and rename
  AllVars <- c(EndVar, ExoVar, EventDays, OtherDays)
  DataSelect <- Data[, AllVars]
  newColNames <- c(paste("y", 1:N, sep = ""), paste("x", 1:K, sep = ""), "MainEv", "OtherEv")
  colnames(DataSelect) <- newColNames
  
  EndVarY <- paste("y", 1:N, sep = "")
  ExoVarX <- paste("x", 1:K, sep = "")
  
   # Pass all variables and functions needed
  #toExport <- c("Data", "EventDays", "OtherDays", "EndVar", "ExoVar", "SignIdent", "ScaleIdent", 
  #"H", "P", "B", "k", "useParametric", "useCumulative", "NoEndo", "NoExo",
  #"N", "K", "Ts", "AllVars",  "Data", "newColNames",  "EndVarY",  "ExoVarX",
  #"drawBootData", "compLags")
  # NOTE: Have to explicitly pass functions and packages that should be used! Otherwise
  #       looks for standard R packages and may use wrong function
  toExport <- c("drawBootData", "compLags")
  # %dopar%
  ResultsBoot <-  foreach (b = 1:B, .export = toExport, .packages = c("dplyr")) %dopar% {
    
    # Make sure that I have all functions in cluster
    #source("SVARFunctions.R")
    PsiHet <- array(NA, dim = c(N, J, H+1))
    CovEv <- array(NA, dim = c(N, J+1, H+1))
    
    # Note that here I always draw bootstrap sample because otherwise can use normal function
    #if(B > 1){
    
    # Draw a new bootstrap sample
    set.seed(b)
    if(B>1){
      DataB <- drawBootData(as.matrix(DataSelect), k)
      DataB <- as.data.frame(DataB)
      colnames(DataB) <- colnames(DataSelect)
      
    }else{
      DataB <- DataSelect
    }
    
    print(DataB)
    

    # Second data set for lagged residuals
    DataBl <- DataB
    
    # Prepare dependent variable
    for(var in EndVarY){
      DataB[, paste(var, "Dep", sep = "")]  <- DataB[, var]
      DataBl[, paste(var, "Dep", sep = "")] <- DataBl[, var]
    }
    
    if(useParametric == TRUE){
      H2 <- 0
    }else{
      H2 <- H
    }
    
    for (h in 0:H2){
      
      # Set up local projection data
      
      # 1) Estimate residuals for t|t-h
      # Compute lags for each variable (endogenous h+1 to h+P, exogenous 1 to h+P)
      for (var in EndVarY){
        DataB[, paste(var, ".l", 1:P, sep = "")] <- compLags(lag(DataB[, var], h), P)
      }
      for (var in ExoVarX){
        #DataB[, paste(var, ".l", 1:P, sep = "")] <- compLags(lag(DataB[, var], h), P)
        DataB[, paste(var, ".l", 0, sep = "")]   <- lag(DataB[, var], h)
      }
      
      if(useCumulative){
        
        if(h>0){
          
          # Calculate accumulated dependent variable
          for(var in EndVarY){
            DataB[, paste(var, "Dep", sep = "")]  <- DataB[, paste(var, "Dep", sep = "")] + lag(DataB[, var], h)
          }
        }
        
      }else{
        
        # Calculate accumulated dependent variable
        for(var in EndVarY){
          DataB[, paste(var, "Dep", sep = "")]  <- DataB[, paste(var, "Dep", sep = "")]
        }
      }
      
      # Dependent variable, endogenous variables, exogenous variables
      regData <- data.frame(DataB[, paste("y", 1:N, "Dep", sep = "")],
                            DataB[, paste(sapply(paste("y", 1:N, sep = ""), paste, paste(".l", seq(1, P, 1), sep = ""), sep ="" ))],
                            DataB[, paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, 0, 1), sep = ""), sep ="" ))])
                            #DataB[, paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, P, 1), sep = ""), sep ="" ))])
                            
                            
      colnames(regData) <- c(paste("y", 1:N, "Dep", sep = ""),
                             paste(sapply(paste("y", 1:N, sep = ""), paste, paste(".l", seq(1, P, 1), sep = ""), sep ="" )),
                             paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, 0, 1), sep = ""), sep ="" )))
                             #paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, P, 1), sep = ""), sep ="" )))
                             
                             
      lagEndo <- paste(sapply(paste("y", 1:N, sep = ""), paste, paste(".l", seq(1, P, 1), sep = ""), sep ="" ), collapse = "+")
      #lagExo  <- paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, P, 1), sep = ""), sep ="" ), collapse = "+")
      lagExo  <- paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, 0, 1), sep = ""), sep ="" ), collapse = "+")
      
      Resids <- array(NA, dim = c(Ts, N))
      colnames(Resids) <- EndVarY
      PhiHat <- array(NA, dim = c(N, N, P))
      rownames(PhiHat) <- EndVarY
      colnames(PhiHat) <- EndVarY
      
      for (var in EndVarY){
        
        if(NoExo==TRUE&NoEndo==TRUE){
          regFormula <- paste(var, "Dep ~1", sep = "")
        }
        if(NoExo==FALSE&NoEndo==FALSE){
          regFormula <- paste(var, "Dep ~", lagEndo, "+", lagExo, sep = "")
        }
        if(NoExo==TRUE&NoEndo==FALSE){
          regFormula <- paste(var, "Dep ~", lagEndo, sep = "")
        }
        if(NoExo==FALSE&NoEndo==TRUE){
          regFormula <- paste(var, "Dep ~", lagExo, sep = "")
        }
        
        # Remove pluses that are too much
        regFormula <- gsub("([[:punct:]])\\1+", "\\1", regFormula)
        regFormula <- gsub("\\+$", "", regFormula)
        
        RegResid <- lm(regFormula, data=regData, na.action = "na.exclude")
        Resids[, var] <- residuals(RegResid, na.action="na.exclude")
        
        # Collect VAR coefficients for IRFs later on if parametric
        if (useParametric == TRUE){        
          for(p in 1:P){
            PhiHat[var, , p] <- RegResid$coefficients[paste("y", 1:N, ".l", p, sep = "")]
          }
        }
      }
      
      # 2) Estimate residuals for t|t-h+1
      if (h>0){
        
        # Compute lags for each variable (endogenous h+1 to h+P, exogenous 1 to h+P)
        for (var in EndVarY){
          DataBl[, paste(var, ".l", 1:P, sep = "")] <- compLags(lag(DataBl[, var], h-1), P)
        }
        for (var in ExoVarX){
          #DataBl[, paste(var, ".l", 1:P, sep = "")] <- compLags(lag(DataBl[, var], h-1), P)
          DataBl[, paste(var, ".l", 0, sep = "")]   <- lag(DataBl[, var], h-1)
        }
        
        if(useCumulative){
          
          if(h>1){
            
            # Calculate accumulated dependent variable
            for(var in EndVarY){
              DataBl[, paste(var, "Dep", sep = "")]  <- DataBl[, paste(var, "Dep", sep = "")] + lag(DataBl[, var], h-1)
            }
          }else{
            for(var in EndVarY){
              DataBl[, paste(var, "Dep", sep = "")]  <- DataBl[, paste(var, "Dep", sep = "")]
            }
          }
          
        }else{
          
          # Calculate accumulated dependent variable
          for(var in EndVarY){
            DataBl[, paste(var, "Dep", sep = "")]  <- DataBl[, paste(var, "Dep", sep = "")]
          }
        }
        
        # Dependent variable, endogenous variables, exogenous variables
        regDatal <- data.frame(DataBl[, paste("y", 1:N, "Dep", sep = "")],
                               DataBl[, paste(sapply(paste("y", 1:N, sep = ""), paste, paste(".l", seq(1, P, 1), sep = ""), sep ="" ))],
                               DataBl[, paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, 0, 1), sep = ""), sep ="" ))])
                               #DataBl[, paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, P, 1), sep = ""), sep ="" ))])
                              
                                
        
        colnames(regDatal) <- c(paste("y", 1:N, "Dep", sep = ""),
                                paste(sapply(paste("y", 1:N, sep = ""), paste, paste(".l", seq(1, P, 1), sep = ""), sep ="" )),
                                paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, 0, 1), sep = ""), sep ="" )))
                                #paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, P, 1), sep = ""), sep ="" )))
                                
                                
        
        lagEndo <- paste(sapply(paste("y", 1:N, sep = ""), paste, paste(".l", seq(1, P, 1), sep = ""), sep ="" ), collapse = "+")
        lagExo  <- paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, 0, 1), sep = ""), sep ="" ), collapse = "+")
        #lagExo  <- paste(sapply(paste("x", 1:K, sep = ""), paste, paste(".l", seq(0, P, 1), sep = ""), sep ="" ), collapse = "+")
                
        Residsl <- array(NA, dim = c(Ts, N))
        colnames(Residsl) <- EndVarY
        
        for (var in EndVarY){
          if(NoExo==TRUE&NoEndo==TRUE){
            regFormula <- paste(var, "Dep ~1", sep = "")
          }
          if(NoExo==FALSE&NoEndo==FALSE){
            regFormula <- paste(var, "Dep ~", lagEndo, "+", lagExo, sep = "")
          }
          if(NoExo==TRUE&NoEndo==FALSE){
            regFormula <- paste(var, "Dep ~", lagEndo, sep = "")
          }
          if(NoExo==FALSE&NoEndo==TRUE){
            regFormula <- paste(var, "Dep ~", lagExo, sep = "")
          }
          # Remove pluses that are too much
          regFormula <- gsub("([[:punct:]])\\1+", "\\1", regFormula)
          regFormula <- gsub("\\+$", "", regFormula)
          
          RegResidl <- lm(regFormula, data=regDatal, na.action = "na.exclude")
          
          Residsl[, var] <- residuals(RegResidl, na.action="na.exclude")
        }
        
        Resids <- Resids - Residsl
        
      }
      
      # Compute covariance controlling for other auctions that may happen at the same time
      Event   <- (lag(DataB$MainEv, h)==TRUE)&(lag(DataB$OtherEv, h)==FALSE)
      NoEvent <- (lag(DataB$MainEv, h)==FALSE)&(lag(DataB$OtherEv, h)==FALSE)
      
      # Replace missing values with zeros so that not included in calculations
      Event[is.na(Event)]     <- FALSE
      NoEvent[is.na(NoEvent)] <- FALSE
      
      # Calculate the covariance matrices
      CovE <- cov(data.frame(Resids[Event, ]), use = "na.or.complete")
      CovNE <- cov(data.frame(Resids[NoEvent, ]), use = "na.or.complete")
      CovT <- CovE - CovNE
      
      if(b == 1&h == 0){
        e2 <- data.frame(Resids^2, Event, NoEvent)
      }else{
        e2 <- NA
      }
      #print(CovT)
      
      # Note: this imposes a unit normalization on *variance* of structural shocks and that variable 1 responds positively
      # Initial impact (h = 0)
      for (i in 1:N){
        for (j in 1:J){
          if (i == 1 & j == 1){
      
            # Impose sign restriction (shock 1)
            PsiHet[i, j, h+1] <- SignRest[j]*(sqrt(CovT[j, i]))
            
          }
          if (i == 1 & j == 2){
      
            # impose zero restriction (shock 2)
            PsiHet[i, j, h+1] <- 0
            
          }
          if (i > 1 & j == 1){
            
            # Use covariance to estimate response of variable 2
            PsiHet[i, j, h+1] <- CovT[j, i]/PsiHet[1, j, h+1]
            
          }
          if (i == 2 & j == 2){
           
            # Estimate response of variable 2 to shock 2 and impose sign restriction
            PsiHet[i, j, h+1] <- SignRest[j]*(sqrt(CovT[j, i]-PsiHet[2, 1, h+1]^2))
          
          }
          if(i>2 & j == 2){
            
            # Response of other variables to shock 2
            PsiHet[i, j, h+1] <- (CovT[j, i]-PsiHet[2, 1, h+1]*PsiHet[i, 1, h+1])/PsiHet[2, 2, h+1] 
  
          }
          # Remove extreme outliers
          if(abs(PsiHet[i, j, h+1])>10000&!is.na(PsiHet[i, j, h+1])){
            PsiHet[i, j, h+1] <- NA
          }  
        }
        #Compute variance decomposition
        CovEv[i, 1, h+1] <- PsiHet[i, 1, h+1]^2/CovE[i,i]
        if(J==2){
          CovEv[i, 2, h+1] <- PsiHet[i, 2, h+1]^2/CovE[i,i]
          CovEv[i, 3, h+1] <- (PsiHet[i, 1, h+1]^2+PsiHet[i, 2, h+1]^2)/CovE[i,i]
        }    
        #print(CovEv)
      }
    }
    if(H>0){
      if(useParametric == TRUE){
        # Dynamic impact using various lags
        for(j in 1:J){
          for (h in 1:H){
            PsiTemp <- PsiHet[ ,j, h]
            PsiTemp[] <- 0
            for (p in 1:min(h, P)){
              PsiTemp <- PsiTemp + PhiHat[, , p]%*%PsiHet[ , j, h+1-p]
            }
            PsiHet[ , j, h+1] <- PsiTemp
          }
        }    
        if(useCumulative == TRUE){
          for(j in 1:J){
            for (h in 1:H){
            PsiHet[ , j, h+1] <- PsiHet[ ,j, h+1]+PsiHet[ ,j, h]
            }
          }
        }
      }
    }
    Result <- list(PsiHet, CovEv, PhiHat, e2)
  }
  
  # In the end, collect results from the cluster in an array instead of list
  PsiHet <- array(NA, dim = c(N, J, H+1, B))
  CovEv <- array(NA, dim = c(N, J+1, H+1, B))
  for(b in 1:length(ResultsBoot)){
    PsiHet[, , , b] <- ResultsBoot[[b]][[1]]
    CovEv[, , , b] <- ResultsBoot[[b]][[2]]
  }
  rownames(PsiHet) <- EndVar
  rownames(CovEv) <- EndVar
  
  e2 <- ResultsBoot[[1]][[4]]
  
  return(list(PsiHet, CovEv, e2))
}

plotIRFHet <- function(PsiHet, H, SigScale, SigLev, plotActual, SimIRF, YLim){
  
  doCI <- !is.na(dim(PsiHet)[3])
  
  # Save everything
  IRFs <- array(data = NA, dim = c(nrow(PsiHet), H+1))
  rownames(IRFs) <- rownames(PsiHet)
  
  IRFU <- array(data = NA, dim = c(nrow(PsiHet), H+1, length(SigLev)))
  rownames(IRFU) <- rownames(PsiHet)
  IRFL <- array(data = NA, dim = c(nrow(PsiHet), H+1, length(SigLev)))
  rownames(IRFL) <- rownames(PsiHet)
  
  Labs <- rownames(PsiHet)
  
  
  # Construct CIs only if there are draws
  for (h in 0:H){
    for(i in 1:nrow(PsiHet)){
      if(doCI == TRUE){      
        IRFs[i, h+1] <- mean(PsiHet[i, h+1, ]/sqrt(SigScale), na.rm = TRUE)
        
        for(s in 1:length(SigLev)){
          IRFU[i, h+1, s] <- quantile(PsiHet[i, h+1, ]/sqrt(SigScale), 1-SigLev[s]/2, na.rm = TRUE)
          IRFL[i, h+1, s] <- quantile(PsiHet[i, h+1, ]/sqrt(SigScale), SigLev[s]/2, na.rm = TRUE)
        }
      }else{
        IRFs[i, h+1] <- PsiHet[i, h+1]/sqrt(SigScale)
        IRFU[i, h+1, ] <- PsiHet[i, h+1]/sqrt(SigScale)
        IRFL[i, h+1, ] <- PsiHet[i, h+1]/sqrt(SigScale)
      }
    }
  }

  # Plot the estimates with CI
  myGraphs <- list()
  for (i in 1:length(Labs)){
    if(plotActual){
      myIRF <- data.frame((0:H), (IRFs[i, ]), IRFU[i, , ], IRFL[i, , ], SimIRF[i, 1, ])
      colnames(myIRF) <- c("Horizon", "Mean", paste("Upper", 1:length(SigLev), sep="" ),  paste("Lower", 1:length(SigLev), sep="" ), "Actual")
    }else{
      myIRF <- data.frame((0:H), (IRFs[i, ]), IRFU[i, , ], IRFL[i, , ])
      colnames(myIRF) <- c("Horizon", "Mean", paste("Upper", 1:length(SigLev), sep="" ),  paste("Lower", 1:length(SigLev), sep="" ))
    }
    g1 <- ggplot(myIRF, aes(Horizon))
    
    for (s in 1:length(SigLev)){
      g1 <- g1 + geom_ribbon(aes_string(ymin = paste("Lower", s, sep = "") , ymax = paste("Upper", s, sep = "")), fill= "gray25", alpha=s/10)
    }
    
    g1 <- g1 + theme_minimal() + xlab("") + ggtitle(Labs[i])+theme(plot.title = element_text(size = 10))+ylab("")+theme(legend.title=element_blank()) + scale_x_continuous(breaks=seq(0, H, 2))
    g1 <- g1 + geom_hline(yintercept = 0, size=0.4, linetype = "dotted") + theme(legend.position = "none")
    g1 <- g1 + geom_line(aes(y = `Mean`, colour = "blue"), size = 0.4)
  
      if(plotActual){
      g1 <- g1 + geom_line(aes(y = `Actual`, colour = "red")) + scale_colour_manual("",values=cbind("black", "red")) 
      g1 <- g1 + geom_point(aes(y = `Actual`, colour = "red"), size = 2) + scale_colour_manual("",values=cbind("black", "red")) + scale_linetype_manual(values = c("solid", "dashed"))
    }else{
      g1 <- g1 + scale_colour_manual("",values=cbind("black"))
    }
    
    if(!missing(YLim)){
      g1 <- g1+ coord_cartesian(ylim = YLim[[i]]) 
    }
    
    g1 <- g1 + theme(panel.grid.major = element_blank()) +
      theme(panel.grid.minor = element_blank()) +
      theme(panel.border = element_rect(colour = "black", fill=NA, size=0.1))+
      theme(axis.ticks = element_line(colour = "black", size=0.1))+
      theme(axis.text = element_text(colour = "black"))+
      theme(text = element_text(size = 11, family = "Palatino"))+
      theme(plot.margin=grid::unit(c(1,1,1,1), "mm"))
    
    
    myGraphs[[i]] <- g1
  }
  return(myGraphs)
}

simEventData <- function(NSim, NBur, H){
  
  # 1) Simulate data (two shocks, both i.i.d., second shock only every fifth period)
  # --------------------------------------------------------------

  # One shock occurs only every 10 days, one shock occurs every fifth day, one shock occurs every day
  Seas1 <- seq(5, NSim+NBur, 5) 
  Sig1 <- 2
  Sig2 <- 3
  Sig3 <- 2
  
  # Simulate the shocks
  e1 <- array(data = 0, dim = c(NSim+NBur, 1))
  e1[Seas1] <- rnorm(NSim+NBur, mean = 0, sd = sqrt(Sig1))[Seas1]
  e2 <- array(data = 0, dim = c(NSim+NBur, 1))
  e2 <- rnorm(NSim+NBur, mean = 0, sd = sqrt(Sig2))
  e3 <- array(data = 0, dim = c(NSim+NBur, 1))
  e3 <- rnorm(NSim+NBur, mean = 0, sd = sqrt(Sig3))
  
  # Exogenous variables
  x <- array(data = 0, dim = c(NSim+NBur, 1))
  x <- rnorm(NSim+NBur, mean = 0, sd = sqrt((Sig3+Sig2)/2))
  
  # --------------------------------------------------------------
  # 2) Simulate data from VAR with specific coefficients
  # --------------------------------------------------------------
  # y(t) = B^-1*Gam*y(t-1)+B^-1*e + Thet*x(t-1)
  Binv <- matrix(data = c(0.7, 0.5, 0.3, 0.8, -0.9, 0.1, 0.5, 0.4, 0.2), ncol = 3, nrow = 3)
  Gam1  <- matrix(data = c(0.3, 0.7, 0.1, 0.2, 0.2, 0.2, 0.4, 0.5, -0.4), ncol = 3, nrow = 3)
  Gam2  <- matrix(data = c(0.1, 0.2, 0.05, 0.2, 0.3, 0.1, 0.2, 0.3, 0.1), ncol = 3, nrow = 3)
  
  #Thet1  <- 0.3
  #Thet2  <- 0.4
  #Thet3 <- -0.1
  
  Phi1  <- Binv%*%Gam1
  Phi2  <- Binv%*%Gam2
  y    <- matrix(data = 0, nrow = 3, ncol = NSim+NBur)
  e    <- t(cbind(as.matrix(e1), as.matrix(e2), as.matrix(e3)))
  
  for (t in 1:(NSim+NBur-2)){
    y[, t+2] <- Phi1%*%y[, t+1]+Phi2%*%y[, t]+Binv%*%e[, t+2]
    #☺+ Thet1*x[t+2] + Thet2*x[t+1] + Thet3*x[t]
  }
  
  # Remove burnin observations
  y <- y[, (NBur+1):(NSim+NBur)]
  x <- x[(NBur+1):(NSim+NBur)]
  
  e <- e[, (NBur+1):(NSim+NBur)]
  e1 <- e1[(NBur+1):(NSim+NBur)]
  e2 <- e2[(NBur+1):(NSim+NBur)]
  e3 <- e3[(NBur+1):(NSim+NBur)]
 
  # --------------------------------------------------------------
  # 3) Simulate theoretical impulse response functions from this model
  # --------------------------------------------------------------
  # Extend to VAR(2)
  # y(t) = Binv*e(t)+Phi*Binv*e(t-1)+Phi^2*Binv*e(t-2)+...
  Psi <- array(data = 0, dim = c(3, 3, H+1))
  for (h in 0:H){
    if(h == 0){
      Psi[, , h+1] <- Binv
    }
    if(h == 1){
      Psi[, , h+1] <- Phi1%*%Binv
    }
    if(h>1){
      # Note see Neusser Textbook for this recursion
      Psi[, , h+1] <- Phi1%*%Psi[, , h]+Phi2%*%Psi[, , h-1]
    }
  }
  
  PsiCum <- array(data = 0, dim = c(3, 3, H+1))
  for (h in 0:H){
    if(h == 0){
      PsiCum[, , h+1] <- Psi[, , h+1]
    }
    if(h>=1){
      
      PsiCum[, , h+1] <- PsiCum[, , h]+Psi[, , h+1]
    }
  }
  
  
  
  Data <- data.frame(t(y), x, t(e))
  colnames(Data) <- c("y1", "y2", "y3", "x1", "e1", "e2", "e3")
  return(list(Data, Psi, PsiCum))
  
}


# Construct a companion form matrix from VAR coefficients
makeCompanion <- function(Coeffs, K, P){
  
  firstRow <- Coeffs
  secondRow <- cbind(diag(K*(P-1)), matrix(0, K*(P-1), K))
  PHI <- rbind(firstRow, secondRow)
  return(PHI)
}

# Calculate IRF to a reduced form shock for a specific horizon using the companion form
calcIRF <- function(Phi, A0i, H, K, P){
  # A0*y(t) = A*C + A1*y(t-1)+...+As*eps(t)
  # PHI: Coefficients in companion form
  # A0i: Inverse of A0
  # H:   Max Horizon of IRF
  # K:   Number of variables
  
  PHI <- makeCompanion(Phi, K, P)
  IRF <- array(0, dim=c(H, K, K))        # pre-allocate space: a zero-matrix with dimension HxKxK
  for (h in 0:(H-1)){
    PHIh <- PHI%^%h   
    IRF[h+1, , ] <- PHIh[1:K,1:K]%*%A0i  # by definition, in the companion form, the model is VAR(1)
    
  }
  return(IRF)
}

# Simulate VAR data
simVARData <- function(Const, Phi, Sig, P, K, nSim, burnIn){
  # Input are parameters for an reduced-form VAR
  # y(t) = C + Phi1*y(t-1)+Phi2*y(t-2)+...+B*eps(t)
  # Sig = BB'
  
  nSim <- nSim+burnIn
  Y    <- matrix(0, nrow=K*P, ncol = nSim+P)                # pre-allocate space - size K*P x nSim + P
  
  EPS   <- t(mvrnorm(n = nSim+P, t(array(0, c(K))), Sig))   # reduced form shocks: from a multivariate std-normal w/ mean 0 and cov-matrix: Sig - size K x nSim+P
  CONST <- rbind(Const, matrix(0, K*(P-1), 1))              # constant of the comp. form - size K*P x nSim + P
  PHI   <- makeCompanion(Phi, K, P)                         # coefficient matrix of the comp. form
  
  for (t in (P+1):nSim){
    Y[,t] <- CONST + PHI%*%Y[,t-1] + EPS[, t]               # here, and only here, is EPS a reduced form shock
  }
  
  out <- list(Y=Y[1:K, (burnIn+1):nSim], EPS=EPS[1:K, (burnIn+1):nSim])    # output are 1) the simulated series Y and 2) the reduced form shocks EPS
  return(out)
}

# Invert VAR (get Psis impulse response function)
invertVAR <- function(Phi, K, H){
  
  PSI <- array(diag(K), dim=c(H, K, K))   # pre-allocate the space and impose a unitary impact effect (element 0,k,k is 1)
  PHI <- makeCompanion(Phi, K, P)
  for (h in 0:(H-1)){
    PSIh <- PHI%^%h                       # Invert using the companion form. Note that for a VAR(1), PSI(h) = PHI^h
    PSI[h+1, , ] <- PSIh[1:K, 1:K]  
  }
  
  return(PSI)
}

# Estimate the impulse responses for an IV-SVAR
estimateSVARIV <- function(data, iShock, PSI, K, H, includeLags){
  # Some particular naming conventions: X# (simulated/real series), Z# (instrument), X#.l# (lagged simulated/real series)
  # R# (estimated reduced form residuals), R#.l# (lagged estimated reduced form residuals)
  
  # Aim: ivreg(X2 ~ X1 + X1.l1 + X2.l1 + X3.l1 + X1.l2 + X2.l2 + X3.l2 | Z1 + X1.l1 + X2.l1 + X3.l1 + X1.l2 + X2.l2 + X3.l2, data = data.VAR)
  
  IRFe <- array(0, dim=c(H, K))
  for (i in iShock){                                                  # bc iShock = 3, i can only be 3 (we only compute the IRF to the 3rd shock)
    allVars   <- as.array(colnames(data.VAR))
    # lagged variables:
    lagVars   <- allVars[grep(".l", (allVars))]
    # shock variables:
    shockVar  <- as.array(paste("X", as.character(i), sep = ""))      # fabio: w/ R instead of X and includeLags == FALSE, this is estimation of (21) in Stock & Watson, p. 931
    #instrument variables:
    instVar   <- as.array(paste("Z", as.character(i), sep =""))
    
    for (k in 1:K){
      if (k != i){
        
        # the LHV:
        depVar <- as.array(paste("X", as.character(k), sep = ""))     # fabio: w/ R instead of X and includeLags == FALSE, this is estimation of (21) in Stock & Watson, p. 931
        
        # the RHV:
        if (includeLags == TRUE){
          indVar <- append(shockVar, lagVars) 
          # indVar <- shockVar                                        # fabio: w/ R instead of X and includeLags == FALSE, this is estimation of (21) in Stock & Watson, p. 931
        }else{
          indVar <- shockVar
        }
        zVar <- append(instVar, lagVars) # zusammenh?ngen
        
        # ivreg:
        myForm1 <- paste(depVar, paste(indVar, collapse=" + "), sep=" ~ ")
        myForm2 <- paste(zVar, collapse=" + ")
        myForm  <- as.formula(paste(myForm1, myForm2, sep = " | "))
        IVEst   =  ivreg(myForm, data = data.VAR)
        #print(summary(IVEst))
        print(myForm)

        IRFe[1, k] <- IVEst$coefficients[2]
        
      }else{
        IRFe[1, k] <- 1      # IE of shock j on variable j is 1 (imposed)
      }
      
    }
    
  }
  
  for (h in 1:(H-1)){
    
    IRFe[h+1, ] <- PSI[h+1, ,]%*%IRFe[1, ]    # Invert using the companion form. Note that for a VAR(1), PSI(h) = PHI^h
  }
  return(IRFe)
}

#-------------------------------------------------------------------------------------------------

# Estimate historical shocks using the estimated impulse responses
estimateShocks <- function(baseVAR, IRFe, P, K){
  vt <- t(residuals(baseVAR))
  EPSe <- array(0, dim=c(baseVAR$obs, 1))
  
  Sige <- vt%*%t(vt)/(baseVAR$obs-(P*K+1))
  Sigei <- solve(Sige)
  
  # Estimate the historical shock
  sigEps <- 1/t(IRFe[1, ])%*%Sigei%*%IRFe[1, ]  # Stock & Watson (2018), p. 933
  lam    <- t(IRFe[1, ])%*%Sigei*sigEps[1,1]    # Stock & Watson (2018), p. 933
  for (t in 1:ncol(vt)){ 
    EPSe[t, ] <- lam%*%vt[, t]                  # Stock & Watson (2018), p. 933
  }
  return(EPSe)
}



# Estimate historical decomposition (HDC)
estimateHDC <- function(EPSe, IRFe, P, K){
  HDC <- array(0, dim = c(nrow(EPSe), K))
  for (t in 1:nrow(EPSe)){
    if (t>H){
      iStart <- t-H+1
      h <- H
    }else{
      iStart <- 1
      h <- t
    }
    HDC[t, ] <- EPSe[iStart:t, ]%*%IRFe[h:1, ]
  }
  return(HDC)
}

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
