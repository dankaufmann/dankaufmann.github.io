#-------------------------------------------------------------------------------
# README - replication codes
#-------------------------------------------------------------------------------
# Fabio Canetg and Daniel Kaufmann (2022)
# Overnight rate and signalling effects of central bank bills
# European Economic Review, forthcoming
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# Software
#-------------------------------------------------------------------------------
All codes are written in R version 4.0.4 (2021-02-15). There are multiple 
packages that have to be installed in R before running the codes. The names
of the packages can be found at the beginning of each R file (library(name)).

#-------------------------------------------------------------------------------
# Files
#-------------------------------------------------------------------------------
The R files have to be run in the order of the number given by the pre-fix
to the file name to replicate all results.

# /Data/
	Original data source files in excel (sources described in the Online
	Appendix)

# SVARFunctions.R
	User-defined functions for VARs and heteroskedasticity-based identification

# 1_MakeDailyDataSet.R
	Imports data from excel and online sources (FRED) and saves them as an
	R data file in /Data/DailyData.RData

# 2_SimulateHetBootNew.R
	Simulates data from a VAR to test the heteroskedasticity-based estimator
	and replicate the results shown in Online Appendix C.

# 3_EstimateHetBootNew.R
	Uses the daily data on SNB Bills auctions to obtain the main results 
	shown in the paper and the robustness tests in Online Appendix D.

# 4_DescriptiveStats.R
	Creates graphs and descriptive statistics shown in Section 3 and Online
	Appendix B

# 5_EstimateIV.R
	Estimates the effects of SNB Bill auctions with an IV estimator discussed
	in Online Appendix D.




#-------------------------------------------------------------------------------
# Results
#-------------------------------------------------------------------------------
The results are saved in a folder. An excel file is used to create tables with 
latex code that appear in the paper.
 
# /Results/
	All results are saved in a folder with the same name as the corresponding
	R code. Tables are saved in raw excel files

# ResultsTable.xlsx
	Excel file with latex code linking to the raw excel files in the Results 
	folder
	
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
