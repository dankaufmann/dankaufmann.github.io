#-------------------------------------------------------------------------------
# 5) IV estimates
#-------------------------------------------------------------------------------
# Fabio Canetg and Daniel Kaufmann (2022)
# Overnight rate and signalling effects of central bank bills
# European Economic Review, forthcoming
#-------------------------------------------------------------------------------
# NOTES: 
# - IV estimator following Lewis (2020)
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# 0) Preliminary commands, load packages and functions, Settings
#-------------------------------------------------------------------------------
cat("\014") 
rm(list=ls())
library(AER)
library(dplyr)
library(lubridate)
library(Rfast)
library(ggplot2)
library(gridExtra)
library(xtable)
library(xts)
library(extrafont)
library(xlsx)
library(stargazer)
library(doParallel)
loadfonts(device = "win")
source("SVARFunctions.R")

# For parallel computing, register number of cores
noCores <- detectCores()
registerDoParallel(cores = noCores)

# Create results folder and settings for outputs
mainDir <- getwd()
outDir <- makeOutDir(mainDir, "/Results/EstimateIV/")
dataDir <- paste(mainDir, "./Data/", sep = "")

# OVerall settings
figWidth3 <- 24
figWidth1 <- figWidth3/3
figWidth2 <- figWidth3/3*2
figHeight1 <- 7.5
figHeight2 <- 2*figHeight1

#-------------------------------------------------------------------------------
# 2) Estimates models with actual data
#-------------------------------------------------------------------------------
# A) Load daily data
#-------------------------------------------------------------------------------
load(file=paste(dataDir, "DailyData.RData", sep = ""))
myStart <- "2008-10-20"
myEnd   <- "2011-07-31"
Sample  <- na.locf(AllData, na.rm = FALSE, maxgap = 5)   # Note fills missing values with previous value but only up to 4 days

# Remove weekends and missing values beforehand (otherwise problem with lags)
isSun <- weekdays(Sample$Date) == "Sunday"
Sample <- Sample[!isSun, ]
isSat <- weekdays(Sample$Date) == "Saturday"
Sample <- Sample[!isSat, ]

# Transform important events to logical
Sample$Auction <- Sample$Auction == TRUE
Sample$Auction[is.na(Sample$Auction)] = FALSE

Sample$Payment <- Sample$Payment == TRUE
Sample$AuctionGMBF <- Sample$AuctionGMBF==1
Sample$AuctionEid <- Sample$AuctionEid == 1
Sample$AuctionRepoUSD <- Sample$AuctionRepoUSD == 1
Sample$Payment.d <- !is.na(Sample$Payment.d)
Sample$Auction.d <- !is.na(Sample$Auction.d)
Sample$SNBlb <- Sample$SNBlb == 1
Sample$ECBmeeting <- Sample$ECBmeeting == 1

Sample$Payment[is.na(Sample$Payment)] <- FALSE
Sample$AuctionGMBF[is.na(Sample$AuctionGMBF)] <- FALSE
Sample$AuctionEid[is.na(Sample$AuctionEid)] <- FALSE
Sample$AuctionRepoUSD[is.na(Sample$AuctionRepoUSD)] <- FALSE
Sample$Payment.d[is.na(Sample$Payment.d)] <- FALSE
Sample$Auction.d[is.na(Sample$Auction.d)] <- FALSE
Sample$SNBlb[is.na(Sample$SNBlb)] <- FALSE
Sample$Speech[is.na(Sample$Speech)] <- FALSE
Sample$ECBmeeting[is.na(Sample$ECBmeeting)] <- FALSE
Sample$Outstanding[is.na(Sample$Outstanding)] <- 0

Sample$AuctionGMBF2 <- (Sample$AuctionGMBF==TRUE)&(Sample$Auction==FALSE)

Sample$RRepoAuction[is.na(Sample$RRepoAuction)] <- FALSE
Sample$BillsAuction[is.na(Sample$BillsAuction)] <- FALSE
Sample$SwapAuction[is.na(Sample$SwapAuction)] <- FALSE
Sample$NRepoAuction[is.na(Sample$NRepoAuction)] <- FALSE

Sample$RRepoAuction = Sample$RRepoAuction == 1
Sample$NRepoAuction = Sample$NRepoAuction == 1
Sample$SwapAuction = Sample$SwapAuction == 1

# Set up data
MainEv  <- Sample$Auction            # The auction is shock 1 (maybe rename to "Event")
OtherEv <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEv==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

MainEvRR  <- Sample$RRepoAuction            # The auction is shock 1 (maybe rename to "Event")
OtherEvRR <- ((Sample$SwapAuction|Sample$Auction)&MainEvRR==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

MainEvLong  <- (Sample$Auction12M==TRUE | Sample$Auction6M==TRUE)
MainEvShort  <- (Sample$Auction1M==TRUE | Sample$Auction3M==TRUE)
OtherEvLong <- ((Sample$SwapAuction|Sample$RRepoAuction|MainEvShort)&MainEvLong==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvShort <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEvShort==FALSE)|MainEvLong|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

OtherEvBroad1 <- Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad2 <- Sample$AuctionRepoUSD|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad3 <- Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad4 <- ((Sample$SwapAuction)&MainEv==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad5 <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEv==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad6 <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEv==FALSE)|Sample$Speech|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

MainEvPay  <- Sample$Payment             # The auction is shock 1 (maybe rename to "Event")
OtherEvPay <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEvPay==FALSE)|Sample$AuctionGMBF|Sample$Auction|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

MainEvUSD  <- Sample$Auction.d             # The auction is shock 1 (maybe rename to "Event")
OtherEvUSD <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEvUSD==FALSE)|Sample$Auction|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$ECBmeeting|Sample$SNBlb

MainEvGMBF  <- ((Sample$AuctionGMBF)&MainEv==FALSE)             # The auction is shock 1 (maybe rename to "Event")
OtherEvGMBF <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEvGMBF==FALSE)|Sample$Auction|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$ECBmeeting|Sample$SNBlb

# Compute (log) changes of the variables
CHFEUR <- ((log(Sample$CHFEUR)) - lag(log(Sample$CHFEUR), 1))*100
CHFUSD <- ((log(Sample$CHFUSD)) - lag(log(Sample$CHFUSD), 1))*100
CHFJPY <- ((log(Sample$CHFJPY)) - lag(log(Sample$CHFJPY), 1))*100
CHFTW  <- ((log(Sample$CHFTW)) - lag(log(Sample$CHFTW), 1))*100

USDEUR <- (log(Sample$USDEUR) - lag(log(Sample$USDEUR), 1))*100
USDJPY <- (log(Sample$USDJPY) - lag(log(Sample$USDJPY), 1))*100
USDGBP <- (log(Sample$USDGBP) - lag(log(Sample$USDGBP), 1))*100

USDEUR.l1 <- lag((log(Sample$USDEUR) - lag(log(Sample$USDEUR), 1))*100, 1)
USDJPY.l1 <- lag((log(Sample$USDJPY) - lag(log(Sample$USDJPY), 1))*100, 1)
USDGBP.l1 <- lag((log(Sample$USDGBP) - lag(log(Sample$USDGBP), 1))*100, 1)
USDEUR.f1 <- lead((log(Sample$USDEUR) - lag(log(Sample$USDEUR), 1))*100, 1)
USDJPY.f1 <- lead((log(Sample$USDJPY) - lag(log(Sample$USDJPY), 1))*100, 1)
USDGBP.f1 <- lead((log(Sample$USDGBP) - lag(log(Sample$USDGBP), 1))*100, 1)

MSCI  <- ((log(Sample$MSCI)) - lag(log(Sample$MSCI), 1))*100
SPI     <- ((log(Sample$SPI)) - lag(log(Sample$SPI), 1))*100
SMI     <- ((log(Sample$SMI)) - lag(log(Sample$SMI), 1))*100
VIXEUR  <- (Sample$VIXEUR) - lag(Sample$VIXEUR, 1)
VIXCH   <- (Sample$VIXCH) - lag(Sample$VIXCH, 1)
ESTXX   <- ((log(Sample$ESTXX)) - lag(log(Sample$ESTXX), 1))*100
ESTXX.l1 <- lag(((log(Sample$ESTXX)) - lag(log(Sample$ESTXX), 1))*100, 1)
ESTXX.f1 <- lead(((log(Sample$ESTXX)) - lag(log(Sample$ESTXX), 1))*100, 1)

SP500   <- ((log(Sample$SP500)) - lag(log(Sample$SP500), 1))*100
SP500.l1 <- lag(((log(Sample$SP500)) - lag(log(Sample$SP500), 1))*100, 1)
SP500.f1 <- lead(((log(Sample$SP500)) - lag(log(Sample$SP500), 1))*100, 1)

SARON     <- (Sample$SARON) - lag(Sample$SARON, 1)
SAR1W     <- (Sample$SAR1W) - lag(Sample$SAR1W, 1)
SAR2W     <- (Sample$SAR2W) - lag(Sample$SAR2W, 1)
SAR3M     <- (Sample$SAR3M) - lag(Sample$SAR3M, 1)
LIB3M     <- (Sample$LIB3M)  - lag(Sample$LIB3M, 1)
LIB1M     <- (Sample$LIB1M)  - lag(Sample$LIB1M, 1)
EID2Y     <- (Sample$EID2Y) - lag(Sample$EID2Y, 1)
EID8Y     <- Sample$EID8Y - lag(Sample$EID8Y, 1)
EID10Y    <- Sample$EID10Y - lag(Sample$EID10Y, 1)

TSPR1 <- EID8Y - SAR3M
TSPR2 <- EID8Y - EID2Y

US8Y     <- Sample$US8Y - lag(Sample$US8Y, 1)
GER10Y     <- Sample$GER10Y - lag(Sample$GER10Y, 1)
FFR      <- Sample$FFR - lag(Sample$FFR, 1)
EONIA    <- Sample$EONIA - lag(Sample$EONIA, 1)
US8Y.l1     <- lag(Sample$US8Y - lag(Sample$US8Y, 1), 1)
GER10Y.l1     <- lag(Sample$GER10Y - lag(Sample$GER10Y, 1), 1)
FFR.l1      <- lag(Sample$FFR - lag(Sample$FFR, 1), 1)
EONIA.l1    <- lag(Sample$EONIA - lag(Sample$EONIA, 1), 1)
US8Y.f1     <- lead(Sample$US8Y - lag(Sample$US8Y, 1), 1)
GER10Y.f1     <- lead(Sample$GER10Y - lag(Sample$GER10Y, 1), 1)
FFR.f1      <- lead(Sample$FFR - lag(Sample$FFR, 1), 1)
EONIA.f1    <- lead(Sample$EONIA - lag(Sample$EONIA, 1), 1)

CPFOR8Y   <- (Sample$CPFOR8Y) - lag(Sample$CPFOR8Y, 1)
CPHIG8Y   <- (Sample$CPHIG8Y) - lag(Sample$CPHIG8Y, 1)
CPLOW8Y   <- (Sample$CPLOW8Y) - lag(Sample$CPLOW8Y, 1)

# Construct proxy for risk premia etc.
RPLOW <- (Sample$CPLOW8Y-Sample$EID8Y) - lag(Sample$CPLOW8Y-Sample$EID8Y, 1)
RRLOW <- (Sample$CPLOW8Y-Sample$CPFOR8Y) - lag(Sample$CPLOW8Y-Sample$CPFOR8Y, 1) - RPLOW
PI    <- (Sample$CPLOW8Y) - lag(Sample$CPLOW8Y, 1) - RPLOW - RRLOW
RPHIG <- (Sample$CPHIG8Y-Sample$EID8Y) - lag(Sample$CPHIG8Y-Sample$EID8Y, 1)
RRHIG <- (Sample$CPHIG8Y-Sample$CPFOR8Y) - lag(Sample$CPHIG8Y-Sample$CPFOR8Y, 1) - RPLOW
RPMID <- (Sample$CPMID8Y-Sample$EID8Y) - lag(Sample$CPMID8Y-Sample$EID8Y, 1)
RRMID <- (Sample$CPMID8Y-Sample$CPFOR8Y) - lag(Sample$CPMID8Y-Sample$CPFOR8Y, 1) - RPLOW

# Compute repo yield on same day (or 5 days before) as auction
RRepoYield <- Sample$RRepoYield
RRepoYield[is.na(RRepoYield)] <- 0
RRepoAllot <- Sample$RRepoAllot
RRepoAllot[is.na(RRepoAllot)] <- 0
RRepoAllot <- lead(RRepoAllot, 1)
RRepoYield <- lead(RRepoYield, 1)

# Collect everything and shorten sample
Date <- Sample$Date
Data <- data.frame(Date, US8Y, GER10Y, FFR, EONIA, US8Y.l1, GER10Y.l1, FFR.l1, EONIA.l1, US8Y.f1, GER10Y.f1, FFR.f1, EONIA.f1, 
                   SP500, SP500.l1, SP500.f1, ESTXX.f1, ESTXX.l1,
                   USDGBP, USDJPY, USDEUR,USDGBP.l1, USDJPY.l1, USDEUR.l1,USDGBP.f1, USDJPY.f1, USDEUR.f1,
                   MainEvRR, OtherEvRR, SAR2W, LIB1M, OtherEvBroad5,OtherEvBroad6,  
                   RPLOW, RRLOW, RPHIG, RRHIG, RRMID, RPMID, PI, SAR3M, RRepoYield, RRepoAllot, 
                   SARON, CHFEUR, CHFUSD, VIXEUR,  CHFJPY, SMI, MSCI, SPI, CHFEUR, CHFTW, VIXCH, ESTXX,
                   LIB3M, SAR1W, EID2Y, EID8Y, EID10Y,TSPR1,TSPR2, 
                   MainEv, OtherEv, 
                   OtherEvBroad1, OtherEvBroad2, OtherEvBroad3, OtherEvBroad4, MainEvLong, OtherEvLong, MainEvShort, OtherEvShort, MainEvPay, OtherEvPay, MainEvUSD, OtherEvUSD, MainEvGMBF, OtherEvGMBF)

# Shorten to actual sample
Data <- subset(Data, as.Date(Date) >= myStart & as.Date(Date) <= myEnd)


#-------------------------------------------------------------------------------
# IV estimates and F-Test
#-------------------------------------------------------------------------------

# Compute F-statistic according to Lewis
Data$SARON.l1 <- lag(Data$SARON, 1)
Data$SMI.l1 <- lag(Data$SMI, 1)
Data$EID8Y.l1 <- lag(Data$EID8Y, 1)
Data$CHFTW.l1 <- lag(Data$CHFTW, 1)
Data$SARON.l2 <- lag(Data$SARON, 2)
Data$SMI.l2 <- lag(Data$SMI, 2)
Data$EID8Y.l2 <- lag(Data$EID8Y, 2)
Data$CHFTW.l2 <- lag(Data$CHFTW, 2)


ResSMI <- lm(SMI~SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = Data, na.action="na.exclude")
summary(ResSMI)
Data$SMIRes <- residuals(ResSMI)
ResSARON <- lm(SARON~SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = Data, na.action="na.exclude")
summary(ResSARON)
Data$SARONRes <- residuals(ResSARON)
ResCHFTW <- lm(CHFTW~SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = Data, na.action="na.exclude")
summary(ResCHFTW)
Data$CHFTWRes <- residuals(ResCHFTW)
ResEID <- lm(EID8Y~SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = Data, na.action="na.exclude")
summary(ResEID)
Data$EIDRes <- residuals(ResEID)

DataF   <- Data[(Data$MainEv==TRUE | Data$MainEv == FALSE),]
DataF$Event   <- (DataF$MainEv==TRUE)
DataF$NoEvent <- (DataF$MainEv==FALSE)

# Replace missing values with zeros so that not included in calculations
DataF <- DataF[!is.na(DataF$Event), ]
DataF <- DataF[!is.na(DataF$NoEvent), ]
Te <- sum(DataF$Event)
Tn <- sum(DataF$NoEvent)
Tt  <- dim(DataF)[1]

DataF$ZSARON <- (DataF$Event*Te/Tt - DataF$NoEvent*Tn/Tt)*DataF$SARONRes
DataF$ZCHFTW <- (DataF$Event*Te/Tt - DataF$NoEvent*Tn/Tt)*DataF$CHFTWRes
DataF$ZSMI <- (DataF$Event*Te/Tt - DataF$NoEvent*Tn/Tt)*DataF$SMIRes
DataF$ZEID <- (DataF$Event*Te/Tt - DataF$NoEvent*Tn/Tt)*DataF$EIDRes

# Regress OLS for F-statistics
FModel1 <- lm(SARONRes~ZSARON, data = DataF)
FModel2 <- lm(CHFTWRes~ZCHFTW, data = DataF)
FModel3 <- lm(SMIRes~ZSMI, data = DataF)
FModel4 <- lm(EIDRes~ZEID, data = DataF)

FSARON <- FModel1$coefficients[2]^2*(sum(DataF$ZSARON^2)^2)/(sum((DataF$ZSARON^2)*(FModel1$residuals^2)))
FCHFTW <- FModel2$coefficients[2]^2*(sum(DataF$ZCHFTW^2)^2)/(sum((DataF$ZCHFTW^2)*(FModel2$residuals^2)))
FSMI   <- FModel3$coefficients[2]^2*(sum(DataF$ZSMI^2)^2)/(sum((DataF$ZSMI^2)*(FModel3$residuals^2)))
FEID   <- FModel4$coefficients[2]^2*(sum(DataF$ZEID^2)^2)/(sum((DataF$ZEID^2)*(FModel4$residuals^2)))

print("F-statistics")
print(c(FSARON, FEID, FCHFTW, FSMI))
summary(FModel1)
summary(FModel2)
summary(FModel3)
summary(FModel4)

# Note that not exactly the same as heteroskedasticity because not controlled for other events
# Also not exactly the same because mix of the two dimensions. So a mix of money market and signalling shock (and potentially others)
# Advantage is more observations and efficient approach
# Other advantage can use F-stat

# Estimate IV model with stock price response normalized to 1
CHFTW.IV <- ivreg(CHFTW ~ SMI+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1 | ZSMI+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = DataF)
CHFTW.se <- sqrt(diag(NeweyWest(CHFTW.IV)))
summary(CHFTW.IV, vcov = NeweyWest, df = Inf, diagnostics = TRUE)

SARON.IV <- ivreg(SARON ~ SMI+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1 | ZSMI+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = DataF)
SARON.se <- sqrt(diag(NeweyWest(SARON.IV)))
summary(SARON.IV, vcov = NeweyWest, df = Inf, diagnostics = TRUE)

EID8Y.IV <- ivreg(EID8Y ~ SMI+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1 | ZSMI+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = DataF)
EID8Y.se <- sqrt(diag(NeweyWest(EID8Y.IV)))
summary(EID8Y.IV, vcov = NeweyWest, df = Inf, diagnostics = TRUE)

# Rescale coefficients on SMI
SARON.IV$coefficients[2] <- -SARON.IV$coefficients[2]
EID8Y.IV$coefficients[2] <- -EID8Y.IV$coefficients[2]
CHFTW.IV$coefficients[2] <- -CHFTW.IV$coefficients[2]

# Rescale standard error on SMI
SARON.se[2] <- SARON.se[2]
EID8Y.se[2] <- EID8Y.se[2]
CHFTW.se[2] <- CHFTW.se[2]

# Display results
stargazer(list(SARON.IV, EID8Y.IV, CHFTW.IV), 
          se = list(SARON.se, EID8Y.se, CHFTW.se), 
          dep.var.labels = c("ON interest rate (in pp)", "8Y interest rate (in pp)", "Exchange rate (in %)"),
          omit = c("SP500.l1", "FFR.l1", "USDEUR.l1", "US8Y.l1"),
          covariate.labels = c("Stock prices (in %)"),
          model.numbers = F,
          type = "text", digits = 3,
          style = "aer",
          omit.stat = c("f", "ll", "ser"),
          add.lines = list(c("Foreign controls", "yes", "yes", "yes"), c("Robust first-stage F", round(FSMI, 1), round(FSMI, 1), round(FSMI, 1))))

# Export
stargazer(list(SARON.IV, EID8Y.IV, CHFTW.IV), 
          se = list(SARON.se, EID8Y.se, CHFTW.se), 
          out = "./Results/EstimateIV/StockPrice.tex", 
          label = "tab:IVStockPrice",
          dep.var.labels = c("ON interest rate", "8Y interest rate", "Exchange rate"),
          omit = c("SP500.l1", "FFR.l1", "USDEUR.l1", "US8Y.l1"),
          covariate.labels = c("Fall in stock prices"),
          model.numbers = F,
          float = FALSE,
          colnames = FALSE,
          type = "latex", digits = 3,
          omit.table.layout = "n",
          column.sep.width = "0pt",
          style = "aer",
          omit.stat = c("f", "ll", "ser"),
          add.lines = list(c("Foreign controls", "yes", "yes", "yes"), c("Robust first-stage F", round(FSMI, 1), round(FSMI, 1), round(FSMI, 1))))

# Estimate IV model with exchange rate response normalized to 1
SMI.IV <- ivreg(SMI ~ CHFTW+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1 | ZCHFTW+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = DataF)
SMI.se <- sqrt(diag(NeweyWest(SMI.IV)))
summary(SMI.IV, vcov = NeweyWest, df = Inf, diagnostics = TRUE)

SARON.IV <- ivreg(SARON ~ CHFTW+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1 | ZCHFTW+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = DataF)
SARON.se <- sqrt(diag(NeweyWest(SARON.IV)))
summary(SARON.IV, vcov = NeweyWest, df = Inf, diagnostics = TRUE)

EID8Y.IV <- ivreg(EID8Y ~ CHFTW+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1 | ZCHFTW+SP500.l1+FFR.l1+USDEUR.l1+US8Y.l1, data = DataF)
EID8Y.se <- sqrt(diag(NeweyWest(EID8Y.IV)))
summary(EID8Y.IV, vcov = NeweyWest, df = Inf, diagnostics = TRUE)

# Rescale coefficients on SMI
SARON.IV$coefficients[2] <- -SARON.IV$coefficients[2]
EID8Y.IV$coefficients[2] <- -EID8Y.IV$coefficients[2]
SMI.IV$coefficients[2] <- -SMI.IV$coefficients[2]

# Rescale standard error on SMI
SARON.se[2] <- SARON.se[2]
EID8Y.se[2] <- EID8Y.se[2]
SMI.se[2] <- SMI.se[2]

# Display results
stargazer(list(SARON.IV, EID8Y.IV, SMI.IV), 
          se = list(SARON.se, EID8Y.se, SMI.se), 
          dep.var.labels = c("ON interest rate (in pp)", "8Y interest rate (in pp)", "Stock prices (in %)"),
          omit = c("SP500.l1", "FFR.l1", "USDEUR.l1", "US8Y.l1"),
          covariate.labels = c("Exchange rate (in %)"),
          model.numbers = F,
          type = "text", digits = 3,
          style = "aer",
          omit.stat = c("f", "ll", "ser"),
          add.lines = list(c("Foreign controls", "yes", "yes", "yes"), c("Robust first-stage F", round(FCHFTW, 1), round(FCHFTW, 1), round(FCHFTW, 1))))

# Export
stargazer(list(SARON.IV, EID8Y.IV, SMI.IV), 
          se = list(SARON.se, EID8Y.se, SMI.se), 
          out = "./Results/EstimateIV/ExchangeRate.tex", 
          label = "tab:IVExchangeRate",
          dep.var.labels = c("ON interest rate", "8Y interest rate", "Stock prices"),
          omit = c("SP500.l1", "FFR.l1", "USDEUR.l1", "US8Y.l1"),
          covariate.labels = c("Fall in exchange rate"),
          model.numbers = F,
          float = FALSE,
          colnames = FALSE,
          type = "latex", digits = 3,
          omit.table.layout = "n",
          column.sep.width = "0pt",
          style = "aer",
          omit.stat = c("f", "ll", "ser"),
          add.lines = list(c("Foreign controls", "yes", "yes", "yes"), c("Robust first-stage F", round(FCHFTW, 1), round(FCHFTW, 1), round(FCHFTW, 1))))


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------