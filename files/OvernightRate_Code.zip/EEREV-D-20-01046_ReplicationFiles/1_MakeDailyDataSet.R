#-------------------------------------------------------------------------------
# 1) Load daily data for empirical estimates and descriptive statistics
#-------------------------------------------------------------------------------
# Fabio Canetg and Daniel Kaufmann (2022)
# Overnight rate and signalling effects of central bank bills
# European Economic Review, forthcoming
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# 0) Preliminary commands, load packages and functions
#-------------------------------------------------------------------------------
rm(list=ls())
library(quantmod)
library(tsbox)
library(xlsx)
library(dplyr)   
source("SVARFunctions.R")

# Data folder
mainDir <- getwd()
dataDir <- paste(mainDir, "./Data/", sep = "")
startExport <- as.Date("2000-01-01")   # Start date for export

#-------------------------------------------------------------------------------
# German government bond data from SNB
#-------------------------------------------------------------------------------
# Note that these are ranges of maturity. Take the middle of the range
Bonds <- read.xlsx(paste(dataDir, "GermanGovBondYields.xlsx", sep = ""), sheetName = "Report", startRow = 17)
GER10Y <- Bonds[, 2]

GERData <- data.frame(as.Date(Bonds[,1]), GER10Y)
colnames(GERData) <- cbind("Date", "GER10Y")
GERData <- GERData[order(GERData$Date),]
print("German bond data loaded")

#-------------------------------------------------------------------------------
# Data from FRED
#-------------------------------------------------------------------------------
FRED <- ts_fred('DFF', 'EONIARATE', 'THREEFY8')
FRED <- ts_span(FRED, "2004-01-01", "2013-12-01")
FRED <- ts_xts(FRED)
FRED <- data.frame(as.Date(index(FRED)), FRED$EONIARATE, FRED$DFF, FRED$THREEFY8)
colnames(FRED) <- c("Date", "EONIA", "FFR", "US8Y")

#-------------------------------------------------------------------------------
# Exchange rates
#-------------------------------------------------------------------------------
# 1) CHF/EUR, CHF/JPY, CHF/USD for trade-weighted
library(stringr)

# CHF/EUR Exchange rate data (select 18h quote)
XR     <- read.csv(paste0(dataDir, "EURCHF_Candlestick_1_h_BID_01.01.2004-31.12.2011.csv"))
Date   <- str_split_fixed(XR$Local.time, " ", 3)
XR     <- data.frame(Date[, 2], as.Date(Date[, 1], format = "%d.%m.%Y"), XR$Close, XR$Volume)
colnames(XR) <- c("time", "date", "close", "volume")
XR     <- subset(XR, time == "18:00:00.000" & volume > 0)

CHFEUR <- data.frame(XR$date, XR$close)
colnames(CHFEUR) <- cbind("Date", "CHFEUR")

# CHF/USD Exchange rate data (select 18h quote)
XR     <- read.csv(paste0(dataDir, "USDCHF_Candlestick_1_h_BID_01.01.2004-31.12.2011.csv"))
Date   <- str_split_fixed(XR$Local.time, " ", 3)
XR     <- data.frame(Date[, 2], as.Date(Date[, 1], format = "%d.%m.%Y"), XR$Close, XR$Volume)
colnames(XR) <- c("time", "date", "close", "volume")
XR     <- subset(XR, time == "18:00:00.000" & volume > 0)

CHFUSD <- data.frame(XR$date, XR$close)
colnames(CHFUSD) <- cbind("Date", "CHFUSD")

# CHF/JPY Exchange rate data (select 18h quote)
XR     <- read.csv(paste0(dataDir, "CHFJPY_Candlestick_1_h_BID_01.01.2004-31.12.2011.csv"))
Date   <- str_split_fixed(XR$Local.time, " ", 3)
XR     <- data.frame(Date[, 2], as.Date(Date[, 1], format = "%d.%m.%Y"), XR$Close, XR$Volume)
colnames(XR) <- c("time", "date", "close", "volume")
XR     <- subset(XR, time == "18:00:00.000" & volume > 0)

CHFJPY <- data.frame(XR$date, 1/XR$close*100)
colnames(CHFJPY) <- cbind("Date", "CHFJPY")

# Compute trade-weighted measure
XRCH <- full_join(CHFEUR, CHFUSD, by = "Date")
XRCH <- full_join(XRCH, CHFJPY, by = "Date")
XRCH$CHFTW <- (56.9*XRCH$CHFEUR+3.2*XRCH$CHFJPY+9.5*XRCH$CHFUSD)/(56.9+3.2+9.5)

# 2) EURUSD and USDJPY and USDGBP for residuals trade-weighted (residuals estimated later on)
# USDEUR Exchange rate data (select 18h quote)
XR     <- read.csv(paste0(dataDir, "EURUSD_Candlestick_1_h_BID_01.01.2004-31.12.2011.csv"))
Date   <- str_split_fixed(XR$Local.time, " ", 3)
XR     <- data.frame(Date[, 2], as.Date(Date[, 1], format = "%d.%m.%Y"), XR$Close, XR$Volume)
colnames(XR) <- c("time", "date", "close", "volume")
XR     <- subset(XR, time == "18:00:00.000" & volume > 0)

USDEUR <- data.frame(XR$date, XR$close)
colnames(USDEUR) <- cbind("Date", "USDEUR")

# USDJPY Exchange rate data (select 18h quote)
XR     <- read.csv(paste0(dataDir, "USDJPY_Candlestick_1_h_BID_01.01.2004-31.12.2011.csv"))
Date   <- str_split_fixed(XR$Local.time, " ", 3)
XR     <- data.frame(Date[, 2], as.Date(Date[, 1], format = "%d.%m.%Y"), XR$Close, XR$Volume)
colnames(XR) <- c("time", "date", "close", "volume")
XR     <- subset(XR, time == "18:00:00.000" & volume > 0)

USDJPY <- data.frame(XR$date, 1/XR$close*100)
colnames(USDJPY) <- cbind("Date", "USDJPY")

# USDGBP Exchange rate data (select 18h quote)
XR     <- read.csv(paste0(dataDir, "GBPUSD_Candlestick_1_h_BID_01.01.2004-31.12.2011.csv"))
Date   <- str_split_fixed(XR$Local.time, " ", 3)
XR     <- data.frame(Date[, 2], as.Date(Date[, 1], format = "%d.%m.%Y"), XR$Close, XR$Volume)
colnames(XR) <- c("time", "date", "close", "volume")
XR     <- subset(XR, time == "18:00:00.000" & volume > 0)

USDGBP <- data.frame(XR$date, XR$close)
colnames(USDGBP) <- cbind("Date", "USDGBP")

# Collect for later use
XRData <- full_join(XRCH, USDEUR, by = "Date")
XRData <- full_join(XRData, USDJPY, by = "Date")
XRData <- full_join(XRData, USDGBP, by = "Date")
XRData <- XRData[order(XRData$Date),]
print("Exchange rate data loaded")

#-------------------------------------------------------------------------------
# SNB Speeches
#-------------------------------------------------------------------------------
Speeches <- read.xlsx(paste(dataDir, "SNBSpeeches.xlsx", sep = ""), sheetName = "Tabelle1", startRow = 1)
Speech <- Speeches[, 2]

Speeches <- data.frame(as.Date(Speeches[,1], format = "%d.%m.%Y"), Speech)
colnames(Speeches) <- cbind("Date", "Speech")
Speeches <- Speeches[order(Speeches$Date),]
print("Speeches data loaded")

#-------------------------------------------------------------------------------
# Data releases
#-------------------------------------------------------------------------------
DataRs <- read.xlsx(paste(dataDir, "DataReleases.xlsx", sep = ""), sheetName = "Tabelle1", startRow = 1)
DataR <- DataRs[, 2]

DataRs <- data.frame(as.Date(DataRs[,1], format = "%d.%m.%Y"), DataR)
colnames(DataRs) <- cbind("Date", "DataRelease")
DataRs <- DataRs[order(DataRs$Date),]
print("DataRs data loaded")

#-------------------------------------------------------------------------------
# SNB BIlls data
#-------------------------------------------------------------------------------
# Bills CHF data (note this data set is by instrument, but we need data set by day)
BILLS <- read.xlsx(paste(dataDir, "SNBBills.xlsx", sep = ""), sheetName = "chf", startRow = 1)
Date <- as.Date(BILLS[,1], format = "%d.%m.%y")     ## this variable is directly used in later codes
ISIN <- BILLS[,2]
Term <- BILLS[,3]
DatePayment <- as.Date(BILLS[,4], format = "%d.%m.%y")
DateRedemption <- as.Date(BILLS[,5], format = "%d.%m.%y")
Yield <- BILLS[,9]
Bids <- BILLS[,10]
Allotment <- BILLS[,11]
OutstandingByTerm <- BILLS[,12]
OutstandingTotal <- BILLS[,13]
CoverRate <- Allotment/Bids
BillsData <- data.frame(as.Date(BILLS[,1], format = "%d.%m.%y"), ISIN, Term, DatePayment, DateRedemption, Yield, Bids, Allotment, OutstandingByTerm, OutstandingTotal, CoverRate)
colnames(BillsData) <- cbind("Date", "ISIN", "Term", "DatePayment", "DateRedemption", "Yield", "Bids", "Allotment", "OutstandingByTerm", "OutstandingTotal", "CoverRate")
BillsData <- BillsData[order(BillsData$Date),]
print("Bills CHF data loaded")

# Create daily data set aggregated over all instruments
startDate  = as.Date("2008-01-01")
endDate    = as.Date("2012-01-01")

# Create data frames to save results in (by instrument, aggregation below) 
# Note that this is a weekday data set. But should not matter much in the end.
OutStanding <- data.frame(Date = seq(startDate, endDate, "days"))
OutStanding <- data.frame(OutStanding[!weekdays(OutStanding$Date) %in% c(weekdays(as.Date(cbind("2018-10-06","2018-10-07")))),]) # drop wknds
YieldWeighted <- data.frame(Date = seq(startDate, endDate, "days"))
YieldWeighted <- data.frame(YieldWeighted[!weekdays(YieldWeighted$Date) %in% c(weekdays(as.Date(cbind("2018-10-06","2018-10-07")))),]) # drop wknds
Yield <- data.frame(Date = seq(startDate, endDate, "days"))
Yield <- data.frame(Yield[!weekdays(Yield$Date) %in% c(weekdays(as.Date(cbind("2018-10-06","2018-10-07")))),]) # drop wknds
Allotment <- data.frame(Date = seq(startDate, endDate, "days"))
Allotment <- data.frame(Allotment[!weekdays(Allotment$Date) %in% c(weekdays(as.Date(cbind("2018-10-06","2018-10-07")))),]) # drop wknds
Bids <- data.frame(Date = seq(startDate, endDate, "days"))
Bids <- data.frame(Bids[!weekdays(Bids$Date) %in% c(weekdays(as.Date(cbind("2018-10-06","2018-10-07")))),]) # drop wknds
Auctions <- data.frame(Date = seq(startDate, endDate, "days"))
Auctions <- data.frame(Auctions[!weekdays(Auctions$Date) %in% c(weekdays(as.Date(cbind("2018-10-06","2018-10-07")))),]) # drop wknds
Payments <- data.frame(Date = seq(startDate, endDate, "days"))
Payments <- data.frame(Payments[!weekdays(Payments$Date) %in% c(weekdays(as.Date(cbind("2018-10-06","2018-10-07")))),]) # drop wknds

YieldWeighted$Total <- 0
colnames(OutStanding) <- c("Date")
colnames(YieldWeighted) <- c("Date", "Total")
colnames(Yield) <- c("Date")
colnames(Allotment) <- c("Date")
colnames(Bids) <- c("Date")
colnames(Auctions) <- c("Date")
colnames(Payments) <- c("Date")

for (inst in unique(BillsData$ISIN)){ # for each instrument
  BillsDataInst <- BillsData[BillsData$ISIN==inst, ]
  
  for(auct in unique(BillsDataInst$Date)){ # for each date on which this instrument was auctioned
    BillsDataInstAuct  <- BillsDataInst[BillsDataInst$Date==auct, ]
    name               <- paste(inst, "-", as.Date(auct), sep ="")
    allot              <- BillsDataInstAuct$Allotment
    yield              <- BillsDataInstAuct$Yield
    bid                <- BillsDataInstAuct$Bids
    term               <- BillsDataInstAuct$Term
    
    # Note: left_join because we create a weekday data set here
    TempData           <- data.frame(Date = seq(BillsDataInstAuct$DatePayment, BillsDataInstAuct$DateRedemption-1, "days"))  
    TempData$name      <- allot                                             # this instrument (name) has allot outstanding (allot is a vector w/ the duration of that particular instrument)
    colnames(TempData) <- cbind("Date", name)
    OutStanding        <- left_join(OutStanding, TempData, by="Date")       # matching by date: for a 7-days bill: TempData has 7 entries, Outstanding will only have 5 entries
    
    TempYield          <- data.frame(Date = seq(BillsDataInstAuct$DatePayment, BillsDataInstAuct$DateRedemption-1, "days")) 
    TempYield$name     <- allot*yield
    colnames(TempYield)<- cbind("Date", name)
    YieldWeighted      <- left_join(YieldWeighted, TempYield, by="Date") 

    TempYield2          <- data.frame(Date = seq(BillsDataInstAuct$Date, BillsDataInstAuct$Date, "days")) 
    TempYield2$name     <- yield
    colnames(TempYield2)<- cbind("Date", name)
    Yield               <- left_join(Yield, TempYield2, by="Date") 
    
    # Added Allotment and Bids to calculate cover rate for an acution day rather than per instrument
    TempAllot           <- data.frame(Date = BillsDataInstAuct$Date) 
    TempAllot$name      <- allot
    colnames(TempAllot) <- cbind("Date", name)
    Allotment           <- left_join(Allotment, TempAllot, by="Date")   
    
    TempBids            <- data.frame(Date = BillsDataInstAuct$Date) 
    TempBids$name       <- bid
    colnames(TempBids)  <- cbind("Date", name)
    Bids                <- left_join(Bids, TempBids, by="Date")    
    
    TempAuctions            <- data.frame(Date = BillsDataInstAuct$Date) 
    TempAuctions$name       <- term
    colnames(TempAuctions)  <- cbind("Date", name)
    Auctions                <- left_join(Auctions, TempAuctions, by="Date")   
    
    TempPayments            <- data.frame(Date = BillsDataInstAuct$DatePayment) 
    TempPayments$name       <- 1
    colnames(TempPayments)  <- cbind("Date", name)
    Payments                <- left_join(Payments, TempPayments, by="Date")   
    
  }
}

rownames(OutStanding)   <- OutStanding$Date
OutStanding$Total       <- rowSums(OutStanding[, grep("CH", colnames(OutStanding))], na.rm=TRUE)       # grep looks for "CH" in ISIN

rownames(Allotment)   <- Allotment$Date
Allotment$Total       <- rowSums(Allotment[, grep("CH", colnames(Allotment))], na.rm=TRUE)       # grep looks for "CH" in ISIN

rownames(Bids)   <- Bids$Date
Bids$Total       <- rowSums(Bids[, grep("CH", colnames(Bids))], na.rm=TRUE)       # grep looks for "CH" in ISIN

rownames(YieldWeighted) <- YieldWeighted$Date
YieldWeighted$Total     <- rowSums(YieldWeighted[, grep("CH", colnames(YieldWeighted))], na.rm=TRUE)   # weighted
YieldWeighted$Total     <- YieldWeighted$Total/OutStanding$Total                                       # weighted and normalized

rownames(Yield) <- Yield$Date
Yield$Total     <- rowMeans(Yield[, grep("CH", colnames(Yield))], na.rm=TRUE)   # weighted

rownames(Auctions) <- Auctions$Date
Auctions$Total     <- rowSums(Auctions[, grep("CH", colnames(Auctions))], na.rm=TRUE)   # weighted

rownames(Payments) <- Payments$Date
Payments$Total     <- rowSums(Payments[, grep("CH", colnames(Payments))], na.rm=TRUE)   # weighted

# Calculate a measure wheter Bills are expected to increase, remain constant or decline on the next payment date
# After the auction took place
SurpBills <- data.frame(Date = seq(startDate, endDate, "days"))
SurpBills <- data.frame(SurpBills[!weekdays(SurpBills$Date) %in% c(weekdays(as.Date(cbind("2018-10-06","2018-10-07")))),]) # drop wknds
colnames(SurpBills) <- c("Date")

Dates <- rownames(Auctions)
Payments <- data.frame(Dates, Payments$Total>0)
for(auct in unique(BillsData$Date)){ # for each date on which this instrument was auctioned

  
  # 1) Get Allotment on the auction date
  allot <- Allotment$Total[as.Date(auct) == Dates]
  
  # 2) Get outstanding Bills on the auction date
  outst <- OutStanding$Total[as.Date(auct) == Dates]
  
  # 3) Get how many Bills will mature on the next payment date (so that increase was in a sense temporary)
  FutPayments <- subset(Payments, as.Date(Dates) > as.Date(auct)) 
  FutPayments <- FutPayments[FutPayments[, 2] == TRUE,]
  DatePayment <- as.Date(FutPayments[1, 1])
  
  # Note that this is only correct if there is only one auction between auction and next payment (check this)
  outPaym <- OutStanding$Total[DatePayment == Dates]
    
  SurpBills[SurpBills$Date == as.Date(auct), "Val"] <- (outPaym - outst)

}
SurpBills[is.na(SurpBills$Val), "Val"] = 0

# Generate buckets with auction terms
AuctionsTemp <- Auctions[,2:(ncol(Auctions)-1)]
Auction1M  <- rowSums(AuctionsTemp<40 & AuctionsTemp>0, na.rm=TRUE)>0
Auction3M  <- rowSums(AuctionsTemp>=40 & AuctionsTemp<100, na.rm=TRUE)>0
Auction6M  <- rowSums(AuctionsTemp>=100 & AuctionsTemp<300, na.rm=TRUE)>0
Auction12M <- rowSums(AuctionsTemp>=300, na.rm=TRUE)>0
AuctionAll <- rowSums(AuctionsTemp>0, na.rm=TRUE)>0

sum(Auction1M+Auction3M+Auction6M+Auction12M)
sum(AuctionAll)
sum(Auctions$Total>0)

# Generate interaction of term auction and yield
YieldsTemp <- Yield[,2:(ncol(Yield))]

Ind7D <- (AuctionsTemp<=7)
Ind7D[is.na(Ind7D)] <- 0
Yield7D <- rowMeans(YieldsTemp*Ind7D, na.rm = TRUE)
Yield7D[is.na(Yield7D)] <- 0

Ind1M <- (AuctionsTemp<40 & AuctionsTemp>0)
Ind1M[is.na(Ind1M)] <- 0
Yield1M <- rowMeans(YieldsTemp*Ind1M, na.rm = TRUE)
Yield1M[is.na(Yield1M)] <- 0

Ind3M <- (AuctionsTemp>=40 & AuctionsTemp<100)
Ind3M[is.na(Ind3M)] <- 0
Yield3M <- rowMeans(YieldsTemp*Ind3M, na.rm = TRUE)
Yield3M[is.na(Yield3M)] <- 0

Ind6M <- (AuctionsTemp>=100 & AuctionsTemp<300)
Ind6M[is.na(Ind6M)] <- 0
Yield6M <- rowMeans(YieldsTemp*Ind6M, na.rm = TRUE)
Yield6M[is.na(Yield6M)] <- 0

Ind12M <- (AuctionsTemp>=300)
Ind12M[is.na(Ind12M)] <- 0
Yield12M <- rowMeans(YieldsTemp*Ind12M, na.rm = TRUE)                   
Yield12M[is.na(Yield12M)] <- 0

# Generate interaction term of term and allottment
AllotTemp <- Allotment[,2:(ncol(Allotment)-1)]

Allot1M <- rowSums(AllotTemp*Ind1M, na.rm = TRUE)
Allot1M[is.na(Allot1M)] <- 0

Allot3M <- rowSums(AllotTemp*Ind3M, na.rm = TRUE)
Allot3M[is.na(Allot3M)] <- 0

Allot6M <- rowSums(AllotTemp*Ind6M, na.rm = TRUE)
Allot6M[is.na(Allot6M)] <- 0

Allot12M <- rowSums(AllotTemp*Ind12M, na.rm = TRUE)
Allot12M[is.na(Allot12M)] <- 0

data.frame(Allot1M+Allot3M+Allot6M+Allot12M, Allotment$Total)


# Generage amount outstanding according to term for chart
OutTemp <- OutStanding[, 2:(ncol(OutStanding)-1)]

inst1M <- apply(Ind1M, 2, function(r) any(r == 1))
Out1M <- rowSums(OutTemp[, inst1M], na.rm = TRUE)
Out1M[is.na(Out1M)] <- 0

inst3M <- apply(Ind3M, 2, function(r) any(r == 1))
Out3M <- rowSums(OutTemp[, inst3M], na.rm = TRUE)
Out3M[is.na(Out3M)] <- 0

inst6M <- apply(Ind6M, 2, function(r) any(r == 1))
Out6M <- rowSums(OutTemp[, inst6M], na.rm = TRUE)
Out6M[is.na(Out6M)] <- 0

inst12M <- apply(Ind12M, 2, function(r) any(r == 1))
Out12M <- rowSums(OutTemp[, inst12M], na.rm = TRUE)
Out12M[is.na(Out12M)] <- 0

data.frame(Out1M+Out3M+Out6M+Out12M, OutStanding$Total)

BillsDaily <- data.frame(YieldWeighted$Date, OutStanding$Total, YieldWeighted$Total, Yield$Total, Allotment$Total, Bids$Total, Allotment$Total/Bids$Total, 
                         AuctionAll, Payments[, 2], SurpBills$Val,
                         Auction1M, Auction3M, Auction6M, Auction12M,
                         Yield7D, Yield1M, Yield3M, Yield6M, Yield12M,
                         Allot1M, Allot3M, Allot6M, Allot12M,
                         Out1M, Out3M, Out6M, Out12M)
colnames(BillsDaily) <- c("Date", "Outstanding", "Yield", "Yield2", "Allotment", "Bid", "CoverRate", "Auction", "Payment", "Surprise",
                          "Auction1M", "Auction3M", "Auction6M", "Auction12M",
                          "Yield7D", "Yield1M", "Yield3M", "Yield6M", "Yield12M",
                          "Allot1M", "Allot3M", "Allot6M", "Allot12M",
                          "Out1M", "Out3M", "Out6M", "Out12M")
BillsDaily$CoverRate[is.na(BillsDaily$CoverRate)] <- 0

BILLS.d <- read.xlsx(paste(dataDir, "SNBBills.xlsx", sep = ""), sheetName = "usd", startRow = 1)
DateAuction.d <- as.Date(BILLS.d[,1], format = "%d.%m.%y")
DatePayment.d <- as.Date(BILLS.d[,4], format = "%d.%m.%y")

Temp1 <- data.frame(unique(DateAuction.d))
Temp1$Auction.d <- 1
colnames(Temp1) <- c("Date", "Auction.d")
Temp2 <- data.frame(unique(DatePayment.d))
Temp2$Payment.d <- 1
colnames(Temp2) <- c("Date", "Payment.d")
BillsDaily.d <- full_join(Temp1, Temp2, by = "Date")
colnames(BillsDaily.d) <- c("Date", "Auction.d", "Payment.d")
BillsDaily.d <- BillsDaily.d[order(BillsDaily.d$Date),]

# Create daily date vector without weekends
# Specify estimation sample (date of first and last auction)
myStart <- "2005-01-01"
myEnd <- "2018-12-31"
myDate <- seq(as.Date(myStart), as.Date(myEnd), "days")
Auction.b <- data.frame(myDate, rep(0, length(myDate)))
colnames(Auction.b) <- c("Date", "AuctionGMBF")

# Remove weekends and missing values beforehand (otherwise problem with lags)
isSun <- weekdays(Auction.b$Date) == "Sunday"
Auction.b <- Auction.b[!isSun, ]
isSat <- weekdays(Auction.b$Date) == "Saturday"
Auction.b <- Auction.b[!isSat, ]
isTue <- weekdays(Auction.b$Date) == "Tuesday"

# Create Dummy for GMBF (always Tuesday)
Auction.b[, "AuctionGMBF"] <- 0
Auction.b[isTue, "AuctionGMBF"] <- 1

# Add Bond auctions
BondAuc <- read.xlsx(paste(dataDir, "BondAuctions.xlsx", sep = ""), sheetName = "Tabelle1", startRow = 1)
BondAuc <- as.Date(BondAuc[, 1], "%d.%m.%Y")

hasAuction <- Auction.b$Date%in%BondAuc

Auction.b[, "AuctionEid"] <- 0
Auction.b[hasAuction, "AuctionEid"] <- 1

# Add REPO
RepoUSD <- read.xlsx(paste(dataDir, "RepoUSD.xlsx", sep = ""), sheetName = "Tabelle1", startRow = 1)
RepoAuc <- as.Date(RepoUSD[, 1], "%d.%m.%y")
RepoVol <- RepoUSD[, 5]
RepoAuc <- RepoAuc[RepoVol>0] # Just seelct USD Repo auctions with a positive voluem
hasAuction <- Auction.b$Date%in%RepoAuc

Auction.b[, "AuctionRepoUSD"] <- 0
Auction.b[hasAuction, "AuctionRepoUSD"] <- 1

#-------------------------------------------------------------------------------
# Government bond data
#-------------------------------------------------------------------------------
# Note that these are ranges of maturity. Take the middle of the range
Bonds <- read.xlsx(paste(dataDir, "CHFGovBondYields.xlsx", sep = ""), sheetName = "Government_Yields_Close_SIX", startRow = 5)
EID2Y <- Bonds[, 2]
EID4Y <- Bonds[, 3]
EID6Y <- Bonds[, 4]
EID8Y <- Bonds[, 5]
EID10Y <- (Bonds[, 5]+Bonds[, 6])/2

EIDData <- data.frame(as.Date(Bonds[,1]), EID2Y, EID4Y, EID6Y, EID8Y, EID10Y)
colnames(EIDData) <- cbind("Date", "EID2Y", "EID4Y", "EID6Y", "EID8Y", "EID10Y")
EIDData <- EIDData[order(EIDData$Date),]
print("Government bond data loaded")

#-------------------------------------------------------------------------------
# Corporate bond data
#-------------------------------------------------------------------------------
# Note that these are ranges of maturity. Take the middle of the range. Also, low/mid/high mean
# AAA-BBB, AAA-A, AAA-AA
# Note that foreign are AAA-AA and are copied from another excel file
Bonds <- read.xlsx(paste(dataDir, "CHFCorpBondYields.xlsx", sep = ""), sheetName = "NonGovernment_Yields_Close_SIX", startRow = 5)

CPLOW2Y  <- Bonds[, 2]
CPLOW4Y  <- Bonds[, 3]
CPLOW6Y  <- Bonds[, 4]
CPLOW8Y  <- Bonds[, 5]
CPLOW10Y <- (Bonds[, 5]+Bonds[, 6])/2

CPMID2Y  <- Bonds[, 7]
CPMID4Y  <- Bonds[, 8]
CPMID6Y  <- Bonds[, 9]
CPMID8Y  <- Bonds[, 10]
CPMID10Y <- (Bonds[, 10]+Bonds[, 11])/2

CPHIG2Y  <- Bonds[, 12]
CPHIG4Y  <- Bonds[, 13]
CPHIG6Y  <- Bonds[, 14]
CPHIG8Y  <- Bonds[, 15]
CPHIG10Y <- (Bonds[, 15]+Bonds[, 16])/2

CPFOR2Y  <- Bonds[, 17]
CPFOR4Y  <- Bonds[, 18]
CPFOR6Y  <- Bonds[, 19]
CPFOR8Y  <- Bonds[, 20]
CPFOR10Y <- (Bonds[, 20]+Bonds[, 21])/2

CORPData <- data.frame(as.Date(Bonds[,1]), CPLOW2Y, CPLOW4Y, CPLOW6Y, CPLOW8Y, CPLOW10Y,
                       CPMID2Y, CPMID4Y, CPMID6Y, CPMID8Y, CPMID10Y,
                       CPHIG2Y, CPHIG4Y, CPHIG6Y, CPHIG8Y, CPHIG10Y,
                       CPFOR2Y, CPFOR4Y, CPFOR6Y, CPFOR8Y, CPFOR10Y)
colnames(CORPData) <- cbind("Date", "CPLOW2Y", "CPLOW4Y", "CPLOW6Y", "CPLOW8Y", "CPLOW10Y",
                            "CPMID2Y", "CPMID4Y", "CPMID6Y", "CPMID8Y", "CPMID10Y",
                            "CPHIG2Y", "CPHIG4Y", "CPHIG6Y", "CPHIG8Y", "CPHIG10Y",
                            "CPFOR2Y", "CPFOR4Y", "CPFOR6Y", "CPFOR8Y", "CPFOR10Y")
CORPData <- CORPData[order(CORPData$Date),]
print("Corporate bond data loaded")

#-------------------------------------------------------------------------------
# (reverse) Repo Auctions
#-------------------------------------------------------------------------------
Repo <- read.xlsx(paste(dataDir, "RepoOperations.xlsx", sep = ""), stringsAsFactors = FALSE, sheetName = "Sheet1", startRow = 20)
NormRepo <- subset(Repo, Art == "Repo")
Swaps <- subset(Repo, Art == "Swaps")
RevRepo <- subset(Repo, Art == "Reverse Repo")
Bills <- subset(Repo, Art == "SNB Bills")

unique(RevRepo$Laufzeit)
RevRepo$Gebote <- as.numeric(RevRepo$Gebote)
RevRepo$Zuteilung <- as.numeric(RevRepo$Zuteilung)

# Only one reverse repo each day!
length(unique(RevRepo$Date))
length(RevRepo$Date)

# To test variable SNB Bills date auction
BillsData <- data.frame(unique(Bills$Date), 1)
colnames(BillsData) <- c("Date", "BillsAuction")
BillsData <- BillsData[order(BillsData$Date),]

# Swap auction date
SwapsData <- data.frame(as.Date(unique(Swaps$Date)), 1)
colnames(SwapsData) <- cbind("Date", "SwapAuction")
SwapsData <- SwapsData[order(SwapsData$Date),]

# Normal repo auction date
NormRepoData <- data.frame(as.Date(unique(NormRepo$Date)), 1)
colnames(NormRepoData) <- cbind("Date", "NRepoAuction")
NormRepoData <- NormRepoData[order(NormRepoData$Date),]

RevRepoData <- data.frame(as.Date(RevRepo$Date), 1, RevRepo$Zins, RevRepo$Zuteilung, RevRepo$Gebote)
colnames(RevRepoData) <- cbind("Date", "RRepoAuction", "RRepoYield", "RRepoAllot", "RRepoBid")
RevRepoData <- RevRepoData[order(RevRepoData$Date),]

RevRepoData <- full_join(BillsData, RevRepoData, by = "Date")
RevRepoData <- full_join(RevRepoData, SwapsData, by = "Date")
RevRepoData <- full_join(RevRepoData, NormRepoData, by = "Date")
RevRepoData$BillsAuction[is.na(RevRepoData$BillsAuction)] = 0
RevRepoData$RRepoAuction[is.na(RevRepoData$RRepoAuction)] = 0
RevRepoData$NRepoAuction[is.na(RevRepoData$NRepoAuction)] = 0
RevRepoData$SwapAuction[is.na(RevRepoData$SwapAuction)] = 0
RevRepoData <- RevRepoData[order(RevRepoData$Date),]

sum(RevRepoData$BillsAuction)
sum(RevRepoData$RRepoAuction)
sum(RevRepoData$NRepoAuction)
sum(RevRepoData$SwapAuction)
sum(RevRepoData$RRepoAuction==RevRepoData$BillsAuction)

print("Rev repo data loaded")

#-------------------------------------------------------------------------------
# SAR data
#-------------------------------------------------------------------------------
SARData <- read.xlsx(paste(dataDir, "InterestRatesSAR.xlsx", sep = ""), sheetName = "Report", startRow = 17)

SARON.noon <- SARData[, 2]   # 12:00 fixing
SARON <- SARData[, 3]        # Handelsschluss
SARTN.noon <- SARData[, 4]
SARTN <- SARData[, 5]
SAR1W.noon <- SARData[, 6]
SAR1W <- SARData[, 7]
SAR2W.noon <- SARData[, 8]
SAR2W <- SARData[, 9]
SAR1M.noon <- SARData[, 10]
SAR1M <- SARData[, 11]
SAR3M.noon <- SARData[, 12]
SAR3M <- SARData[, 13]

SARONData <- data.frame(as.Date(SARData[,1]), SARON.noon, SARON, SARTN.noon, SARTN, SAR1W.noon, SAR1W, SAR2W.noon, SAR2W, SAR1M.noon, SAR1M, SAR3M.noon, SAR3M)
colnames(SARONData) <- cbind("Date", "SARON.noon", "SARON", "SARTN.noon", "SARTN", "SAR1W.noon" , "SAR1W", "SAR2W.noon", "SAR2W", "SAR1M.noon", "SAR1M", "SAR3M.noon","SAR3M")
SARONData <- SARONData[order(SARONData$Date),]
print("SAR data loaded")

#-------------------------------------------------------------------------------
# CHF Libor data
#-------------------------------------------------------------------------------
LIBData <- read.xlsx(paste(dataDir, "InterestRatesLibor.xlsx", sep = ""), sheetName = "FRED Graph", startRow = 14)

LIB3M <- LIBData[, 2]
LIB1M <- LIBData[, 3]
LIB12M <- LIBData[, 4]
LIB6M <- LIBData[, 5]

LIBORData <- data.frame(as.Date(LIBData[,1]), LIB1M, LIB3M, LIB6M, LIB12M)
colnames(LIBORData) <- cbind("Date", "LIB1M", "LIB3M", "LIB6M", "LIB12M")
LIBORData <- LIBORData[order(LIBORData$Date),]
print("Libor data loaded")

#-------------------------------------------------------------------------------
# Stock market data (Use trade close quotes)
#-------------------------------------------------------------------------------
StockData <- read.xlsx(paste(dataDir, "StockMarketClose.xlsx", sep = ""), sheetName = "eikon_output", startRow = 4)

SMI <- StockData[, 2]
SPI <- StockData[, 3]
SLI <- StockData[, 4]
VIXCH <- StockData[, 5]
ESTXX <- StockData[, 6]
VIXEUR <- StockData[, 7]
DAX <- StockData[, 8]
VIXDAX <- StockData[, 9]
SP500 <- StockData[, 10]
VIXUS <- StockData[, 11]

SPIL <- StockData[, 12]
SPIM <- StockData[, 13]
SPIS <- StockData[, 14]

StockData <- data.frame(as.Date(StockData[,1], format = "%d.%m.%Y"), SMI, SPI, SLI, VIXCH, ESTXX, VIXEUR, DAX, VIXDAX, SP500, VIXUS, SPIL, SPIM, SPIS)
colnames(StockData) <- cbind("Date", "SMI", "SPI", "SLI", "VIXCH", "ESTXX", "VIXEUR", "DAX", "VIXDAX", "SP500", "VIXUS", "SPIL", "SPIM", "SPIS")
StockData <- StockData[order(StockData$Date),]
print("Stock market data loaded")

# Stock market data MSCI
MSCIData <- read.xlsx(paste(dataDir, "StockMarketMSCI.xlsx", sep = ""), sheetName = "eikon_output", startRow = 4)

MSCI <- MSCIData[, 2]
MSCIs <- MSCIData[, 7]

MSCIData <- data.frame(as.Date(MSCIData[,1], format = "%d.%m.%Y"), MSCI, MSCIs)
colnames(MSCIData) <- cbind("Date", "MSCI", "MSCIs")
MSCIData <- MSCIData[order(MSCIData$Date),]
print("MSCI market data loaded")

#-------------------------------------------------------------------------------
# ECB data
#-------------------------------------------------------------------------------
ECBData <- read.xlsx(paste(dataDir, "EZBmeetings.xlsx", sep = ""), sheetName = "data", startRow = 1)

ECB <- ECBData[, 2]

ECBData <- data.frame(as.Date(ECBData[,1], format = "%d.%m.%Y"), ECB)
colnames(ECBData) <- cbind("Date", "ECBmeeting")
ECBData <- ECBData[order(ECBData$Date),]
print("ECB data loaded")

#-------------------------------------------------------------------------------
# Other SNB data
#-------------------------------------------------------------------------------
SNBData <- read.xlsx(paste(dataDir, "SNBcommunication.xlsx", sep = ""), sheetName = "data", startRow = 1)

SNBlb <- SNBData[, 8]
SNB.AnnouncBillsCHF <- SNBData[, 24]
SNB.AnnouncBillsUSD <- SNBData[, 25]

SNBData <- data.frame(as.Date(SNBData[,1], format = "%d.%m.%Y"), SNBlb, SNB.AnnouncBillsCHF, SNB.AnnouncBillsUSD)
colnames(SNBData) <- cbind("Date", "SNBlb","AnnouncBillsCHF","AnnouncBillsUSD")
SNBData <- SNBData[order(SNBData$Date),]
print("SNB data loaded")

#-------------------------------------------------------------------------------
# Save all data to disk
#-------------------------------------------------------------------------------
# Shorten to 2000 - today because we don't need other data anyway
AllData <- full_join(subset(SARONData, Date >= startExport), subset(EIDData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(LIBORData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(CORPData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(RevRepoData, Date >= startExport), by = "Date")
AllData <- left_join(AllData, subset(XRData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(BillsDaily, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(BillsDaily.d, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(GERData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(FRED, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(StockData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(MSCIData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(ECBData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(SNBData, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(Speeches, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(DataRs, Date >= startExport), by = "Date")
AllData <- full_join(AllData, subset(Auction.b, Date >= startExport), by = "Date")

AllData <- AllData[order(AllData$Date),]

# Remove inconsequential duplicates that were created
AllData <- AllData[duplicated(AllData$Date) == FALSE, ]

save(AllData, file = paste(dataDir, "DailyData.RData", sep = ""))

# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------