#-------------------------------------------------------------------------------
# 4) Descriptive analysis
#-------------------------------------------------------------------------------
# Fabio Canetg and Daniel Kaufmann (2022)
# Overnight rate and signalling effects of central bank bills
# European Economic Review, forthcoming
#-------------------------------------------------------------------------------


#-------------------------------------------------------------------------------
# 0) Preliminary commands, load packages and functions
#-------------------------------------------------------------------------------
rm(list=ls())
library(quantmod)
library(tsbox)
library(xlsx)
library(dplyr) 
library(ggplot2)
library(reshape2)
library(sandwich)
library(forecast)
library(extrafont)
library(stargazer)
loadfonts(device = "win")
source("SVARFunctions.R")

mainDir <- getwd()
outDir <- makeOutDir(mainDir, "/Results/DescriptiveStats")
dataDir <- paste(mainDir, "./Data/", sep = "")

myStart <- "2008-10-01"
myEnd   <- "2011-08-01"
myWidth <- 14
myHeight <- 11

#-------------------------------------------------------------------------------
# 1) Figure weekly sight deposits and SNB Bill volume
#-------------------------------------------------------------------------------
# Bills CHF data (note this data set is by instrument, but we need data set by day)
Data <- read.xlsx(paste(dataDir, "WeeklySightDeposits.xlsx", sep = ""), sheetName = "weekly sight deposits", startRow = 8)
SD <- data.frame(seq(as.Date("2008-01-01"), by = "weeks", length.out=length(Data[,9])), Data[, 9])
SD.w <- ts(SD[, 2], frequency=52, start=c(2008,1))
SD.w <- ts_xts(SD.w)

SDt <- data.frame(seq(as.Date("2008-01-01"), by = "weeks", length.out=length(Data[,11])), Data[, 11])
SDt.w <- ts(SDt[, 2], frequency=52, start=c(2008,1))
SDt.w <- ts_xts(SDt.w)

load(file=paste(dataDir, "DailyData.RData", sep = ""))
Sample <- AllData
Bills.d <- xts(Sample$Outstanding, order.by = as.Date(Sample$Date))
Bills.d <- ts_span(Bills.d, myStart, myEnd)

CHFEUR.d <- xts(Sample$CHFEUR, order.by = as.Date(Sample$Date))
CHFEUR.d <- ts_span(CHFEUR.d, myStart, myEnd)

SD.w <- ts_span(SD.w, myStart, myEnd)
SDt.w <- ts_span(SDt.w, myStart, myEnd)

g <- ts_ggplot(`Reserves domestic counterparties` = SD.w/1000, `CHF SNB Bills` = Bills.d/1000)+theme_minimal()
g <- g + ggplot2::scale_color_manual(values = c("indianred3", "lightgoldenrod3"))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.background = element_blank())+theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g + theme(panel.grid.major = element_line(colour = "black", linetype = "dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g + theme(text = element_text(family = "Palatino"))
g <- g + theme(legend.justification=c(1,0), legend.position=c(.55,.75))+theme(legend.title=element_blank())
g <- g + xlab("") + ylab("In billions")
g
ggsave(paste(outDir, "/BillsVolume.pdf", sep = ""), width = myWidth, height = myHeight, units="cm")
ggsave(paste(outDir, "/BillsVolume.svg", sep = ""), plot = g, width = myWidth, height = myHeight, units="cm")

# Pre-auction reserves and share of SNB Bills, safe for later on
Bills.m <- ts_frequency(Bills.d, to = "month", aggregate="mean", na.rm = TRUE)
SD.m    <- ts_frequency(SD.w, to = "month", aggregate="mean", na.rm = TRUE)
print(ts_c(SD.m, Bills.m, Bills.m/(SD.m+Bills.m)))
Pi.m <- Bills.m/(SD.m+Bills.m)

#-------------------------------------------------------------------------------
# 2) Volume alotted according to day of week
#-------------------------------------------------------------------------------
TempDays <- weekdays(Sample$Date)
TempDays[TempDays == "Monday"] <- "Other"
TempDays[TempDays == "Friday"] <- "Other"
TempDays[TempDays == "Wednesday"] <- "Other"
Data <- data.frame(Sample$Date, Sample$Allotment/1000, factor(TempDays, 
                                                              levels= c("Tuesday", "Thursday", "Other")))
colnames(Data) <- c("Date", "Allotment", "Weekday")
Data <- subset(Data, weekdays(Date) != "Saturday" & weekdays(Date) != "Sunday")
Data <- subset(Data, Date>=myStart & Date <= myEnd)
g <- ggplot(data=Data, aes(x=Date, y=Allotment, fill = Weekday)) +
  geom_bar(stat="identity", position="dodge", width=2.5) +theme_minimal()
g <- g + scale_fill_manual(values = c("indianred3", "lightgoldenrod3", "gray60"))
g <- g + theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g + theme(panel.grid.major = element_line(colour = "black",linetype="dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.background = element_blank())+theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g + theme(panel.grid.major = element_line(colour = "black", linetype = "dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g + theme(text = element_text(family = "Palatino"))
g <- g + xlab("") + ylab("In billions")
g <- g + theme(legend.justification=c(1,0), legend.position=c(.9,.65))+theme(legend.title=element_blank())
g
ggsave(paste(outDir, "/AllotmentDay.pdf", sep = ""), width = myWidth, height = myHeight, units="cm")
ggsave(paste(outDir, "/AllotmentDay.svg", sep = ""), plot = g, width = myWidth, height = myHeight, units="cm")


#-------------------------------------------------------------------------------
# 3) Volume outstanding SNB Bills according to term
#-------------------------------------------------------------------------------
load(file=paste(dataDir, "DailyData.RData", sep = ""))
Sample <- AllData

Data <- data.frame(Sample$Date, Sample$Out1M, Sample$Out3M, Sample$Out6M, Sample$Out12M)
print(Data)
colnames(Data) <- c("Date", "1M", "3M", "6M", "12M")
Data <- subset(Data, Date>= myStart & Date <= myEnd)
Data <- subset(Data, weekdays(Date) != "Saturday" & weekdays(Date) != "Sunday")
Data <- melt(Data, id.vars='Date')

g <- ggplot(Data, aes(Date, value/1000))
g <- g + geom_area(aes( fill= variable), position = 'stack')   +theme_minimal()+ scale_fill_manual(values = c("indianred3", "lightgoldenrod3", "gray60", "black", "yellowgreen"))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.background = element_blank())+theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g+ theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g+theme(panel.grid.major = element_blank()) + theme(panel.grid.minor = element_blank()) 
g <- g + theme(panel.grid.major = element_line(colour = "black", linetype = "dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g + theme(text = element_text(family = "Palatino"))
g <- g+xlab("") + ylab("In billions")
g <- g +  theme(legend.justification=c(1,0), legend.position=c(.45,.65))+theme(legend.title=element_blank())
g
ggsave(paste(outDir, "/SNBBillsTerm.pdf", sep = ""), width = myWidth, height = myHeight, units="cm")
ggsave(paste(outDir, "/SNBBillsTerm.svg", sep = ""), plot = g, width = myWidth, height = myHeight, units="cm")

#-------------------------------------------------------------------------------
# 4) Reverse repo bids and allotment
#-------------------------------------------------------------------------------
# Repo and Bills data
RepoData <- xlsx::read.xlsx(paste(dataDir, "RepoOperations.xlsx", sep = ""), stringsAsFactors = FALSE, sheetName = "Sheet1", startRow = 20)

# Do a plot of all the repo rates but color Bills with different colors
RevRepo <- subset(RepoData, Art == "Reverse Repo")
SNBBills <- subset(RepoData, Art == "SNB Bills")
Swaps <- subset(RepoData, Art == "Swaps")
unique(RevRepo$Date)
RevRepo$Gebote <- as.numeric(RevRepo$Gebote)
RevRepo$Zuteilung <- as.numeric(RevRepo$Zuteilung)
names(RevRepo)[names(RevRepo) == 'Laufzeit'] <- "Maturity reverse repos"

RevRepo <- subset(RevRepo, Date>=myStart & Date <= myEnd)

# Scatter plot
g <- ggplot(RevRepo, aes(x=`Gebote`/1000, y=`Zuteilung`/1000, colour = `Maturity reverse repos`, shape = `Maturity reverse repos`)) + geom_point(size = 2.5) + theme_minimal()
g <- g + coord_cartesian(xlim = c(0, 80), ylim =  c(0, 20))+ geom_abline(intercept = 0, slope = 1)
g <- g + scale_shape_manual(values = c(0, 16, 17, 2)) 
g <- g + scale_colour_manual(values = c("indianred3", "lightgoldenrod3", "gray60", "black"))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.background = element_blank())+theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g + theme(legend.justification=c(1,0), legend.position=c(.9,.5))
g <- g + theme(text = element_text(family = "Palatino"))
g <- g + theme(panel.grid.major = element_line(colour = "black",linetype="dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g + xlab("Bids (in billions)") + ylab("Allotment (in billions)")
g
ggsave(paste(outDir, "/RRepoBidsAllot.pdf", sep = ""), width = myWidth, height = myHeight, units="cm")
ggsave(paste(outDir, "/RRepoBidsAllot.svg", sep = ""), width = myWidth, height = myHeight, units="cm")

#-------------------------------------------------------------------------------
# 5) Reverse repo and SNB Bill yields
#-------------------------------------------------------------------------------
RevRepoAuction <- !is.na(RevRepo$Date)
RevRepoYield   <- RevRepo$Zins
RevRepoVolume   <- RevRepo$Zuteilung
RevRepoBids   <- RevRepo$Gebote

BillVolume   <- as.numeric(SNBBills$Zuteilung)
BillBids   <- as.numeric(SNBBills$Gebote)

SwapVolume   <- as.numeric(Swaps$Zuteilung)
SwapBids   <- as.numeric(Swaps$Gebote)

YieldRepo <- data.frame(RevRepo$Date, RevRepo$Zins, as.character(RevRepo$`Maturity reverse repos`), RevRepoVolume/1000, RevRepoBids/1000, (RevRepoBids-RevRepoVolume)/1000)
YieldBills <- data.frame(SNBBills$Date, SNBBills$Zins, as.character(SNBBills$Laufzeit),  BillVolume/1000, BillBids/1000, (BillBids-BillVolume)/1000)
YieldSwaps <- data.frame(Swaps$Date, SwapVolume/1000, SwapBids/1000, (SwapBids-SwapVolume)/1000)

colnames(YieldRepo) <- c("Date", "YieldRepo", "MaturityRepo", "VolumeRepo", "BidsRepo", "DiffRepo")
colnames(YieldBills) <- c("Date", "YieldBills", "MaturityBills", "VolumeBills", "BidsBills", "DiffBills")
colnames(YieldSwaps) <- c("Date", "VolumeSwaps", "BidsSwaps", "DiffSwaps")
YieldBills$MaturityBills <- as.character(YieldBills$MaturityBills)

is1M = (YieldBills$MaturityBills == "4W" | YieldBills$MaturityBills == "1W" | YieldBills$MaturityBills == NA | YieldBills$MaturityBills == "33T" | YieldBills$MaturityBills == "2W" | YieldBills$MaturityBills == "29T")
YieldBills$MaturityBills[is1M] = "1M"

is3M = (YieldBills$MaturityBills == "85T" | YieldBills$MaturityBills == "12W" )
YieldBills$MaturityBills[is3M] = "3M"

is6M = (YieldBills$MaturityBills == "24W" | YieldBills$MaturityBills == "169T")
YieldBills$MaturityBills[is6M] = "6M"

is12M = (YieldBills$MaturityBills == "337T" | YieldBills$MaturityBills == "48W")
YieldBills$MaturityBills[is12M] = "12M"

YieldBills <- data.frame(YieldBills, is1M, is3M, is6M, is12M)
YieldBills$is1M[is.na(YieldBills$is1M)] = FALSE
YieldBills$is6M[is.na(YieldBills$is6M)] = FALSE
YieldBills$is12M[is.na(YieldBills$is12M)] = FALSE

# Regressions Join data but only keep those days with an SNB Bill auction
AllData <- full_join(YieldRepo, YieldBills, by="Date")
AllData <- full_join(AllData, YieldSwaps, by="Date")
AllData$VolumeRepo[is.na(AllData$VolumeRepo)] <- 0
AllData$VolumeSwaps[is.na(AllData$VolumeSwaps)] <- 0
AllData$VolumeBills[is.na(AllData$VolumeBills)] <- 0

AllData$BidsRepo[is.na(AllData$BidsRepo)] <- 0
AllData$BidsSwaps[is.na(AllData$BidsSwaps)] <- 0
AllData$BidsBills[is.na(AllData$BidsBills)] <- 0

AllData <- subset(AllData, Date>=myStart & Date <= myEnd)

names(AllData)[names(AllData) == 'MaturityBills'] <- "Maturity SNB Bills"
# Plot over time
g <- ggplot(AllData, aes(x=`Date`, y=`YieldBills`, color = `Maturity SNB Bills`, shape = `Maturity SNB Bills`)) + geom_point()
g <- g + geom_point(data = AllData, aes(x = `Date`, y = `YieldRepo`, color = "Reverse repo", shape = "Reverse repo"))
g <- g+scale_shape_manual(values = c(0, 16, 17, 2, 1)) 
g <- g+scale_colour_manual(values = c("indianred3", "lightgoldenrod3", "gray60", "black", "yellowgreen"))
g <- g+ theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g+theme(panel.grid.major = element_line(colour = "black",linetype="dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.background = element_blank())+theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g+ theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g+theme(panel.grid.major = element_line(colour = "black",linetype="dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g+theme(text = element_text(family = "Palatino"))
g <- g+theme(legend.key = element_blank(), legend.background = element_blank())
g <- g+xlab("") + ylab("In %")
g <- g+scale_y_continuous(breaks=seq(0,1.25,.25))
g <- g +  theme(legend.justification=c(1,0), legend.position=c(.8,.45))
g
ggsave(paste(outDir, "/BillVsRepoTime.pdf", sep = ""), width = myWidth, height = myHeight, units="cm")
ggsave(paste(outDir, "/BillVsRepoTime.svg", sep = ""), width = myWidth, height = myHeight, units="cm")

# Only keep those days were Bills and SARON for scatter plot
AllData <- AllData[!is.na(AllData$YieldBills),]
AllData <- AllData[!is.na(AllData$YieldRepo),]

# Scatter plot
g <- ggplot(AllData, aes(x=`YieldRepo`, y=`YieldBills`, colour = `Maturity SNB Bills`, shape = `Maturity SNB Bills`)) + geom_point(size = 2.5) + theme_minimal()
g <- g+coord_cartesian(xlim = c(0, 1), ylim =  c(0, 1.25))+ geom_abline(intercept = 0, slope = 1)
g <- g+scale_y_continuous(breaks=seq(0,1.25,.25))+scale_x_continuous(breaks=seq(0,1,.25))
g <- g+scale_shape_manual(values = c(0, 16, 17, 2)) 
g <- g+scale_colour_manual(values = c("indianred3", "lightgoldenrod3", "gray60", "black"))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.background = element_blank())+theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g+ theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g + theme(legend.justification=c(1,0), legend.position=c(.9,.1))
g <- g+theme(text = element_text(family = "Palatino"))
g <- g+theme(panel.grid.major = element_line(colour = "black",linetype="dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g+xlab("Reverse repo yield (in %)") + ylab("SNB Bill marginal yield (in %)")
g
ggsave(paste(outDir, "/BillVsRepoAll.pdf", sep = ""), width = myWidth, height = myHeight, units="cm")
ggsave(paste(outDir, "/BillVsRepoAll.svg", sep = ""), width = myWidth, height = myHeight, units="cm")

#-------------------------------------------------------------------------------
# 6) Estimate the determinants of Bill yields
#-------------------------------------------------------------------------------
# Baseline regression all yields
YieldDeterm1 <- lm(YieldBills~YieldRepo, data = AllData)
summary(YieldDeterm1)
seYield1 <- NeweyWest(YieldDeterm1)

# Yield regression with maturities
YieldDeterm2 <- lm(YieldBills~YieldRepo+is3M+is6M+is12M, data = AllData)
summary(YieldDeterm2)
seYield2 <- NeweyWest(YieldDeterm2)

# Yield regression with maturities and bids
YieldDeterm3 <- lm(YieldBills~YieldRepo+is3M+is6M+is12M+
                     VolumeRepo+BidsRepo, data = AllData)
summary(YieldDeterm3)
seYield3 <- NeweyWest(YieldDeterm3)

# Yield regression with maturities and bids
YieldDeterm4 <- lm(YieldBills~YieldRepo+is3M+is6M+is12M+
                     VolumeRepo+BidsRepo+
                     VolumeBills+BidsBills, data = AllData)
summary(YieldDeterm4)
seYield4 <- NeweyWest(YieldDeterm4)

Results     <- list(YieldDeterm1, YieldDeterm2, YieldDeterm3, YieldDeterm4)
Results.se  <- list(sqrt(diag(NeweyWest(YieldDeterm1))), sqrt(diag(NeweyWest(YieldDeterm2))), sqrt(diag(NeweyWest(YieldDeterm3))), sqrt(diag(NeweyWest(YieldDeterm4))))
stargazer(Results, type = "text")

# Conlcusion, at least for those observations, the yield on SNB Bills was largely pre-determined
stargazer(Results,
          se=Results.se,
          out = paste(outDir, "/BillYieldRegs.tex", sep = ""), 
          label = "tab:BillYieldReg",
          digits = 2,
          style = "aer",
          float = FALSE,
          colnames = FALSE,
          title = "Determinants of SNB Bill yield",
          dep.var.labels.include = FALSE,
          column.labels   = c("SNB Bill yields (in \\%)"),
          column.separate = c(4),
          covariate.labels = c("Reverse repo yield (in \\%)", 
                               "3M SNB Bill (dummy)", "6M SNB Bill (dummy)", "12M SNB Bill (dummy)",
                               "Reverse repo allotment (in bio.)",
                               "Reverse repo bids (in bio.)",
                               "SNB Bill allotment (in bio.)",
                               "SNB Bill bids (in bio.)"
          ),  
          omit.table.layout = "n",
          column.sep.width = "0pt",
          omit.stat = c("f", "adj.rsq", "res.dev", "ser"), 
          model.numbers = FALSE, 
          type = "latex")


stargazer(Results,
          se=Results.se,
          out = paste(outDir, "/BillYieldRegs.txt", sep = ""), 
          label = "tab:BillYieldReg",
          digits = 2,
          style = "aer",
          float = FALSE,
          colnames = FALSE,
          title = "Determinants of SNB Bill yield",
          dep.var.labels.include = FALSE,
          column.labels   = c("SNB Bill yields (in \\%)"),
          column.separate = c(4),
          covariate.labels = c("Reverse repo yield (in \\%)", 
                               "3M SNB Bill (dummy)", "6M SNB Bill (dummy)", "12M SNB Bill (dummy)",
                               "Reverse repo allotment (in bio.)",
                               "Reverse repo bids (in bio.)",
                               "SNB Bill allotment (in bio.)",
                               "SNB Bill bids (in bio.)"
          ),  
          omit.table.layout = "n",
          column.sep.width = "0pt",
          omit.stat = c("f", "adj.rsq", "res.dev", "ser"), 
          model.numbers = FALSE, 
          type = "text")


#-------------------------------------------------------------------------------
# 7) SNB Bills and money market rates
#-------------------------------------------------------------------------------
load(file=paste(dataDir, "DailyData.RData", sep = ""))
Sample <- AllData
Sample$Yield7D[Sample$Yield7D == 0] <- NA
Sample$Yield1M[Sample$Yield1M == 0] <- NA

Data <- data.frame(Sample$Date, Sample$SAR1W.noon,  Sample$SAR1M.noon, Sample$SAR3M.noon, 
                   Sample$Yield1M, Sample$Yield3M, Sample$Yield6M, Sample$Yield12M,
                   Sample$Out1M, Sample$Out3M, Sample$Out6M, Sample$Out12M, Sample$SARON.noon)
colnames(Data) <- c("Date", "SAR1W", "SAR1M", "SAR3M", 
                    "Yield1M", "Yield3M", "Yield6M", "Yield12M",
                    "Out1M", "Out3M", "Out6M", "Out12M", "SARON")
Data <- subset(Data, Date>= myStart & Date <= myEnd)
Data <- subset(Data, weekdays(Date) != "Saturday" & weekdays(Date) != "Sunday")

Yield1M = xts(Data$Yield1M, order.by=as.Date(Data$Date))
Yield3M = xts(Data$Yield3M, order.by=as.Date(Data$Date))
Yield6M = xts(Data$Yield6M, order.by=as.Date(Data$Date))
Yield12M = xts(Data$Yield12M, order.by=as.Date(Data$Date))
Yield1M[Yield1M==0] = NA
Yield3M[Yield3M==0] = NA
Yield6M[Yield6M==0] = NA
Yield12M[Yield12M==0] = NA

IRS1W = xts(Data$IRS1W, order.by=as.Date(Data$Date))
SAR1W = xts(Data$SAR1W, order.by=as.Date(Data$Date))
SAR1M = xts(Data$SAR1M, order.by=as.Date(Data$Date))
SAR3M = xts(Data$SAR3M, order.by=as.Date(Data$Date))
SARON = xts(Data$SARON, order.by=as.Date(Data$Date))

Out1M = xts(Data$Out1M, order.by=as.Date(Data$Date))
Out3M = xts(Data$Out3M, order.by=as.Date(Data$Date))
Out6M = xts(Data$Out6M, order.by=as.Date(Data$Date))
Out12M = xts(Data$Out12M, order.by=as.Date(Data$Date))

# 1) Total liabilities
Liab <- read.xlsx(paste(dataDir, "LiabilitiesSNB.xlsx", sep = ""), sheetName = "Report", startRow = 21)
Total <- xts(Liab[, 14], order.by = as.Date(paste(Liab[, 1], "-01", sep = "")))
Reserves <- xts(Liab[, 5]+Liab[, 3], order.by = as.Date(paste(Liab[, 1], "-01", sep = "")))

# 2) Monthly values outsanding SNB BIlls
Out1M.w <- ts_frequency(Out1M, to = "month", aggregate = "last", na.rm = TRUE)
Out3M.w <- ts_frequency(Out3M, to = "month", aggregate = "last", na.rm = TRUE)
Out6M.w <- ts_frequency(Out6M, to = "month", aggregate = "last", na.rm = TRUE)
Out12M.w <- ts_frequency(Out12M, to = "month", aggregate = "last", na.rm = TRUE)

# 3) Monthly values of interest rates
Yield1M.w <- ts_frequency(Yield1M, to = "month", aggregate = "mean", na.rm = TRUE)
Yield3M.w <- ts_frequency(Yield3M, to = "month", aggregate = "mean", na.rm = TRUE)
Yield6M.w <- ts_frequency(Yield6M, to = "month", aggregate = "mean", na.rm = TRUE)
Yield12M.w <- ts_frequency(Yield12M, to = "month", aggregate = "mean", na.rm = TRUE)
IRS1W.w <- ts_frequency(IRS1W, to = "month", aggregate = "mean", na.rm = TRUE)
SAR1W.w <- ts_frequency(SAR1W, to = "month", aggregate = "mean", na.rm = TRUE)
SAR1M.w <- ts_frequency(SAR1M, to = "month", aggregate = "mean", na.rm = TRUE)
SAR3M.w <- ts_frequency(SAR3M, to = "month", aggregate = "mean", na.rm = TRUE)
SARON.w <- ts_frequency(SARON, to = "month", aggregate = "mean", na.rm = TRUE)

Yield.w = ts_c(Yield1M.w,Yield3M.w,Yield6M.w,Yield12M.w)
Pi.w <- (Out1M.w+Out3M.w+Out6M.w+Out12M.w)/(Reserves+Out1M.w+Out3M.w+Out6M.w+Out12M.w)
Pi.w <- ts_span(Pi.w, ts_summary(Yield1M.w)$start, ts_summary(Yield1M.w)$end)
Yield.w <- xts(rowSums(Yield.w, na.rm = TRUE), order.by = index(Pi.w))

Pi.w2 <- (Out1M.w+Out3M.w+Out6M.w+Out12M.w)/(Total)
Pi.w2 <- ts_span(Pi.w2, ts_summary(Yield1M.w)$start, ts_summary(Yield1M.w)$end)

SARON.w <- ts_span(SARON.w, myStart, myEnd)
SAR1W.w <- ts_span(SAR1W.w, myStart, myEnd)
SAR3M.w <- ts_span(SAR3M.w, myStart, myEnd)
Pi.w <- ts_span(Pi.w, myStart, myEnd)
Yield.w <- ts_span(Yield.w, myStart, myEnd)

# Do this also for overall (uses Pi.m from beginning now)
g <- ts_ggplot(`SNB Bills as a share of all SNB liabilities` = Pi.w, `Marginal yield SNB Bills` = Yield.w, `SARON` = SARON.w, `SAR3M` = SAR3M.w)+theme_minimal()
g <- g + ggplot2::scale_color_manual(values = c("indianred3", "lightgoldenrod3", "gray60", "yellowgreen"))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.line = element_line(colour = "black"))+ theme(panel.background = element_blank())+theme(panel.border = element_rect(linetype = "solid", colour = "black", fill = NA))
g <- g + theme(axis.text.x = element_text(colour = "black"), axis.text.y = element_text(colour = "black"))
g <- g + theme(panel.grid.major =element_blank()) + theme(panel.grid.minor = element_blank()) 
g <- g +theme(legend.justification=c(1,0), legend.position=c(.6,.65))+theme(legend.title=element_blank())
g <- g + theme(panel.grid.major = element_line(colour = "black",linetype="dotted", size=0.1)) + theme(panel.grid.minor = element_blank()) 
g <- g+scale_y_continuous(breaks=seq(0,1.5,.25))
g <- g + theme(text = element_text(family = "Palatino"))
g <- g + xlab("") + ylab("In %, share")
g
ggsave(paste(outDir, "/YieldAndPi.pdf", sep = ""), width = myWidth, height = myHeight, units="cm")
ggsave(paste(outDir, "/YieldAndPi.svg", sep = ""), plot = g, width = myWidth, height = myHeight, units="cm")


corr1 <- cor(ts_c(Yield.w, SAR3M.w, Pi.m))
corr2 <- cor(ts_c(ts_diff(Yield.w), ts_diff(SAR3M.w), ts_diff(Pi.m)), use="complete.obs")

write.table(corr1, paste(outDir, "/CorrelationsLevel.txt", sep = ""))
write.table(corr2, paste(outDir, "/CorrelationsDiff.txt", sep = ""))

# Calculations predictions
Predictions <- data.frame(index(Pi.w), Pi.w, Yield.w, Pi.w*Yield.w, SAR1W.w, SAR3M.w)
Predictions
write.table(Predictions, paste(outDir, "/Predictions.txt", sep = ""))


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
