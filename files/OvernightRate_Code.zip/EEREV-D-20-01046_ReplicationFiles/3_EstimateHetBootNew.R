#-------------------------------------------------------------------------------
# 3) Main empirical estimates
#-------------------------------------------------------------------------------
# Fabio Canetg and Daniel Kaufmann (2022)
# Overnight rate and signalling effects of central bank bills
# European Economic Review, forthcoming
#-------------------------------------------------------------------------------
# NOTES: 
# - Heteroskedasticity estimator following Nakamura/Steinsson (2018), and Rigobon (2003)
#   Extension to using multiple moments, zero restrictions, and dynamic effects
# - Implemented covariance estimator and bootstrap of confidence interval
# - Controls for persistence via local projections or VAR
# - Now exploits parallel computing capabilities
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# 0) Preliminary commands, load packages and functions, Settings
#-------------------------------------------------------------------------------
cat("\014") 
rm(list=ls())
library(AER)
library(dplyr)
library(lubridate)
library(Rfast)
library(ggplot2)
library(gridExtra)
library(xtable)
library(xts)
library(extrafont)
library(xlsx)
library(stargazer)
library(doParallel)
loadfonts(device = "win")
source("SVARFunctions.R")

# For parallel computing, register number of cores
noCores <- detectCores()
registerDoParallel(cores = noCores)

# Create results folder and settings for outputs
mainDir <- getwd()
outDir <- makeOutDir(mainDir, "/Results/EstimateHetBoot")
dataDir <- paste(mainDir, "./Data/", sep = "")

# OVerall settings
figWidth3 <- 24
figWidth1 <- figWidth3/3
figWidth2 <- figWidth3/3*2
figHeight1 <- 7.5
figHeight2 <- 2*figHeight1

# --------------------------------------------------------------
# 2) Estimates models with actual data
# --------------------------------------------------------------
# A) Load daily data
# --------------------------------------------------------------
load(file=paste(dataDir, "DailyData.RData", sep = ""))
myStart <- "2008-10-20"
myEnd   <- "2011-07-31"
Sample  <- na.locf(AllData, na.rm = FALSE, maxgap = 5)   # Note fills missing values with previous value but only up to 4 days

# Remove weekends and missing values beforehand (otherwise problem with lags)
isSun <- weekdays(Sample$Date) == "Sunday"
Sample <- Sample[!isSun, ]
isSat <- weekdays(Sample$Date) == "Saturday"
Sample <- Sample[!isSat, ]

# Transform important events to logical
Sample$Auction <- Sample$Auction == TRUE
Sample$Auction[is.na(Sample$Auction)] = FALSE

Sample$Payment <- Sample$Payment == TRUE
Sample$AuctionGMBF <- Sample$AuctionGMBF==1
Sample$AuctionEid <- Sample$AuctionEid == 1
Sample$AuctionRepoUSD <- Sample$AuctionRepoUSD == 1
Sample$Payment.d <- !is.na(Sample$Payment.d)
Sample$Auction.d <- !is.na(Sample$Auction.d)
Sample$SNBlb <- Sample$SNBlb == 1
Sample$ECBmeeting <- Sample$ECBmeeting == 1

Sample$Payment[is.na(Sample$Payment)] <- FALSE
Sample$AuctionGMBF[is.na(Sample$AuctionGMBF)] <- FALSE
Sample$AuctionEid[is.na(Sample$AuctionEid)] <- FALSE
Sample$AuctionRepoUSD[is.na(Sample$AuctionRepoUSD)] <- FALSE
Sample$Payment.d[is.na(Sample$Payment.d)] <- FALSE
Sample$Auction.d[is.na(Sample$Auction.d)] <- FALSE
Sample$SNBlb[is.na(Sample$SNBlb)] <- FALSE
Sample$Speech[is.na(Sample$Speech)] <- FALSE
Sample$DataR[is.na(Sample$DataR)] <- FALSE
Sample$ECBmeeting[is.na(Sample$ECBmeeting)] <- FALSE
Sample$Outstanding[is.na(Sample$Outstanding)] <- 0

Sample$AuctionGMBF2 <- (Sample$AuctionGMBF==TRUE)&(Sample$Auction==FALSE)

Sample$RRepoAuction[is.na(Sample$RRepoAuction)] <- FALSE
Sample$BillsAuction[is.na(Sample$BillsAuction)] <- FALSE
Sample$SwapAuction[is.na(Sample$SwapAuction)] <- FALSE
Sample$NRepoAuction[is.na(Sample$NRepoAuction)] <- FALSE

Sample$RRepoAuction = Sample$RRepoAuction == 1
Sample$NRepoAuction = Sample$NRepoAuction == 1
Sample$SwapAuction = Sample$SwapAuction == 1

# Set up data
MainEv  <- Sample$Auction            # The auction is shock 1 (maybe rename to "Event")
OtherEv <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEv==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

MainEvRR  <- Sample$RRepoAuction            # The auction is shock 1 (maybe rename to "Event")
OtherEvRR <- ((Sample$SwapAuction|Sample$Auction)&MainEvRR==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

MainEvLong  <- (Sample$Auction12M==TRUE | Sample$Auction6M==TRUE)
MainEvShort  <- (Sample$Auction1M==TRUE | Sample$Auction3M==TRUE)
OtherEvLong <- ((Sample$SwapAuction|Sample$RRepoAuction|MainEvShort)&MainEvLong==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvShort <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEvShort==FALSE)|MainEvLong|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

OtherEvBroad1 <- Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad2 <- Sample$AuctionRepoUSD|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad3 <- Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad4 <- ((Sample$SwapAuction)&MainEv==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad5 <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEv==FALSE)|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OtherEvBroad6 <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEv==FALSE)|Sample$Speech|Sample$DataR|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

MainEvPay  <- Sample$Payment             # The auction is shock 1 (maybe rename to "Event")
OtherEvPay <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEvPay==FALSE)|Sample$AuctionGMBF|Sample$Auction|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb

MainEvUSD  <- Sample$Auction.d             # The auction is shock 1 (maybe rename to "Event")
OtherEvUSD <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEvUSD==FALSE)|Sample$Auction|Sample$AuctionGMBF|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$ECBmeeting|Sample$SNBlb

MainEvGMBF  <- ((Sample$AuctionGMBF)&MainEv==FALSE)             # The auction is shock 1 (maybe rename to "Event")
OtherEvGMBF <- ((Sample$SwapAuction|Sample$RRepoAuction)&MainEvGMBF==FALSE)|Sample$Auction|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$ECBmeeting|Sample$SNBlb

# Compute (log) changes of the variables
CHFEUR <- ((log(Sample$CHFEUR)) - lag(log(Sample$CHFEUR), 1))*100
CHFUSD <- ((log(Sample$CHFUSD)) - lag(log(Sample$CHFUSD), 1))*100
CHFJPY <- ((log(Sample$CHFJPY)) - lag(log(Sample$CHFJPY), 1))*100
CHFTW  <- ((log(Sample$CHFTW)) - lag(log(Sample$CHFTW), 1))*100

USDEUR <- (log(Sample$USDEUR) - lag(log(Sample$USDEUR), 1))*100
USDJPY <- (log(Sample$USDJPY) - lag(log(Sample$USDJPY), 1))*100
USDGBP <- (log(Sample$USDGBP) - lag(log(Sample$USDGBP), 1))*100

USDEUR.l1 <- lag((log(Sample$USDEUR) - lag(log(Sample$USDEUR), 1))*100, 1)
USDJPY.l1 <- lag((log(Sample$USDJPY) - lag(log(Sample$USDJPY), 1))*100, 1)
USDGBP.l1 <- lag((log(Sample$USDGBP) - lag(log(Sample$USDGBP), 1))*100, 1)
USDEUR.f1 <- lead((log(Sample$USDEUR) - lag(log(Sample$USDEUR), 1))*100, 1)
USDJPY.f1 <- lead((log(Sample$USDJPY) - lag(log(Sample$USDJPY), 1))*100, 1)
USDGBP.f1 <- lead((log(Sample$USDGBP) - lag(log(Sample$USDGBP), 1))*100, 1)

MSCI  <- ((log(Sample$MSCI)) - lag(log(Sample$MSCI), 1))*100
SPI     <- ((log(Sample$SPI)) - lag(log(Sample$SPI), 1))*100
SMI     <- ((log(Sample$SMI)) - lag(log(Sample$SMI), 1))*100
VIXEUR  <- (Sample$VIXEUR) - lag(Sample$VIXEUR, 1)
VIXCH   <- (Sample$VIXCH) - lag(Sample$VIXCH, 1)
ESTXX   <- ((log(Sample$ESTXX)) - lag(log(Sample$ESTXX), 1))*100
ESTXX.l1 <- lag(((log(Sample$ESTXX)) - lag(log(Sample$ESTXX), 1))*100, 1)
ESTXX.f1 <- lead(((log(Sample$ESTXX)) - lag(log(Sample$ESTXX), 1))*100, 1)

SP500   <- ((log(Sample$SP500)) - lag(log(Sample$SP500), 1))*100
SP500.l1 <- lag(((log(Sample$SP500)) - lag(log(Sample$SP500), 1))*100, 1)
SP500.f1 <- lead(((log(Sample$SP500)) - lag(log(Sample$SP500), 1))*100, 1)

SARON     <- (Sample$SARON) - lag(Sample$SARON, 1)
SAR1W     <- (Sample$SAR1W) - lag(Sample$SAR1W, 1)
SAR2W     <- (Sample$SAR2W) - lag(Sample$SAR2W, 1)
SAR3M     <- (Sample$SAR3M) - lag(Sample$SAR3M, 1)
LIB3M     <- (Sample$LIB3M)  - lag(Sample$LIB3M, 1)
EID2Y     <- (Sample$EID2Y) - lag(Sample$EID2Y, 1)
EID8Y     <- Sample$EID8Y - lag(Sample$EID8Y, 1)
EID10Y    <- Sample$EID10Y - lag(Sample$EID10Y, 1)

TSPR1 <- EID8Y - LIB3M
TSPR2 <- EID8Y - EID2Y

US8Y     <- Sample$US8Y - lag(Sample$US8Y, 1)
GER10Y     <- Sample$GER10Y - lag(Sample$GER10Y, 1)
FFR      <- Sample$FFR - lag(Sample$FFR, 1)
EONIA    <- Sample$EONIA - lag(Sample$EONIA, 1)
US8Y.l1     <- lag(Sample$US8Y - lag(Sample$US8Y, 1), 1)
GER10Y.l1     <- lag(Sample$GER10Y - lag(Sample$GER10Y, 1), 1)
FFR.l1      <- lag(Sample$FFR - lag(Sample$FFR, 1), 1)
EONIA.l1    <- lag(Sample$EONIA - lag(Sample$EONIA, 1), 1)
US8Y.f1     <- lead(Sample$US8Y - lag(Sample$US8Y, 1), 1)
GER10Y.f1     <- lead(Sample$GER10Y - lag(Sample$GER10Y, 1), 1)
FFR.f1      <- lead(Sample$FFR - lag(Sample$FFR, 1), 1)
EONIA.f1    <- lead(Sample$EONIA - lag(Sample$EONIA, 1), 1)

CPFOR8Y   <- (Sample$CPFOR8Y) - lag(Sample$CPFOR8Y, 1)
CPHIG8Y   <- (Sample$CPHIG8Y) - lag(Sample$CPHIG8Y, 1)
CPLOW8Y   <- (Sample$CPLOW8Y) - lag(Sample$CPLOW8Y, 1)

# Construct proxy for risk premia etc.
RPLOW <- (Sample$CPLOW8Y-Sample$EID8Y) - lag(Sample$CPLOW8Y-Sample$EID8Y, 1)
RRLOW <- (Sample$CPLOW8Y-Sample$CPFOR8Y) - lag(Sample$CPLOW8Y-Sample$CPFOR8Y, 1) - RPLOW
PI    <- (Sample$CPLOW8Y) - lag(Sample$CPLOW8Y, 1) - RPLOW - RRLOW
RPHIG <- (Sample$CPHIG8Y-Sample$EID8Y) - lag(Sample$CPHIG8Y-Sample$EID8Y, 1)
RRHIG <- (Sample$CPHIG8Y-Sample$CPFOR8Y) - lag(Sample$CPHIG8Y-Sample$CPFOR8Y, 1) - RPLOW
RPMID <- (Sample$CPMID8Y-Sample$EID8Y) - lag(Sample$CPMID8Y-Sample$EID8Y, 1)
RRMID <- (Sample$CPMID8Y-Sample$CPFOR8Y) - lag(Sample$CPMID8Y-Sample$CPFOR8Y, 1) - RPLOW

# Compute repo yield on same day (or 5 days before) as auction
RRepoYield <- Sample$RRepoYield
RRepoYield[is.na(RRepoYield)] <- 0
RRepoAllot <- Sample$RRepoAllot
RRepoAllot[is.na(RRepoAllot)] <- 0
RRepoAllot <- lead(RRepoAllot, 1)
RRepoYield <- lead(RRepoYield, 1)

# Collect everything and shorten sample
Date <- Sample$Date
Data <- data.frame(Date, US8Y, GER10Y, FFR, EONIA, US8Y.l1, GER10Y.l1, FFR.l1, EONIA.l1, US8Y.f1, GER10Y.f1, FFR.f1, EONIA.f1, 
                   SP500, SP500.l1, SP500.f1, ESTXX.f1, ESTXX.l1,
                   USDGBP, USDJPY, USDEUR,USDGBP.l1, USDJPY.l1, USDEUR.l1,USDGBP.f1, USDJPY.f1, USDEUR.f1,
                   MainEvRR, OtherEvRR, SAR2W, OtherEvBroad5,OtherEvBroad6,  
                   RPLOW, RRLOW, RPHIG, RRHIG, RRMID, RPMID, PI, SAR3M, RRepoYield, RRepoAllot, 
                   SARON, CHFEUR, CHFUSD, VIXEUR,  CHFJPY, SMI, MSCI, SPI, CHFEUR, CHFTW, VIXCH, ESTXX,
                   LIB3M, SAR1W, EID2Y, EID8Y, EID10Y,TSPR1,TSPR2, 
                   MainEv, OtherEv, 
                   OtherEvBroad1, OtherEvBroad2, OtherEvBroad3, OtherEvBroad4, MainEvLong, OtherEvLong, MainEvShort, OtherEvShort, MainEvPay, OtherEvPay, MainEvUSD, OtherEvUSD, MainEvGMBF, OtherEvGMBF)

# Shorten to actual sample
Data <- subset(Data, as.Date(Date) >= myStart & as.Date(Date) <= myEnd)

IntData <- data.frame(Data$US8Y, Data$GER10Y, Data$FFR, Data$EONIA, Data$USDGBP, Data$USDJPY, Data$USDEUR, Data$ESTXX, Data$SP500)
PCX = prcomp(IntData)
Data$PC1 <- PCX$x[,"PC1"]
Data$PC2 <- PCX$x[,"PC2"]
Data$PC3 <- PCX$x[,"PC3"]
Data$PC4 <- PCX$x[,"PC4"]
Data$PC5 <- PCX$x[,"PC5"]
Data$PC6 <- PCX$x[,"PC6"]

# Compute residuals excluding global factors.
ResSARON <- lm(SARON~PC1+PC2+PC3, data = Data, na.action="na.exclude")
summary(ResSARON)
Data$SARONRes2 <- residuals(ResSARON)

# Compute residuals excluding global factors
ResEID8Y <- lm(EID8Y~PC1+PC2+PC3, data = Data, na.action="na.exclude")
summary(ResEID8Y)
Data$EID8YRes2 <- residuals(ResEID8Y)

# Compute residuals excluding global factors
ResSMI <- lm(SMI~PC1+PC2+PC3, data = Data, na.action="na.exclude")
summary(ResSMI)
Data$SMIRes2 <- residuals(ResSMI)

# Compute residuals excluding global factors
ResCHFTW <- lm(CHFTW~PC1+PC2+PC3, data = Data, na.action="na.exclude")
summary(ResCHFTW)
Data$CHFTWRes2 <- residuals(ResCHFTW)


# --------------------------------------------------------------
# Table 1: Baseline
# --------------------------------------------------------------
P <- 1        # Number of lags in local projection
k <- 5        # Block size
B <- 8000     # 8000 Number of bootstrap replications (1 means no bootstrap)
H <- 0        # Horizon IRF
useCumulative <- TRUE
useParametric <- FALSE
EventDays <- "MainEv"
OtherDays <- "OtherEv"
EndVar <- c("SARON", "SMI", "CHFTW", "EID8Y")
SignRest <- c(1, -1)
ExoVar <- c("FFR.l1", "USDEUR.l1", "US8Y.l1", "SP500.l1")


# Estimate model
Estim  <- estimateIRFHetLP(Data, EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]]
VEv <- Estim[[2]]
e2 <- Estim[[3]]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
Shocks <- c(1, 2)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "SMI", "CHFTW")
Results <- array(NA, c((length(ExpVars)+4)*4, 8))
Results2 <- array(NA, c((length(ExpVars)+4)*4, 8))

i <- 1
for (vars in ExpVars){
  for (shocks in Shocks){
    
    Draws <- PsiHet[vars, shocks, , ]
    
    # Calculate mean
    Mean <- mean(Draws, na.rm = TRUE)
    
    # Calculate 95% and 90% CI
    CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
    
    if (vars == "SMI" & shocks == 2){
      # Calculate share identified
      isident2 <- as.matrix(c(mean(!is.na(Draws))))
    }
    if (vars == "SARON" & shocks == 1){
      # Calculate share identified
      isident1 <- as.matrix(c(mean(!is.na(Draws))))
    }
    
    # Collect the results
    Results[i*3-3+1, (shocks-1)*2+1] <- Mean
    Results[i*3-3+2, ((shocks-1)*2+1):((shocks-1)*2+2)] <- CI[3:4]
    Results[i*3-3+3, ((shocks-1)*2+1):((shocks-1)*2+2)] <- CI[1:2]
    
  }
  
  # Calculate mean
  Mean <- mean(VEv[vars, 1 ,1, ], na.rm = TRUE)
  Mean2 <- mean(VEv[vars, 2 , 1, ], na.rm = TRUE)
  Mean3 <- mean(VEv[vars, 3 , 1, ], na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(VEv[vars, 1 ,1, ], na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(VEv[vars, 2 ,1, ], na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(VEv[vars, 3 ,1, ], na.rm = TRUE, probs = CIlev)
  
  # Collect the results
  Results2[i*3-3+1, 1] <- Mean
  Results2[i*3-3+2, 1:2] <- CI[3:4]
  Results2[i*3-3+3, 1:2] <- CI[1:2]
  
  Results2[i*3-3+1, 3] <- Mean2
  Results2[i*3-3+2, 3:4] <- CI2[3:4]
  Results2[i*3-3+3, 3:4] <- CI2[1:2]
  
  Results2[i*3-3+1, 5] <- Mean3
  Results2[i*3-3+2, 5:6] <- CI3[3:4]
  Results2[i*3-3+3, 5:6] <- CI3[1:2]
  
  i <- i+1 
}

N <- length(ExpVars)
# Interest rate shock
Results[N*3-3+8, 1] <- isident1
Results[N*3-3+9, 1] <- length(Data$Date)
Results[N*3-3+10, 1] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[N*3-3+11, 1] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

# Expectation shock
Results[N*3-3+8, 3] <- isident2
Results[N*3-3+9, 3] <- length(Data$Date)
Results[N*3-3+10, 3] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[N*3-3+11, 3] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)
rownames(Results2) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results2)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/OrthogonalizedResults.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
write.xlsx(Results[(N*3-3+8):(N*3-3+12),], paste(outDir, "/OrthogonalizedDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
# Export the results
write.xlsx(Results2, paste(outDir, "/OrthogonalizedVDec.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)


# --------------------------------------------------------------
# Table 2: Risk premium, real rate and inflation expectations
# --------------------------------------------------------------
EndVar1 <- c("SARON", "SMI", "CHFTW", "EID8Y", "RRLOW", "RPLOW", "PI")
Estim  <- estimateIRFHetLP(Data, EventDays, OtherDays, EndVar1, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]]
VEv <- Estim[[2]]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
Shocks <- c(1, 2)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "RRLOW","RPLOW", "PI", "SMI", "CHFTW")
Results <- array(NA, c((length(ExpVars)+4)*4, 12))
Results2 <- array(NA, c((length(ExpVars)+4)*4, 12))

i <- 1
for (vars in ExpVars){
  for (shocks in Shocks){
    
    Draws <- PsiHet[vars, shocks, , ]
    
    # Calculate mean
    Mean <- mean(Draws, na.rm = TRUE)
    
    # Calculate 95% and 90% CI
    CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
    
    if (vars == "SMI" & shocks == 2){
      # Calculate share identified
      isident2 <- as.matrix(c(mean(!is.na(Draws))))
    }
    if (vars == "SARON" & shocks == 1){
      # Calculate share identified
      isident1 <- as.matrix(c(mean(!is.na(Draws))))
    }
    
    # Collect the results
    Results[i*3-3+1, (shocks-1)*2+1] <- Mean
    Results[i*3-3+2, ((shocks-1)*2+1):((shocks-1)*2+2)] <- CI[3:4]
    Results[i*3-3+3, ((shocks-1)*2+1):((shocks-1)*2+2)] <- CI[1:2]
    
  }
  
  # Calculate mean
  Mean <- mean(VEv[vars, 1 ,1, ], na.rm = TRUE)
  Mean2 <- mean(VEv[vars, 2 , 1, ], na.rm = TRUE)
  Mean3 <- mean(VEv[vars, 3 , 1, ], na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(VEv[vars, 1 ,1, ], na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(VEv[vars, 2 ,1, ], na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(VEv[vars, 3 ,1, ], na.rm = TRUE, probs = CIlev)
  
  # Collect the results
  Results2[i*3-3+1, 1] <- Mean
  Results2[i*3-3+2, 1:2] <- CI[3:4]
  Results2[i*3-3+3, 1:2] <- CI[1:2]
  
  Results2[i*3-3+1, 3] <- Mean2
  Results2[i*3-3+2, 3:4] <- CI2[3:4]
  Results2[i*3-3+3, 3:4] <- CI2[1:2]
  
  Results2[i*3-3+1, 5] <- Mean3
  Results2[i*3-3+2, 5:6] <- CI3[3:4]
  Results2[i*3-3+3, 5:6] <- CI3[1:2]
  
  i <- i+1 
}

N <- length(ExpVars)
# Interest rate shock
Results[N*3-3+8, 1] <- isident1
Results[N*3-3+9, 1] <- length(Data$Date)
Results[N*3-3+10, 1] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[N*3-3+11, 1] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

# Expectation shock
Results[N*3-3+8, 3] <- isident2
Results[N*3-3+9, 3] <- length(Data$Date)
Results[N*3-3+10, 3] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[N*3-3+11, 3] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)
rownames(Results2) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results2)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/OrthogonalizedRiskPremiumResults.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
write.xlsx(Results[(N*3-3+8):(N*3-3+12),], paste(outDir, "/OrthogonalizedRiskPremiumDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
# Export the results
write.xlsx(Results2, paste(outDir, "/OrthogonalizedRiskPremiumVDec.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)


# --------------------------------------------------------------
# Table 3: Settlement day shock
# --------------------------------------------------------------
Estim  <- estimateIRFHetLP(Data, "MainEvPay", "OtherEvPay", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]]
VEv <- Estim[[2]]
e2 <- Estim[[3]]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
Shocks <- c(1, 2)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "SMI", "CHFTW")
Results <- array(NA, c((length(ExpVars)+4)*4, 8))
Results2 <- array(NA, c((length(ExpVars)+4)*4, 8))

i <- 1
for (vars in ExpVars){
  for (shocks in Shocks){
    
    Draws <- PsiHet[vars, shocks, , ]
    
    # Calculate mean
    Mean <- mean(Draws, na.rm = TRUE)
    
    # Calculate 95% and 90% CI
    CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
    
    if (vars == "SMI" & shocks == 2){
      # Calculate share identified
      isident2 <- as.matrix(c(mean(!is.na(Draws))))
    }
    if (vars == "SARON" & shocks == 1){
      # Calculate share identified
      isident1 <- as.matrix(c(mean(!is.na(Draws))))
    }
    
    # Collect the results
    Results[i*3-3+1, (shocks-1)*2+1] <- Mean
    Results[i*3-3+2, ((shocks-1)*2+1):((shocks-1)*2+2)] <- CI[3:4]
    Results[i*3-3+3, ((shocks-1)*2+1):((shocks-1)*2+2)] <- CI[1:2]
    
  }
  
  # Calculate mean
  Mean <- mean(VEv[vars, 1 ,1, ], na.rm = TRUE)
  Mean2 <- mean(VEv[vars, 2 , 1, ], na.rm = TRUE)
  Mean3 <- mean(VEv[vars, 3 , 1, ], na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(VEv[vars, 1 ,1, ], na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(VEv[vars, 2 ,1, ], na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(VEv[vars, 3 ,1, ], na.rm = TRUE, probs = CIlev)
  
  # Collect the results
  Results2[i*3-3+1, 1] <- Mean
  Results2[i*3-3+2, 1:2] <- CI[3:4]
  Results2[i*3-3+3, 1:2] <- CI[1:2]
  
  Results2[i*3-3+1, 3] <- Mean2
  Results2[i*3-3+2, 3:4] <- CI2[3:4]
  Results2[i*3-3+3, 3:4] <- CI2[1:2]
  
  Results2[i*3-3+1, 5] <- Mean3
  Results2[i*3-3+2, 5:6] <- CI3[3:4]
  Results2[i*3-3+3, 5:6] <- CI3[1:2]
  
  i <- i+1 
}

N <- length(ExpVars)
# Interest rate shock
Results[N*3-3+8, 1] <- isident1
Results[N*3-3+9, 1] <- length(Data$Date)
Results[N*3-3+10, 1] <- sum((Data$MainEvPay==TRUE)&(Data$OtherEvPay==FALSE))
Results[N*3-3+11, 1] <- sum((Data$MainEvPay==FALSE)&(Data$OtherEvPay==FALSE))

# Expectation shock
Results[N*3-3+8, 3] <- isident2
Results[N*3-3+9, 3] <- length(Data$Date)
Results[N*3-3+10, 3] <- sum((Data$MainEvPay==TRUE)&(Data$OtherEvPay==FALSE))
Results[N*3-3+11, 3] <- sum((Data$MainEvPay==FALSE)&(Data$OtherEvPay==FALSE))

rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)
rownames(Results2) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results2)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/SettlementResults.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
write.xlsx(Results[(N*3-3+8):(N*3-3+12),], paste(outDir, "/SettlementDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
# Export the results
write.xlsx(Results2, paste(outDir, "/SettlementVDec.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)


# --------------------------------------------------------------
# Table 4: Maturity
# --------------------------------------------------------------
# Long-term Bills
Estim  <- estimateIRFHetLP(Data, "MainEvLong", "OtherEvLong", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet1 <- Estim[[1]][,2,1,]

# Short-term Bills
Estim  <- estimateIRFHetLP(Data, "MainEvShort", "OtherEvShort", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet2 <- Estim[[1]][,2,1,]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "SMI", "CHFTW")

Results <- array(NA, c((length(ExpVars)+4)*4, 8))
i <- 1
for (vars in ExpVars){
  
  Draws <- PsiHet1[vars, ]
  Draws2 <- PsiHet2[vars, ]
  
  # Calculate mean
  Mean <- mean(Draws, na.rm = TRUE)
  Mean2 <- mean(Draws2, na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(Draws2, na.rm = TRUE, probs = CIlev)
  
  if (vars == "SMI"){
    # Calculate share identified
    isident1 <- as.matrix(c(mean(!is.na(Draws))))
    isident2 <- as.matrix(c(mean(!is.na(Draws2))))
    
  }
  
  # Collect the results
  Results[i*3-3+1, 1] <- Mean
  Results[i*3-3+1, 3] <- Mean2
  
  Results[i*3-3+2, 1:2] <- CI[3:4]
  Results[i*3-3+2, 3:4] <- CI2[3:4]
  
  Results[i*3-3+3, 1:2] <- CI[1:2]
  Results[i*3-3+3, 3:4] <- CI2[1:2]
  
  
  i <- i+1
  
}

Results[i*3-3+5, 1] <- isident1
Results[i*3-3+6, 1] <- length(Data$Date)
Results[i*3-3+7, 1] <- sum((Data$MainEvLong==TRUE)&(Data$OtherEvLong==FALSE))
Results[i*3-3+8, 1] <- sum((Data$MainEvLong==FALSE)&(Data$OtherEvLong==FALSE))

Results[i*3-3+5, 2] <- isident2
Results[i*3-3+6, 2] <- length(Data$Date)
Results[i*3-3+7, 2] <- sum((Data$MainEvShort==TRUE)&(Data$OtherEvShort==FALSE))
Results[i*3-3+8, 2] <- sum((Data$MainEvShort==FALSE)&(Data$OtherEvShort==FALSE))


rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/Maturity.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)

write.xlsx(Results[(i*3-3+5):(i*3-3+8),], paste(outDir, "/MaturityDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)


# --------------------------------------------------------------
# Figure 4: Dynamic impact of signalling shock
# --------------------------------------------------------------
SigLev    <- c(0.05, 0.1)
H <- 20
EndLab <- c("8Y interest rate (in pp)", "Inflation expectations (in pp)", "Real interest rate (in pp)", "Risk premium (in pp)", "Exchange rate (in %)")
EndVar1 <- c("SARON", "SMI", "CHFTW", "EID8Y", "RRLOW", "RPLOW", "PI")
Estim  <- estimateIRFHetLP(Data, EventDays, OtherDays, EndVar1, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]]

# Plot responses to shock 2
YLim <- list(c(-.1, .01), c(-.05, .025), c(-.05, .025), c(-.01, .05), c(-.75, .1))
PlotIRF <- PsiHet[c(4, 7, 5, 6, 3), 2 , , ]
rownames(PlotIRF) <- EndLab

myCharts <- plotIRFHet(PlotIRF, H, SigScale = 1, SigLev, plotActual = FALSE, YLim = YLim)
# Check whether identified and add to plot
isident <- array(NA, H+1)
for (h in 0:H){
  isident[h] <- as.matrix(c(mean(!is.na(PlotIRF[2, h+1, ]), na.rm = TRUE)))
}
g1 <- ggplot(data.frame(isident), aes(c(0:H)))
g1 <- g1 + geom_line(aes(y = `isident`, colour = "black"), size = 0.4)
g1 <- g1 + theme_minimal() + xlab("") + ggtitle("Share identified")+theme(plot.title = element_text(size = 10))+ylab("")+
  theme(legend.position = "none", legend.title = element_blank()) + scale_x_continuous(breaks=seq(0, H, 2))
g1 <- g1 + scale_colour_manual("",values=cbind("black"))
g1 <- g1+ coord_cartesian(ylim = c(.5, 1)) 
g1 <- g1 + theme(panel.grid.major = element_blank()) +
  theme(panel.grid.minor = element_blank()) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.1))+
  theme(axis.ticks = element_line(colour = "black", size=0.1))+
  theme(axis.text = element_text(colour = "black"))+
  theme(text = element_text(size = 11, family = "Palatino"))+
  theme(plot.margin=grid::unit(c(1,1,1,1), "mm"))

myCharts[[(length(myCharts)+1)]] <- g1
gAll <- do.call("grid.arrange", c(myCharts, ncol = 2))
ggsave(paste(outDir, "/IRFLP.pdf", sep = ""), plot = gAll, width = figWidth2, height = figHeight2*1.4, units="cm")

# --------------------------------------------------------------
# Figure 5: Dynamic impact of overnight rate shock
# --------------------------------------------------------------
YLim2 <- list(c(-.05, .1), c(-.05, .05), c(-.05, .05), c(-.05, .05), c(-0.5, .5))
PlotIRF <- PsiHet[c(4, 7, 5, 6, 3), 1 , , ]
rownames(PlotIRF) <- EndLab
myCharts <- plotIRFHet(PlotIRF, H, SigScale = 1, SigLev, plotActual = FALSE, YLim = YLim2)

# Check whether identified and add to plot
isident <- array(NA, H+1)
for (h in 0:H){
  isident[h] <- as.matrix(c(mean(!is.na(PlotIRF[1, h+1, ]), na.rm = TRUE)))
}
g1 <- ggplot(data.frame(isident), aes(c(0:H)))
g1 <- g1 + geom_line(aes(y = `isident`, colour = "black"), size = 0.4)
g1 <- g1 + theme_minimal() + xlab("") + ggtitle("Share identified")+theme(plot.title = element_text(size = 10))+ylab("")+
  theme(legend.position = "none", legend.title = element_blank()) + scale_x_continuous(breaks=seq(0, H, 2))
g1 <- g1 + scale_colour_manual("",values=cbind("black"))
g1 <- g1+ coord_cartesian(ylim = c(.5, 1)) 
g1 <- g1 + theme(panel.grid.major = element_blank()) +
  theme(panel.grid.minor = element_blank()) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.1))+
  theme(axis.ticks = element_line(colour = "black", size=0.1))+
  theme(axis.text = element_text(colour = "black"))+
  theme(text = element_text(size = 11, family = "Palatino"))+
  theme(plot.margin=grid::unit(c(1,1,1,1), "mm"))

myCharts[[(length(myCharts)+1)]] <- g1
gAll <- do.call("grid.arrange", c(myCharts, ncol = 2))
ggsave(paste(outDir, "/IRFLPIR.pdf", sep = ""), plot = gAll, width = figWidth2, height = figHeight2*1.4, units="cm")


# --------------------------------------------------------------
# Table C.1: Placebo tests: other events
# --------------------------------------------------------------
# 1) GMBF
print("Estimate model 1")
Estim  <- estimateIRFHetLP(Data, "MainEvGMBF", "OtherEvGMBF", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]][,2,1,]

# 2) USD SNB Bill Auctions, Negative Sign restriction on SMI
print("Estimate model 2")
Estim  <- estimateIRFHetLP(Data, "MainEvUSD", "OtherEvUSD", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet2 <- Estim[[1]][,2,1,]

# 3) Reverse repo auction
print("Estimate model 3")
Estim  <- estimateIRFHetLP(Data, "MainEvRR", "OtherEvRR", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet3 <- Estim[[1]][,2,1,]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "SMI", "CHFTW")
Results <- array(NA, c((length(ExpVars)+4)*4, 8))
i <- 1
for (vars in ExpVars){
  
  Draws <- PsiHet[vars, ]
  Draws2 <- PsiHet2[vars, ]
  Draws3 <- PsiHet3[vars, ]
  
  # Calculate mean
  Mean <- mean(Draws, na.rm = TRUE)
  Mean2 <- mean(Draws2, na.rm = TRUE)
  Mean3 <- mean(Draws3, na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(Draws2, na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(Draws3, na.rm = TRUE, probs = CIlev)
  
  if (vars == "SMI"){
    # Calculate share identified
    isident1 <- as.matrix(c(mean(!is.na(Draws))))
    isident2 <- as.matrix(c(mean(!is.na(Draws2))))
    isident3 <- as.matrix(c(mean(!is.na(Draws3))))
  }
  
  # Collect the results
  Results[i*3-3+1, 1] <- Mean
  Results[i*3-3+1, 3] <- Mean2
  Results[i*3-3+1, 5] <- Mean3
  
  Results[i*3-3+2, 1:2] <- CI[3:4]
  Results[i*3-3+2, 3:4] <- CI2[3:4]
  Results[i*3-3+2, 5:6] <- CI3[3:4]
  
  Results[i*3-3+3, 1:2] <- CI[1:2]
  Results[i*3-3+3, 3:4] <- CI2[1:2]
  Results[i*3-3+3, 5:6] <- CI3[1:2]
  
  i <- i+1
  
}

Results[i*3-3+5, 1] <- isident1
Results[i*3-3+6, 1] <- length(Data$Date)
Results[i*3-3+7, 1] <- sum((Data$MainEvPay==TRUE)&(Data$OtherEvPay==FALSE))
Results[i*3-3+8, 1] <- sum((Data$MainEvPay==FALSE)&(Data$OtherEvPay==FALSE))

Results[i*3-3+5, 2] <- isident2
Results[i*3-3+6, 2] <- length(Data$Date)
Results[i*3-3+7, 2] <- sum((Data$MainEvUSD==TRUE)&(Data$OtherEvUSD==FALSE))
Results[i*3-3+8, 2] <- sum((Data$MainEvUSD==FALSE)&(Data$OtherEvUSD==FALSE))

Results[i*3-3+5, 3] <- isident3
Results[i*3-3+6, 3] <- length(Data$Date)
Results[i*3-3+7, 3] <- sum((Data$MainEvGMBF==TRUE)&(Data$OtherEvGMBF==FALSE))
Results[i*3-3+8, 3] <- sum((Data$MainEvGMBF==FALSE)&(Data$OtherEvGMBF==FALSE))


rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/Placebo.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)

write.xlsx(Results[(i*3-3+5):(i*3-3+8),], paste(outDir, "/PlaceboDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)


# --------------------------------------------------------------
# Table C.4: Robustness test I: various controls
# --------------------------------------------------------------
# 1) P = 1
print("Estimate model 1")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P = 1, B, k, useCumulative, useParametric, NoEndo = FALSE, NoExo = F)
PsiHet <- Estim[[1]][,2,1,]

# 2) P = 2
print("Estimate model 2")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P = 2, B, k, useCumulative, useParametric, NoEndo = FALSE, NoExo = F)
PsiHet2 <- Estim[[1]][,2,1,]

# 3) No foreign controls
print("Estimate model 3")
EndVar3 <- c("SARON", "SMI", "CHFTW", "EID8Y", "USDEUR", "ESTXX")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar3, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = T)
PsiHet3 <- Estim[[1]][,2,1,]

# 4) Reverse Repo controls (note that we have to estimate this with "broad" event definition to include days with repo auctions)
print("Estimate model 4")
ExoVar4 <- c("FFR.l1", "USDEUR.l1", "US8Y.l1", "SP500.l1", "RRepoAllot", "RRepoYield")
EndVar4 <- c("SARON", "SMI", "CHFTW", "EID8Y")
Estim  <- estimateIRFHetLP(Data,  EventDays, "OtherEvBroad4", EndVar4, ExoVar4, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet4 <- Estim[[1]][,2,1,]

# 5) Data cleaned by international noise
print("Estimate model 5")
EndVar5 <- c("SARONRes2", "SMIRes2", "CHFTWRes2", "EID8YRes2")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar5, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = T)
PsiHet5 <- Estim[[1]][,2,1,]
rownames(PsiHet5) <- c("SARON", "SMI", "CHFTW", "EID8Y")


# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "SMI", "CHFTW")

Results <- array(NA, c((length(ExpVars)+4)*4, 10))
i <- 1
for (vars in ExpVars){
  
  Draws <- PsiHet[vars, ]
  Draws2 <- PsiHet2[vars, ]
  Draws3 <- PsiHet3[vars, ]
  Draws4 <- PsiHet4[vars, ]
  Draws5 <- PsiHet5[vars, ]
  
  # Calculate mean
  Mean <- mean(Draws, na.rm = TRUE)
  Mean2 <- mean(Draws2, na.rm = TRUE)
  Mean3 <- mean(Draws3, na.rm = TRUE)
  Mean4 <- mean(Draws4, na.rm = TRUE)
  Mean5 <- mean(Draws5, na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(Draws2, na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(Draws3, na.rm = TRUE, probs = CIlev)
  CI4 <- quantile(Draws4, na.rm = TRUE, probs = CIlev)
  CI5 <- quantile(Draws5, na.rm = TRUE, probs = CIlev)
  
  if (vars == "SMI"){
    # Calculate share identified
    isident1 <- as.matrix(c(mean(!is.na(Draws))))
    isident2 <- as.matrix(c(mean(!is.na(Draws2))))
    isident3 <- as.matrix(c(mean(!is.na(Draws3))))
    isident4 <- as.matrix(c(mean(!is.na(Draws4))))
    isident5 <- as.matrix(c(mean(!is.na(Draws5))))
  }
  
  # Collect the results
  Results[i*3-3+1, 1] <- Mean
  Results[i*3-3+1, 3] <- Mean2
  Results[i*3-3+1, 5] <- Mean3
  Results[i*3-3+1, 7] <- Mean4
  Results[i*3-3+1, 9] <- Mean5
  
  Results[i*3-3+2, 1:2] <- CI[3:4]
  Results[i*3-3+2, 3:4] <- CI2[3:4]
  Results[i*3-3+2, 5:6] <- CI3[3:4]
  Results[i*3-3+2, 7:8] <- CI4[3:4]
  Results[i*3-3+2, 9:10] <- CI5[3:4]
  
  Results[i*3-3+3, 1:2] <- CI[1:2]
  Results[i*3-3+3, 3:4] <- CI2[1:2]
  Results[i*3-3+3, 5:6] <- CI3[1:2]
  Results[i*3-3+3, 7:8] <- CI4[1:2]
  Results[i*3-3+3, 9:10] <- CI5[1:2]
  
  i <- i+1
  
}

Results[i*3-3+5, 1] <- isident1
Results[i*3-3+6, 1] <- length(Data$Date)
Results[i*3-3+7, 1] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 1] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 2] <- isident2
Results[i*3-3+6, 2] <- length(Data$Date)
Results[i*3-3+7, 2] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 2] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 3] <- isident3
Results[i*3-3+6, 3] <- length(Data$Date)
Results[i*3-3+7, 3] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 3] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 4] <- isident4
Results[i*3-3+6, 4] <- length(Data$Date)
Results[i*3-3+7, 4] <- sum((Data$MainEv==TRUE)&(Data$OtherEvBroad4==FALSE))
Results[i*3-3+8, 4] <- sum((Data$MainEv==FALSE)&(Data$OtherEvBroad4==FALSE))

Results[i*3-3+5, 5] <- isident5
Results[i*3-3+6, 5] <- length(Data$Date)
Results[i*3-3+7, 5] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 5] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/RobustI.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)

write.xlsx(Results[(i*3-3+5):(i*3-3+8),], paste(outDir, "/RobustIDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)



# --------------------------------------------------------------
# Table C.5: Robustness test II: other stock prices and exchange rates
# --------------------------------------------------------------
# 1) CHF/EUR, Negative Sign restriction on SMI
print("Estimate model 1")
EndVar1 <- c("SARON", "SMI", "CHFEUR", "EID8Y")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar1, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]][,2,1,]
rownames(PsiHet) <- EndVar

# 2) CHF/USD, Negative Sign restriction on SMI
print("Estimate model 2")
EndVar2 <- c("SARON", "SMI", "CHFUSD", "EID8Y")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar2, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet2 <- Estim[[1]][,2,1,]
rownames(PsiHet2) <- EndVar

# 3) CHF/JPY, Negative Sign restriction on SMI
print("Estimate model 3")
EndVar3 <- c("SARON", "SMI", "CHFJPY", "EID8Y")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar3, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet3 <- Estim[[1]][,2,1,]
rownames(PsiHet3) <- EndVar

# 4) SPI
print("Estimate model 4")
EndVar4 <- c("SARON", "SPI", "CHFTW", "EID8Y")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar4, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet4 <- Estim[[1]][,2,1,]
rownames(PsiHet4) <- EndVar

# 5) MSCI
print("Estimate model 5")
EndVar5 <- c("SARON", "MSCI", "CHFTW", "EID8Y")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar5, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet5 <- Estim[[1]][,2,1,]
rownames(PsiHet5) <- EndVar

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "SMI", "CHFTW")

Results <- array(NA, c((length(ExpVars)+4)*4, 10))
i <- 1
for (vars in ExpVars){
  
  Draws <- PsiHet[vars, ]
  Draws2 <- PsiHet2[vars, ]
  Draws3 <- PsiHet3[vars, ]
  Draws4 <- PsiHet4[vars, ]
  Draws5 <- PsiHet5[vars, ]
  
  # Calculate mean
  Mean <- mean(Draws, na.rm = TRUE)
  Mean2 <- mean(Draws2, na.rm = TRUE)
  Mean3 <- mean(Draws3, na.rm = TRUE)
  Mean4 <- mean(Draws4, na.rm = TRUE)
  Mean5 <- mean(Draws5, na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(Draws2, na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(Draws3, na.rm = TRUE, probs = CIlev)
  CI4 <- quantile(Draws4, na.rm = TRUE, probs = CIlev)
  CI5 <- quantile(Draws5, na.rm = TRUE, probs = CIlev)
  
  if (vars == "SMI"){
    # Calculate share identified
    isident1 <- as.matrix(c(mean(!is.na(Draws))))
    isident2 <- as.matrix(c(mean(!is.na(Draws2))))
    isident3 <- as.matrix(c(mean(!is.na(Draws3))))
    isident4 <- as.matrix(c(mean(!is.na(Draws4))))
    isident5 <- as.matrix(c(mean(!is.na(Draws5))))
  }
  
  # Collect the results
  Results[i*3-3+1, 1] <- Mean
  Results[i*3-3+1, 3] <- Mean2
  Results[i*3-3+1, 5] <- Mean3
  Results[i*3-3+1, 7] <- Mean4
  Results[i*3-3+1, 9] <- Mean5
  
  Results[i*3-3+2, 1:2] <- CI[3:4]
  Results[i*3-3+2, 3:4] <- CI2[3:4]
  Results[i*3-3+2, 5:6] <- CI3[3:4]
  Results[i*3-3+2, 7:8] <- CI4[3:4]
  Results[i*3-3+2, 9:10] <- CI5[3:4]
  
  Results[i*3-3+3, 1:2] <- CI[1:2]
  Results[i*3-3+3, 3:4] <- CI2[1:2]
  Results[i*3-3+3, 5:6] <- CI3[1:2]
  Results[i*3-3+3, 7:8] <- CI4[1:2]
  Results[i*3-3+3, 9:10] <- CI5[1:2]
  
  i <- i+1
  
}

Results[i*3-3+5, 1] <- isident1
Results[i*3-3+6, 1] <- length(Data$Date)
Results[i*3-3+7, 1] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 1] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 2] <- isident2
Results[i*3-3+6, 2] <- length(Data$Date)
Results[i*3-3+7, 2] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 2] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 3] <- isident3
Results[i*3-3+6, 3] <- length(Data$Date)
Results[i*3-3+7, 3] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 3] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 4] <- isident4
Results[i*3-3+6, 4] <- length(Data$Date)
Results[i*3-3+7, 4] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 4] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 5] <- isident5
Results[i*3-3+6, 5] <- length(Data$Date)
Results[i*3-3+7, 5] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 5] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/RobustII.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)

write.xlsx(Results[(i*3-3+5):(i*3-3+8),], paste(outDir, "/RobustIIDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)


# --------------------------------------------------------------
# Table C.6: Robustness test: spreads
# --------------------------------------------------------------
EndVar1 <- c("SARON", "SMI", "CHFTW", "EID8Y", "TSPR1", "TSPR2", "RPHIG", "RPMID")
Estim  <- estimateIRFHetLP(Data, EventDays, OtherDays, EndVar1, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]]
VEv <- Estim[[2]]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
Shocks <- c(1, 2)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "TSPR1", "TSPR2", "RPMID", "RPHIG", "SMI", "CHFTW")
Results <- array(NA, c((length(ExpVars)+4)*4, 12))
Results2 <- array(NA, c((length(ExpVars)+4)*4, 12))

i <- 1
for (vars in ExpVars){
  for (shocks in Shocks){
    
    Draws <- PsiHet[vars, shocks, , ]
    
    # Calculate mean
    Mean <- mean(Draws, na.rm = TRUE)
    
    # Calculate 95% and 90% CI
    CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
    
    if (vars == "SMI" & shocks == 2){
      # Calculate share identified
      isident2 <- as.matrix(c(mean(!is.na(Draws))))
    }
    if (vars == "SARON" & shocks == 1){
      # Calculate share identified
      isident1 <- as.matrix(c(mean(!is.na(Draws))))
    }
    
    # Collect the results
    Results[i*3-3+1, (shocks-1)*2+1] <- Mean
    Results[i*3-3+2, ((shocks-1)*2+1):((shocks-1)*2+2)] <- CI[3:4]
    Results[i*3-3+3, ((shocks-1)*2+1):((shocks-1)*2+2)] <- CI[1:2]
    
  }
  
  # Calculate mean
  Mean <- mean(VEv[vars, 1 ,1, ], na.rm = TRUE)
  Mean2 <- mean(VEv[vars, 2 , 1, ], na.rm = TRUE)
  Mean3 <- mean(VEv[vars, 3 , 1, ], na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(VEv[vars, 1 ,1, ], na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(VEv[vars, 2 ,1, ], na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(VEv[vars, 3 ,1, ], na.rm = TRUE, probs = CIlev)
  
  # Collect the results
  Results2[i*3-3+1, 1] <- Mean
  Results2[i*3-3+2, 1:2] <- CI[3:4]
  Results2[i*3-3+3, 1:2] <- CI[1:2]
  
  Results2[i*3-3+1, 3] <- Mean2
  Results2[i*3-3+2, 3:4] <- CI2[3:4]
  Results2[i*3-3+3, 3:4] <- CI2[1:2]
  
  Results2[i*3-3+1, 5] <- Mean3
  Results2[i*3-3+2, 5:6] <- CI3[3:4]
  Results2[i*3-3+3, 5:6] <- CI3[1:2]
  
  i <- i+1 
}

N <- length(ExpVars)
# Interest rate shock
Results[N*3-3+8, 1] <- isident1
Results[N*3-3+9, 1] <- length(Data$Date)
Results[N*3-3+10, 1] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[N*3-3+11, 1] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

# Expectation shock
Results[N*3-3+8, 3] <- isident2
Results[N*3-3+9, 3] <- length(Data$Date)
Results[N*3-3+10, 3] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[N*3-3+11, 3] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)
rownames(Results2) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results2)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/RobustIII.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
write.xlsx(Results[(N*3-3+8):(N*3-3+12),], paste(outDir, "/RobustIIIDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)
# Export the results
write.xlsx(Results2, paste(outDir, "/RobustIIIVDec.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)


# --------------------------------------------------------------
# Table C.7: Robustness test: subsamples
# --------------------------------------------------------------
# 3M Libor below 25bp
DataSub1 <- subset(Data, Date>as.Date("2010-03-19"))
Estim  <- estimateIRFHetLP(DataSub1, EventDays, "OtherEvBroad2", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet1 <- Estim[[1]][,2,1,]

# 3M Libor above 25bp
DataSub2 <- subset(Data, Date<=as.Date("2010-03-19"))
Estim  <- estimateIRFHetLP(DataSub2, EventDays, "OtherEvBroad2", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet2 <- Estim[[1]][,2,1,]

# Note: Liquidity surplus starting roughly in 2010 (see Moser, 2011)
# Also, we have to use broad events because otherwise not enough auctions (because of Tuesdays)
DataSub3 <- subset(Data, Date>as.Date("2010-06-01"))
Estim  <- estimateIRFHetLP(DataSub3, EventDays, "OtherEvBroad2", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet3 <- Estim[[1]][,2,1,]

DataSub4 <- subset(Data, Date<=as.Date("2010-06-01"))
Estim  <- estimateIRFHetLP(DataSub4, EventDays, "OtherEvBroad2", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet4 <- Estim[[1]][,2,1,]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "SMI", "CHFTW")

Results <- array(NA, c((length(ExpVars)+4)*4, 8))
i <- 1
for (vars in ExpVars){
  
  Draws <- PsiHet1[vars, ]
  Draws2 <- PsiHet2[vars, ]
  Draws3 <- PsiHet3[vars, ]
  Draws4 <- PsiHet4[vars, ]
  
  # Calculate mean
  Mean <- mean(Draws, na.rm = TRUE)
  Mean2 <- mean(Draws2, na.rm = TRUE)
  Mean3 <- mean(Draws3, na.rm = TRUE)
  Mean4 <- mean(Draws4, na.rm = TRUE)
  
  
  # Calculate 95% and 90% CI
  CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(Draws2, na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(Draws3, na.rm = TRUE, probs = CIlev)
  CI4 <- quantile(Draws4, na.rm = TRUE, probs = CIlev)
  
  
  if (vars == "SMI"){
    # Calculate share identified
    isident1 <- as.matrix(c(mean(!is.na(Draws))))
    isident2 <- as.matrix(c(mean(!is.na(Draws2))))
    isident3 <- as.matrix(c(mean(!is.na(Draws3))))
    isident4 <- as.matrix(c(mean(!is.na(Draws4))))
    
  }
  
  # Collect the results
  Results[i*3-3+1, 1] <- Mean
  Results[i*3-3+1, 3] <- Mean2
  Results[i*3-3+1, 5] <- Mean3
  Results[i*3-3+1, 7] <- Mean4
  
  
  Results[i*3-3+2, 1:2] <- CI[3:4]
  Results[i*3-3+2, 3:4] <- CI2[3:4]
  Results[i*3-3+2, 5:6] <- CI3[3:4]
  Results[i*3-3+2, 7:8] <- CI4[3:4]
  
  
  Results[i*3-3+3, 1:2] <- CI[1:2]
  Results[i*3-3+3, 3:4] <- CI2[1:2]
  Results[i*3-3+3, 5:6] <- CI3[1:2]
  Results[i*3-3+3, 7:8] <- CI4[1:2]
  
  
  i <- i+1
  
}

Results[i*3-3+5, 1] <- isident1
Results[i*3-3+6, 1] <- length(DataSub1$Date)
Results[i*3-3+7, 1] <- sum((DataSub1$MainEv==TRUE)&(DataSub1$OtherEvBroad2==FALSE))
Results[i*3-3+8, 1] <- sum((DataSub1$MainEv==FALSE)&(DataSub1$OtherEvBroad2==FALSE))

Results[i*3-3+5, 2] <- isident2
Results[i*3-3+6, 2] <- length(DataSub2$Date)
Results[i*3-3+7, 2] <- sum((DataSub2$MainEv==TRUE)&(DataSub2$OtherEvBroad2==FALSE))
Results[i*3-3+8, 2] <- sum((DataSub2$MainEv==FALSE)&(DataSub2$OtherEvBroad2==FALSE))

Results[i*3-3+5, 3] <- isident3
Results[i*3-3+6, 3] <- length(DataSub3$Date)
Results[i*3-3+7, 3] <- sum((DataSub3$MainEv==TRUE)&(DataSub3$OtherEvBroad2==FALSE))
Results[i*3-3+8, 3] <- sum((DataSub3$MainEv==FALSE)&(DataSub3$OtherEvBroad2==FALSE))

Results[i*3-3+5, 4] <- isident4
Results[i*3-3+6, 4] <- length(DataSub4$Date)
Results[i*3-3+7, 4] <- sum((DataSub4$MainEv==TRUE)&(DataSub4$OtherEvBroad2==FALSE))
Results[i*3-3+8, 4] <- sum((DataSub4$MainEv==FALSE)&(DataSub4$OtherEvBroad2==FALSE))

rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/RobustIV.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)

write.xlsx(Results[(i*3-3+5):(i*3-3+8),], paste(outDir, "/RobustIVDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)

# --------------------------------------------------------------
# Table C.7: Robustness test V: Change counterfactual days
# --------------------------------------------------------------
# 1) Other events, Negative Sign restriction on SMI
Estim  <- estimateIRFHetLP(Data,  EventDays, "OtherEvBroad2", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]][,2,1,]

# 2) Other events, Negative Sign restriction on SMI
print("Estimate model 2")
Estim  <- estimateIRFHetLP(Data,  EventDays, "OtherEvBroad3", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet2 <- Estim[[1]][,2,1,]

# 3) Other events, Negative Sign restriction on SMI
print("Estimate model 3")
Estim  <- estimateIRFHetLP(Data,  EventDays, "OtherEvBroad4", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet3 <- Estim[[1]][,2,1,]

# 4) Other events, Negative Sign restriction on SMI
print("Estimate model 1")
Estim  <- estimateIRFHetLP(Data,  EventDays, "OtherEvBroad5", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet4 <- Estim[[1]][,2,1,]

# 5) Other events, Negative Sign restriction on SMI
print("Estimate model 1")
Estim  <- estimateIRFHetLP(Data,  EventDays, "OtherEvBroad6", EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet5 <- Estim[[1]][,2,1,]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "SMI", "CHFTW")
Results <- array(NA, c((length(ExpVars)+4)*4, 10))
i <- 1
for (vars in ExpVars){
  
  Draws <- PsiHet[vars, ]
  Draws2 <- PsiHet2[vars, ]
  Draws3 <- PsiHet3[vars, ]
  Draws4 <- PsiHet4[vars, ]
  Draws5 <- PsiHet5[vars, ]
  
  # Calculate mean
  Mean <- mean(Draws, na.rm = TRUE)
  Mean2 <- mean(Draws2, na.rm = TRUE)
  Mean3 <- mean(Draws3, na.rm = TRUE)
  Mean4 <- mean(Draws4, na.rm = TRUE)
  Mean5 <- mean(Draws5, na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(Draws2, na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(Draws3, na.rm = TRUE, probs = CIlev)
  CI4 <- quantile(Draws4, na.rm = TRUE, probs = CIlev)
  CI5 <- quantile(Draws5, na.rm = TRUE, probs = CIlev)
  
  if (vars == "SMI"){
    # Calculate share identified
    isident1 <- as.matrix(c(mean(!is.na(Draws))))
    isident2 <- as.matrix(c(mean(!is.na(Draws2))))
    isident3 <- as.matrix(c(mean(!is.na(Draws3))))
    isident4 <- as.matrix(c(mean(!is.na(Draws4))))
    isident5 <- as.matrix(c(mean(!is.na(Draws5))))
  }
  
  # Collect the results
  Results[i*3-3+1, 1] <- Mean
  Results[i*3-3+1, 3] <- Mean2
  Results[i*3-3+1, 5] <- Mean3
  Results[i*3-3+1, 7] <- Mean4
  Results[i*3-3+1, 9] <- Mean5
  
  Results[i*3-3+2, 1:2] <- CI[3:4]
  Results[i*3-3+2, 3:4] <- CI2[3:4]
  Results[i*3-3+2, 5:6] <- CI3[3:4]
  Results[i*3-3+2, 7:8] <- CI4[3:4]
  Results[i*3-3+2, 9:10] <- CI5[3:4]
  
  Results[i*3-3+3, 1:2] <- CI[1:2]
  Results[i*3-3+3, 3:4] <- CI2[1:2]
  Results[i*3-3+3, 5:6] <- CI3[1:2]
  Results[i*3-3+3, 7:8] <- CI4[1:2]
  Results[i*3-3+3, 9:10] <- CI5[1:2]
  
  i <- i+1
  
}

Results[i*3-3+5, 1] <- isident1
Results[i*3-3+6, 1] <- length(Data$Date)
Results[i*3-3+7, 1] <- sum((Data$MainEv==TRUE)&(Data$OtherEvBroad2==FALSE))
Results[i*3-3+8, 1] <- sum((Data$MainEv==FALSE)&(Data$OtherEvBroad2==FALSE))

Results[i*3-3+5, 2] <- isident2
Results[i*3-3+6, 2] <- length(Data$Date)
Results[i*3-3+7, 2] <- sum((Data$MainEv==TRUE)&(Data$OtherEvBroad3==FALSE))
Results[i*3-3+8, 2] <- sum((Data$MainEv==FALSE)&(Data$OtherEvBroad3==FALSE))

Results[i*3-3+5, 3] <- isident3
Results[i*3-3+6, 3] <- length(Data$Date)
Results[i*3-3+7, 3] <- sum((Data$MainEv==TRUE)&(Data$OtherEvBroad4==FALSE))
Results[i*3-3+8, 3] <- sum((Data$MainEv==FALSE)&(Data$OtherEvBroad4==FALSE))

Results[i*3-3+5, 4] <- isident4
Results[i*3-3+6, 4] <- length(Data$Date)
Results[i*3-3+7, 4] <- sum((Data$MainEv==TRUE)&(Data$OtherEvBroad5==FALSE))
Results[i*3-3+8, 4] <- sum((Data$MainEv==FALSE)&(Data$OtherEvBroad5==FALSE))

Results[i*3-3+5, 5] <- isident5
Results[i*3-3+6, 5] <- length(Data$Date)
Results[i*3-3+7, 5] <- sum((Data$MainEv==TRUE)&(Data$OtherEvBroad6==FALSE))
Results[i*3-3+8, 5] <- sum((Data$MainEv==FALSE)&(Data$OtherEvBroad6==FALSE))


rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/RobustV.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)

write.xlsx(Results[(i*3-3+5):(i*3-3+8),], paste(outDir, "/RobustVDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)


# --------------------------------------------------------------
# Table C.7 Robustness test VI: various specifications restrictions
# --------------------------------------------------------------
# 1) Restrict only exchange rate to decline
print("Estimate model 1")
EndVar1 <- c("CHFTW", "SARON", "SMI", "TSPR1","EID8Y",  "RPLOW", "PI")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar1, ExoVar, c(-1), H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet <- Estim[[1]][,1,1,]

# 2) Restrict only stock prices to decline
print("Estimate model 2")
EndVar2 <- c("SMI", "RPLOW", "SARON", "CHFTW", "TSPR1","EID8Y",  "PI")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar2, ExoVar, c(-1), H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet2 <- Estim[[1]][,1,1,]

# 3) Restrict risk premium to increase
print("Estimate model 2")
EndVar3 <- c("SARON", "RPLOW", "SMI", "TSPR1","EID8Y",  "CHFTW", "PI")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar3, ExoVar, c(1, 1), H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet3 <- Estim[[1]][,2,1,]

# 3) Restrict inflation expectations to decline
print("Estimate model 3")
EndVar4 <- c("SARON", "PI", "SMI", "TSPR1","EID8Y",  "CHFTW", "RPLOW")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar4, ExoVar, c(1, -1), H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet4 <- Estim[[1]][,2,1,]

# 5) Restrict yield curve to invert
print("Estimate model 5")
EndVar5 <- c("SARON", "TSPR1", "SMI", "PI","EID8Y",  "CHFTW", "RPLOW")
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar5, ExoVar, c(1, -1), H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
PsiHet5 <- Estim[[1]][,2,1,]

# H = 1: Collect and export of results for table (only for immediate impact, with two confidence intervals)
CIlev <- c(0.025, 0.975, 0.05, 0.95)
ExpVars <-  c("SARON", "EID8Y", "RPLOW", "TSPR1", "PI", "SMI", "CHFTW")

Results <- array(NA, c((length(ExpVars)+4)*4, 10))
i <- 1
for (vars in ExpVars){
  
  Draws <- PsiHet[vars, ]
  Draws2 <- PsiHet2[vars, ]
  Draws3 <- PsiHet3[vars, ]
  Draws4 <- PsiHet4[vars, ]
  Draws5 <- PsiHet5[vars, ]
  
  # Calculate mean
  Mean <- mean(Draws, na.rm = TRUE)
  Mean2 <- mean(Draws2, na.rm = TRUE)
  Mean3 <- mean(Draws3, na.rm = TRUE)
  Mean4 <- mean(Draws4, na.rm = TRUE)
  Mean5 <- mean(Draws5, na.rm = TRUE)
  
  # Calculate 95% and 90% CI
  CI <- quantile(Draws, na.rm = TRUE, probs = CIlev)
  CI2 <- quantile(Draws2, na.rm = TRUE, probs = CIlev)
  CI3 <- quantile(Draws3, na.rm = TRUE, probs = CIlev)
  CI4 <- quantile(Draws4, na.rm = TRUE, probs = CIlev)
  CI5 <- quantile(Draws5, na.rm = TRUE, probs = CIlev)
  
  if (vars == "SMI"){
    # Calculate share identified
    isident1 <- as.matrix(c(mean(!is.na(Draws))))
    isident2 <- as.matrix(c(mean(!is.na(Draws2))))
    isident3 <- as.matrix(c(mean(!is.na(Draws3))))
    isident4 <- as.matrix(c(mean(!is.na(Draws4))))
    isident5 <- as.matrix(c(mean(!is.na(Draws5))))
  }
  
  # Collect the results
  Results[i*3-3+1, 1] <- Mean
  Results[i*3-3+1, 3] <- Mean2
  Results[i*3-3+1, 5] <- Mean3
  Results[i*3-3+1, 7] <- Mean4
  Results[i*3-3+1, 9] <- Mean5
  
  Results[i*3-3+2, 1:2] <- CI[3:4]
  Results[i*3-3+2, 3:4] <- CI2[3:4]
  Results[i*3-3+2, 5:6] <- CI3[3:4]
  Results[i*3-3+2, 7:8] <- CI4[3:4]
  Results[i*3-3+2, 9:10] <- CI5[3:4]
  
  Results[i*3-3+3, 1:2] <- CI[1:2]
  Results[i*3-3+3, 3:4] <- CI2[1:2]
  Results[i*3-3+3, 5:6] <- CI3[1:2]
  Results[i*3-3+3, 7:8] <- CI4[1:2]
  Results[i*3-3+3, 9:10] <- CI5[1:2]
  
  i <- i+1
  
}

Results[i*3-3+5, 1] <- isident1
Results[i*3-3+6, 1] <- length(Data$Date)
Results[i*3-3+7, 1] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 1] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 2] <- isident2
Results[i*3-3+6, 2] <- length(Data$Date)
Results[i*3-3+7, 2] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 2] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 3] <- isident3
Results[i*3-3+6, 3] <- length(Data$Date)
Results[i*3-3+7, 3] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 3] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 4] <- isident4
Results[i*3-3+6, 4] <- length(Data$Date)
Results[i*3-3+7, 4] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 4] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

Results[i*3-3+5, 5] <- isident5
Results[i*3-3+6, 5] <- length(Data$Date)
Results[i*3-3+7, 5] <- sum((Data$MainEv==TRUE)&(Data$OtherEv==FALSE))
Results[i*3-3+8, 5] <- sum((Data$MainEv==FALSE)&(Data$OtherEv==FALSE))

rownames(Results) <- c(rep(ExpVars, each=3), rep("", (length(ExpVars)+4)*4-length(ExpVars)*3))
print(Results)

# Export the results
write.xlsx(Results[1:(i*3-3+4),], paste(outDir, "/RobustVI.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)

write.xlsx(Results[(i*3-3+5):(i*3-3+8),], paste(outDir, "/RobustVIDesc.xlsx", sep = ""), sheetName = "Sheet1", 
           col.names = TRUE, row.names = TRUE, append = FALSE)



# --------------------------------------------------------------
# Figure C.2: Robustness: VAR impulse responses signalling shock
# --------------------------------------------------------------
Estim  <- estimateIRFHetLP(Data, EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric = TRUE, NoEndo = FALSE, NoExo = F)
PsiHet <- Estim[[1]]

# Plot responses to shock 2
YLim <- list(c(-.1, .01), c(-2.5, .1), c(-1, .1))
PlotIRF <- PsiHet[c(4, 2, 3), 2 , , ]
rownames(PlotIRF) <- c("8Y interest rate (in pp)", "Stock prices (in %)", "Exchange rate (in %)" )

myCharts <- plotIRFHet(PlotIRF, H, SigScale = 1, SigLev, plotActual = FALSE, YLim = YLim)
# Check whether identified and add to plot
isident <- array(NA, H+1)
for (h in 0:H){
  isident[h] <- as.matrix(c(mean(!is.na(PlotIRF[2, h+1, ]), na.rm = TRUE)))
}
g1 <- ggplot(data.frame(isident), aes(c(0:H)))
g1 <- g1 + geom_line(aes(y = `isident`, colour = "black"), size = 0.4)
g1 <- g1 + theme_minimal() + xlab("") + ggtitle("Share identified")+theme(plot.title = element_text(size = 10))+ylab("")+
  theme(legend.position = "none", legend.title = element_blank()) + scale_x_continuous(breaks=seq(0, H, 2))
g1 <- g1 + scale_colour_manual("",values=cbind("black"))
g1 <- g1+ coord_cartesian(ylim = c(.5, 1)) 
g1 <- g1 + theme(panel.grid.major = element_blank()) +
  theme(panel.grid.minor = element_blank()) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.1))+
  theme(axis.ticks = element_line(colour = "black", size=0.1))+
  theme(axis.text = element_text(colour = "black"))+
  theme(text = element_text(size = 11, family = "Palatino"))+
  theme(plot.margin=grid::unit(c(1,1,1,1), "mm"))

myCharts[[(length(myCharts)+1)]] <- g1
gAll <- do.call("grid.arrange", c(myCharts, ncol = 2))
ggsave(paste(outDir, "/IRFVAR.pdf", sep = ""), plot = gAll, width = figWidth2, height = figHeight2, units="cm")
#ggsave(paste(outDir, "/IRFVAR.svg", sep = ""), plot = gAll, width = figWidth2, height = figHeight2, units="cm")

# --------------------------------------------------------------
# Figure C.3: Robustness: VAR impulse responses overnight rate shock
# --------------------------------------------------------------
# compute variance decomposition to plot
# Plot responses to shock 1
YLim2 <- list(c(-.05, .1), c(-1.5, 1), c(-.5, .5))
PlotIRF <- PsiHet[c(4, 2, 3), 1 , , ]
rownames(PlotIRF) <- c("8Y interest rate (in pp)", "Stock prices (in %)", "Exchange rate (in %)" )
myCharts <- plotIRFHet(PlotIRF, H, SigScale = 1, SigLev, plotActual = FALSE, YLim = YLim2)

# Check whether identified and add to plot
isident <- array(NA, H+1)
for (h in 0:H){
  isident[h] <- as.matrix(c(mean(!is.na(PlotIRF[1, h+1, ]), na.rm = TRUE)))
}
g1 <- ggplot(data.frame(isident), aes(c(0:H)))
g1 <- g1 + geom_line(aes(y = `isident`, colour = "black"), size = 0.4)
g1 <- g1 + theme_minimal() + xlab("") + ggtitle("Share identified")+theme(plot.title = element_text(size = 10))+ylab("")+
  theme(legend.position = "none", legend.title = element_blank()) + scale_x_continuous(breaks=seq(0, H, 2))
g1 <- g1 + scale_colour_manual("",values=cbind("black"))
g1 <- g1+ coord_cartesian(ylim = c(.5, 1)) 
g1 <- g1 + theme(panel.grid.major = element_blank()) +
  theme(panel.grid.minor = element_blank()) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.1))+
  theme(axis.ticks = element_line(colour = "black", size=0.1))+
  theme(axis.text = element_text(colour = "black"))+
  theme(text = element_text(size = 11, family = "Palatino"))+
  theme(plot.margin=grid::unit(c(1,1,1,1), "mm"))

myCharts[[(length(myCharts)+1)]] <- g1
gAll <- do.call("grid.arrange", c(myCharts, ncol = 2))
ggsave(paste(outDir, "/IRFVARIR.pdf", sep = ""), plot = gAll, width = figWidth2, height = figHeight2, units="cm")
#ggsave(paste(outDir, "/IRFVARIR.svg", sep = ""), plot = gAll, width = figWidth2, height = figHeight2, units="cm")


# --------------------------------------------------------------
# PLACEBO TESTS REST
# --------------------------------------------------------------
# --------------------------------------------------------------
# Table C.2 a: Placebo simulation using random days before SNB Bill program started
# --------------------------------------------------------------
H <- 0
nAuctions <- 170
nPlacebo  <- 200
confLev   <- 0.9

# Create a sample 
MainEv  <- Sample$Auction            # The auction is shock 1 (maybe rename to "Event")
OtherEv <- ((Sample$SwapAuction)&MainEv==FALSE)|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
Date <- Sample$Date
DataPlacebo <- data.frame(Date, MainEv, FFR.l1, USDEUR.l1, US8Y.l1, SP500.l1, SAR3M, EID8Y, SMI, CHFTW, SARON, LIB3M, EID8Y, OtherEv, RRepoAllot, RRepoYield, USDEUR, VIXEUR)
DataPlacebo <- subset(DataPlacebo, as.Date(Date) >= "2005-01-01" & as.Date(Date) <= "2008-01-01")

EventDays <- "MainEv"
OtherDays <- "OtherEv"

EndVar <- c("SARON", "SMI", "CHFTW", "EID8Y")
EndLab <- c("SARON", "SMI", "CHFTW", "EID8Y")
ExoVar <- c("FFR.l1", "USDEUR.l1", "US8Y.l1", "SP500.l1")

s <- 1
l <- 1
H <- 0
Results <- matrix(NA, nrow = 3, ncol = 3)
print("Placebo simulation progress")
pb <- txtProgressBar(min = 0, max = length(H)*nPlacebo, style = 3)

isident <- matrix(NA, ncol = length(EndVar), nrow = nPlacebo)
reject <- matrix(NA, ncol = length(EndVar), nrow = nPlacebo)
coeffs   <- matrix(NA, ncol = length(EndVar), nrow = nPlacebo)

for (p in 1:nPlacebo){
  
  # Construct a random Auction Dummy from periods without an auction but same number
  DataPlacebo$MainEv <- NA
  randAuctions <- runif(length(DataPlacebo$MainEv))  # Generate a uniform distribution so that each element equally likely
  randAuctions[weekdays(DataPlacebo$Date) == "Friday"] <- -Inf        # Set elements to zero where an auction actually took place
  randAuctions[weekdays(DataPlacebo$Date) == "Monday"] <- -Inf        # Set elements to zero where an auction actually took place
  randAuctions[weekdays(DataPlacebo$Date) == "Wednesday"] <- -Inf     # Set elements to zero where an auction actually took place
  
  # Randomly choose among the other periods
  for (i in 1:nAuctions){
    indexRand = nth(randAuctions, i, descending = T, index.return = T, na.rm = TRUE)
    DataPlacebo$MainEv[indexRand] <- TRUE
  }
  DataPlacebo$MainEv[is.na(DataPlacebo$MainEv)] <- 0
  DataPlacebo$MainEv <- (DataPlacebo$MainEv == 1)
  
  Estim  <- estimateIRFHetLP(DataPlacebo,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
  PsiHet <- Estim[[1]][,2,1,]
  
  #PsiHet   <- estimateIRFHetPAR(DataPlacebo, EventDays, OtherDays, EndVar, ExoVar, SignIdent = -1, ScaleIdent = FALSE, H, P, B, k, useParametric = FALSE, useCumulative = TRUE, NoEndo = T, NoExo = TRUE)
  #rownames(PsiHet) <- EndLab
  
  # Save the coefficients
  coeffs[p, 1] <- mean(PsiHet[2, ], na.rm = TRUE)
  coeffs[p, 2] <- mean(PsiHet[3, ], na.rm = TRUE)
  coeffs[p, 3] <- mean(PsiHet[4, ], na.rm = TRUE)
  
  # Save whether we reject at the 90% and 95% level (share of responses negative or postiive)
  reject[p, 1] <- mean(PsiHet[2, ]<0, na.rm = TRUE)>confLev
  reject[p, 2] <- mean(PsiHet[3, ]<0, na.rm = TRUE)>confLev
  reject[p, 3] <- mean(PsiHet[4, ]<0, na.rm = TRUE)>confLev
  
  isident[p, 1] <- mean(!is.na(PsiHet[2, ]), na.rm = TRUE)>confLev
  isident[p, 2] <- mean(!is.na(PsiHet[3, ]), na.rm = TRUE)>confLev
  isident[p, 3] <- mean(!is.na(PsiHet[4, ]), na.rm = TRUE)>confLev
  
  setTxtProgressBar(pb, l)
  l <- l+1
  
}

# Histograms
Results[1, ] <- colMeans(coeffs, na.rm = TRUE)[1:3]
Results[2, ] <- colMeans(reject, na.rm = TRUE)[1:3]
Results[3, ] <- colMeans(isident, na.rm = TRUE)[1:3]

close(pb)

rownames(Results) <- c("Average impact", "Share rejected", "Share identified")
Table <- xtable(Results,digits = 2)
addtorow <- list()
addtorow$pos <- list(0)
addtorow$command <- c("& Stock prices & Exchange rate & 10Y interest rate\\\\\n")
print(Table, file = paste(outDir, "/Placebo1.tex", sep = ""), 
      add.to.row = addtorow,  include.colnames=F, only.contents=TRUE)


# --------------------------------------------------------------
# Table C.2 b: Placebo simulation using random days during SNB Bill program
# --------------------------------------------------------------
# Create a sample 
OtherEv <- ((Sample$SwapAuction)&MainEv==FALSE)|Sample$AuctionRepoUSD|Sample$AuctionEid|Sample$Auction.d|Sample$ECBmeeting|Sample$SNBlb
OrigMainEv <- MainEv
Date <- Sample$Date
DataPlacebo <- data.frame(Date, MainEv, FFR.l1, USDEUR.l1, US8Y.l1, SP500.l1, SMI, SAR3M, EID8Y, CHFTW, SARON, LIB3M, EID8Y, OtherEv, RRepoAllot, RRepoYield, USDEUR, VIXEUR)
DataPlacebo <- subset(DataPlacebo, as.Date(Date) >= myStart & as.Date(Date) <= myEnd)

EventDays <- "MainEv"
OtherDays <- "OtherEv"

EndVar <- c("SARON", "SMI", "CHFTW", "EID8Y")
EndLab <- c("SARON", "SMI", "CHFTW", "EID8Y")
ExoVar <- c("FFR.l1", "USDEUR.l1", "US8Y.l1", "SP500.l1")

l <- 1
Results <- matrix(NA, nrow = 3, ncol = 3)
print("Placebo simulation progress")
pb <- txtProgressBar(min = 0, max = length(H)*nPlacebo, style = 3)

isident <- matrix(NA, ncol = length(EndVar), nrow = nPlacebo)
reject <- matrix(NA, ncol = length(EndVar), nrow = nPlacebo)
coeffs   <- matrix(NA, ncol = length(EndVar), nrow = nPlacebo)

for (p in 1:nPlacebo){
  
  # Construct a random Auction Dummy from periods without an auction but same number
  DataPlacebo$MainEv <- NA
  randAuctions <- runif(length(DataPlacebo$MainEv))  # Generate a uniform distribution so that each element equally likely
  randAuctions[DataPlacebo$OrigMainEv] <- -Inf                           # Set elements to zero where an auction actually took place
  randAuctions[weekdays(DataPlacebo$Date) == "Friday"] <- -Inf        # Set elements to zero where an auction actually took place
  randAuctions[weekdays(DataPlacebo$Date) == "Monday"] <- -Inf        # Set elements to zero where an auction actually took place
  randAuctions[weekdays(DataPlacebo$Date) == "Wednesday"] <- -Inf     # Set elements to zero where an auction actually took place
  
  # Randomly choose among the other periods
  for (i in 1:nAuctions){
    indexRand = nth(randAuctions, i, descending = T, index.return = T, na.rm = TRUE)
    DataPlacebo$MainEv[indexRand] <- TRUE
  }
  DataPlacebo$MainEv[is.na(DataPlacebo$MainEv)] <- 0
  DataPlacebo$MainEv <- (DataPlacebo$MainEv == 1)
  
  Estim  <- estimateIRFHetLP(DataPlacebo,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative, useParametric, NoEndo = T, NoExo = F)
  PsiHet <- Estim[[1]][,2,1,]
  
   # Save the coefficients
  coeffs[p, 1] <- mean(PsiHet[2, ], na.rm = TRUE)
  coeffs[p, 2] <- mean(PsiHet[3, ], na.rm = TRUE)
  coeffs[p, 3] <- mean(PsiHet[4, ], na.rm = TRUE)
  
  # Save whether we reject at the 90% and 95% level (share of responses negative or postiive)
  reject[p, 1] <- mean(PsiHet[2, ]<0, na.rm = TRUE)>confLev
  reject[p, 2] <- mean(PsiHet[3, ]<0, na.rm = TRUE)>confLev
  reject[p, 3] <- mean(PsiHet[4, ]<0, na.rm = TRUE)>confLev
  
  isident[p, 1] <- mean(!is.na(PsiHet[2, ]), na.rm = TRUE)>confLev
  isident[p, 2] <- mean(!is.na(PsiHet[3, ]), na.rm = TRUE)>confLev
  isident[p, 3] <- mean(!is.na(PsiHet[4, ]), na.rm = TRUE)>confLev
  
  setTxtProgressBar(pb, l)
  l <- l+1
  
}

Results[1, ] <- colMeans(coeffs, na.rm = TRUE)[1:3]
Results[2, ] <- colMeans(reject, na.rm = TRUE)[1:3]
Results[3, ] <- colMeans(isident, na.rm = TRUE)[1:3]

close(pb)

rownames(Results) <- c("Average impact", "Share rejected", "Share identified")
Table <- xtable(Results,digits = 2)
addtorow <- list()
addtorow$pos <- list(0)
addtorow$command <- c("& Stock prices & Exchange rate & 10Y interest rate\\\\\n")
print(Table, file = paste(outDir, "/Placebo2.tex", sep = ""), 
      add.to.row = addtorow,  include.colnames=F, only.contents=TRUE)


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------