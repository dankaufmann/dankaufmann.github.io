#-------------------------------------------------------------------------------
# 2) Simulation exercise heteroskedasticity-based estimator
#-------------------------------------------------------------------------------
# Fabio Canetg and Daniel Kaufmann (2022)
# Overnight rate and signalling effects of central bank bills
# European Economic Review, forthcoming
#-------------------------------------------------------------------------------
# NOTES: 
# - Heteroskedasticity estimator following Nakamura/Steinsson (2018), and Rigobon (2003)
#   Extension to using multiple moments, zero restrictions, and dynamic effects
# - Implemented covariance estimator and bootstrap of confidence interval
# - Controls for persistence via local projections or VAR
# - Now exploits parallel computing capabilities
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# 0) Preliminary commands, load packages and functions, Settings
#-------------------------------------------------------------------------------
cat("\014") 
rm(list=ls())
library(AER)
library(dplyr)
library(lubridate)
library(Rfast)
library(ggplot2)
library(gridExtra)
library(xtable)
library(xts)
library(extrafont)
library(xlsx)
library(stargazer)
library(doParallel)
loadfonts(device = "win")
source("SVARFunctions.R")

# For parallel computing, register number of cores
noCores <- detectCores()
registerDoParallel(cores = noCores)

# Create results folder and settings for outputs
mainDir <- getwd()
outDir <- makeOutDir(mainDir, "/Results/SimulateHetBoot")
dataDir <- paste(mainDir, "./Data/", sep = "")

# OVerall settings
figWidth3 <- 24
figWidth1 <- figWidth3/3
figHeight1 <- 7.5
figHeight2 <- 2*figHeight1

#-------------------------------------------------------------------------------
# 1) Construct results with simulated data
#-------------------------------------------------------------------------------
# A) Use many observations to show actual and simulated response and identification issue
#-------------------------------------------------------------------------------
H <- 20
B <- 8000     # 8000 Number of bootstrap replications (1 means no bootstrap)
k <- 50
P <- 2     # Number of lags in local projection
SigLev    <- c(0.01, 0.05, 0.1)
SignRest  <- 1     # Sign restriction on first variable
SigScale  <- 2    # Inverse scale of shock
NSim <- 1000000   # 1000000 number of simulations
NBurn <- 1000     # 1000 number of burn-in

SimulatedData <- simEventData(NSim, NBurn, H)
SimData <- SimulatedData[[1]]
SimIRF <- SimulatedData[[2]]
SimIRFCum <- SimulatedData[[3]]

# Construct data set for estimation
Data <- data.frame(SimData$y1, SimData$y2, SimData$y3, SimData$x1, SimData$e1!=0, FALSE)
colnames(Data) <- c("Y1", "Y2", "Y3", "X1", "MainEv", "OtherEv")
EventDays <- "MainEv"
OtherDays <- "OtherEv"
EndVar <- c("Y1", "Y2", "Y3")
ExoVar <- c("X1")
NoExo <- TRUE
NoEndo <- FALSE

# Estimate parametric model for non-accumulated IRFs
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B = 1, k = NA, useCumulative = FALSE, useParametric = TRUE, NoEndo, NoExo)
PsiHet <- Estim[[1]][,1,,]
myCharts <- plotIRFHet(PsiHet, H, SigScale, SigLev, plotActual = TRUE, SimIRF)
gAll <- do.call("grid.arrange", c(myCharts, ncol = 3))
ggsave(paste(outDir, "/SimIRFVAR.pdf", sep = ""), plot = gAll, width = figWidth3, height = figHeight1, units="cm")

# Test whether variance decomposition works
VEv <- Estim[[2]]
Binv <- matrix(data = c(0.7, 0.5, 0.3, 0.8, -0.9, 0.1, 0.5, 0.4, 0.2), ncol = 3, nrow = 3)
E <- diag(c(2, 3, 2))
E1 <- diag(c(2, 0, 0))
E2 <- diag(c(0, 3, 0))
E3 <- diag(c(0, 0, 0))

Overall <- Binv%*%E%*%t(Binv%*%E)
VAR1 <- Binv%*%E1%*%t(Binv%*%E1)
VAR2 <- Binv%*%E2%*%t(Binv%*%E2)
VAR2 <- Binv%*%E3%*%t(Binv%*%E3)

Decomp1 <- diag(VAR1)/diag(Overall)
print(Decomp1)
print(VEv[, 1, 1, 1])

# Estimate parametric for accumulated IRFs
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B = 1, k = NA, useCumulative = TRUE, useParametric = TRUE, NoEndo, NoExo)
PsiHet <- Estim[[1]][,1,,]
myCharts <- plotIRFHet(PsiHet, H, SigScale, SigLev, plotActual = TRUE, SimIRFCum)
gAll <- do.call("grid.arrange", c(myCharts, ncol = 3))
ggsave(paste(outDir, "/SimIRFVARCum.pdf", sep = ""), plot = gAll, width = figWidth3, height = figHeight1, units="cm")

# Estimate non-parametric model for non-accumulated IRFs
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B = 1, k = NA, useCumulative = FALSE, useParametric = FALSE, NoEndo, NoExo)
PsiHet <- Estim[[1]][,1,,]
myCharts <- plotIRFHet(PsiHet, H, SigScale, SigLev, plotActual = TRUE, SimIRF)
gAll <- do.call("grid.arrange", c(myCharts, ncol = 3))
ggsave(paste(outDir, "/SimIRFLP.pdf", sep = ""), plot = gAll, width = figWidth3, height = figHeight1, units="cm")

# Estimate non-parametric model for accumulated IRFs
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B = 1, k = NA, useCumulative = TRUE, useParametric = FALSE, NoEndo, NoExo)
PsiHet <- Estim[[1]][,1,,]
myCharts <- plotIRFHet(PsiHet, H, SigScale, SigLev, plotActual = TRUE, SimIRFCum)
gAll <- do.call("grid.arrange", c(myCharts, ncol = 3))
ggsave(paste(outDir, "/SimIRFLPCum.pdf", sep = ""), plot = gAll, width = figWidth3, height = figHeight1, units="cm")

#-------------------------------------------------------------------------------
# B) Use few observations to show that confidence intervals work and compare to non-parametric
#-------------------------------------------------------------------------------
NSim <- 2000
NBurn <- 1000
SimulatedData <- simEventData(NSim, NBurn, H)
SimData <- SimulatedData[[1]]
SimIRF <- SimulatedData[[2]]
SimIRFCum <- SimulatedData[[3]]

# Construct data set for estimation
Data <- data.frame(SimData$y1, SimData$y2, SimData$y3, SimData$x1, SimData$e1!=0, FALSE)
colnames(Data) <- c("Y1", "Y2", "Y3", "X1", "MainEv", "OtherEv")
EndVar <- c("Y1", "Y2", "Y3")
ExoVar <- c("X1")
NoExo <- TRUE

YLim <- list(c(-.25, 1.5), c(-1, 1), c(-.25, .5))
YLimCum <- list(c(0, 7), c(-4, 1.5), c(0, 2))

# Estimate parametric model for non-accumulated IRFs
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative = FALSE, useParametric = TRUE, NoEndo, NoExo)
PsiHet <- Estim[[1]][,1,,]
myCharts <- plotIRFHet(PsiHet, H, SigScale, SigLev, plotActual = TRUE, SimIRF, YLim)
gAll <- do.call("grid.arrange", c(myCharts, ncol = 3))
ggsave(paste(outDir, "/SimIRFVARBoot.pdf", sep = ""), plot = gAll, width = figWidth3, height = figHeight1, units="cm")

# Estimate parametric for accumulated IRFs
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative = TRUE, useParametric = TRUE, NoEndo, NoExo)
PsiHet <- Estim[[1]][,1,,]
myCharts <- plotIRFHet(PsiHet, H, SigScale, SigLev, plotActual = TRUE, SimIRFCum, YLimCum)
gAll <- do.call("grid.arrange", c(myCharts, ncol = 3))
ggsave(paste(outDir, "/SimIRFVARBootCum.pdf", sep = ""), plot = gAll, width = figWidth3, height = figHeight1, units="cm")

# Estimate non-parametric model for non-accumulated IRFs
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative = FALSE, useParametric = FALSE, NoEndo, NoExo)
PsiHet <- Estim[[1]][,1,,]
myCharts <- plotIRFHet(PsiHet, H, SigScale, SigLev, plotActual = TRUE, SimIRF, YLim)
gAll <- do.call("grid.arrange", c(myCharts, ncol = 3))
ggsave(paste(outDir, "/SimIRFLPBoot.pdf", sep = ""), plot = gAll, width = figWidth3, height = figHeight1, units="cm")

# Export statistics that would point to weak identification
isident <- as.matrix(c(mean(!is.na(PsiHet[1, 1, ]), na.rm = TRUE), mean(!is.na(PsiHet[1, H, ]), na.rm = TRUE)))
rownames(isident) <- c("H = 0", "H = 5")
colnames(isident) <- "Share identified"
Table <- xtable(isident, digits = 2, caption = "Share identified")
print(Table, file = paste(outDir, "/IdentifiedSimIRFLPBoot.html", sep = ""),  type = "html", include.colnames=F, only.contents=TRUE)

# Estimate non-parametric model for accumulated IRFs
Estim  <- estimateIRFHetLP(Data,  EventDays, OtherDays, EndVar, ExoVar, SignRest, H, P, B, k, useCumulative = TRUE, useParametric = FALSE, NoEndo, NoExo)
PsiHet <- Estim[[1]][,1,,]
myCharts <- plotIRFHet(PsiHet, H, SigScale, SigLev, plotActual = TRUE, SimIRFCum, YLimCum)
gAll <- do.call("grid.arrange", c(myCharts, ncol = 3))
ggsave(paste(outDir, "/SimIRFLPBootCum.pdf", sep = ""), plot = gAll, width = figWidth3, height = figHeight1, units="cm")

# Export statistics that would point to weak identification
isident <- as.matrix(c(mean(!is.na(PsiHet[1, 1, ]), na.rm = TRUE), mean(!is.na(PsiHet[1, H, ]), na.rm = TRUE)))
rownames(isident) <- c("H = 0", "H = 5")
colnames(isident) <- "Share identified"
Table <- xtable(isident, digits = 2, caption = "Share identified")
print(Table, file = paste(outDir, "/IdentifiedSimIRFLPBootCum.html", sep = ""),  type = "html", include.colnames=F, only.contents=TRUE)

# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
